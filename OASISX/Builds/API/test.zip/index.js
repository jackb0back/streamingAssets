const getNumber = (counter) => {
  return parseFloat(counter.dataset.countTo);
};

const getSpeed = (counter) => {
  return parseFloat(counter.dataset.countTo / 0.9);
};

const updateTex = (counter, text) => {
  counter.textContent = text;
};

const easeOutQuad = (t) => {
  return 1 - (1 - t) * (1 - t);
};

const animate = (counter, countTo, duration) => {
  let startTime = null;

  const step = (timestamp) => {
    if (!startTime) {
      startTime = timestamp;
    }

    const elapsed = timestamp - startTime;
    const progress = Math.min(elapsed / duration, 1);

    const easedProgress = easeOutQuad(progress); // Use ease-out easing

    const currentNum = Math.floor(easedProgress * countTo);

    updateTex(counter, currentNum);

    if (progress < 1) {
      window.requestAnimationFrame(step);
    }
  };

  window.requestAnimationFrame(step);
};

const sideAd = document.getElementById('sidead');

// Get references to the cursor image
const customCursor = document.getElementById('custom-cursor');

// Listen for mousemove events on the document
document.addEventListener('mousemove', (e) => {
  // Update the cursor's position to match the mouse coordinates
  customCursor.style.left = e.clientX + 'px';
  customCursor.style.top = e.clientY + 'px';
});

// Optionally, you can hide the default cursor entirely
document.body.style.cursor = 'none';


var loggedIn = false;
var client_data = {
    version: "b2.5.5"
  }
  var server_data = {
    version: ""
  }

  var notifying = false;
  var isDev = false;
  var streamingAssetURL = "https://cdn.jsdelivr.net/gh/jackb0back/streamingAssets@main/OASISX/"
var streamingAssets = {
library: streamingAssetURL + "books.png",
store: streamingAssetURL + "store.png",
frens: streamingAssetURL + "friends.png",
settings: streamingAssetURL + "settings.png",
favIcon: streamingAssetURL + "favicon.png",
news: streamingAssetURL + "news.png",
dev: streamingAssetURL + "dev.png",
dots: streamingAssetURL + "dots.png",
chat: streamingAssetURL + "chat.png",
themes: streamingAssetURL + "paintbrush.png",
x_logo: streamingAssetURL + "new-logo.png",
x_icon: streamingAssetURL + "newX.png",
info: streamingAssetURL + "info.png",
wallet: streamingAssetURL + "wallet.png",
credits: streamingAssetURL + "credits-removebg-preview.png",
plugins: streamingAssetURL + "plugin.png",
download: streamingAssetURL + "download-white.png",
//new ones: add asap
cashapp: streamingAssetURL + "cashapp.png",
cashappnoname: streamingAssetURL + "cashapp (no name).png",
closeicon: streamingAssetURL + "closeicon.svg",
viplogo: streamingAssetURL + "new-logo(vip).png"
}

const notyf = new Notyf({
types: [
{
  type: 'theme',
  background: 'var(--css-button)',
  icon: `<img class="n-icon" src="`+streamingAssetURL+`paintbrush.png">`,
},
{
  type: 'download',
  background: 'var(--css-button)',
  icon: `<img style="filter:invert(1);" class="n-icon" src="`+streamingAssetURL+`download.png">`,
},
{
  type: 'settings',
  background: 'var(--css-button)',
  icon: `<img class="n-icon" src="`+streamingAssetURL+`settings.png">`,
},
{
  type: 'alert',
  background: 'var(--css-button)',
  icon: `<img style="filter:invert(1);" class="n-icon" src="`+streamingAssetURL+`alert.svg">`,
},
{
  type: 'info',
  background: 'var(--css-button)',
  icon: `<img class="n-icon" src="`+streamingAssetURL+`info.png">`,
},
{
  type: 'ok',
  background: 'var(--css-button)',
  icon: `<img class="n-icon" src="`+streamingAssetURL+`thumbup.png">`,
}
]
});



var installs = [];
var opend = false;
var sortedStore = [];
var sortedShop = [];
var navs = [document.getElementById("content-lib"),document.getElementById("content-store"),document.getElementById("content-friends"),document.getElementById("content-settings"),document.getElementById("content-profile"),document.getElementById("content-news"),document.getElementById("content-dev"),document.getElementById("content-chat"),document.getElementById("content-themes"),document.getElementById("content-info"),document.getElementById("content-wallet"),document.getElementById("content-plugins")];
//@nav
//0 = lib //default
//1 = store
//2 = frens
//3 = settings
//4 = profile
//5 = news
//6 = dev
//7 = chat
//8 = themes
//9 = info
//10 = shop
//11 = plugins
var currentNav = 0;
var loginHash = "";
var login_creds = {
username: null,
password: null
}
var defaultSettings = {
gamesDir: "games/",
dev: {
DevFolder: "dev/",
loginDebug: false,
},
newWin: false,
tooltips: true,
theme: "darkmode",
plugins_allowed: false,
lib_display: "",
}
var setting_conf = defaultSettings;
var savedThemes = [];
var defaultTheme = "/*default*/ \n --gradient: none; \n --button-gradient: none; \n --thick-trim: 5px solid rgba(0,0,0,0.15); \n --trim: none; \n --background-color-body: #181818;\n  --text-color: white;\n  --background-color-top: #252525;\n  --background-color-sidebar: #252525;\n  --background-color-sidebar-button: #151515;\n  --background-color-icon: #333;\n  --background-color-play: #3c3c3c;\n  --background-color-game: #333;\n  --background-color-window: #151515;\n  --background-color-window-title: #555;\n  --sidebar-hover: #333;\n  --image-invert: 0;\n  --css-button: #333;\n  --background-color-game-play: #121212;\n  --news-background: #333;\n  --news-cont: #212121;\n  --main-font: 'Montserrat', sans-serif;"
var settings = false;
var defaultLocalData = {
  settings: defaultSettings,
  themes: [],
  favs: [], //favorites are install indexs
  installs: [],
  currentCursor: "streamingAssets/cursors/Defaullt.png",
  cursorSize: 15,
  };
var localData = defaultLocalData;
const today = new Date();
const formattedDate = today.toLocaleDateString("en-US", {
month: "2-digit",
day: "2-digit",
year: "numeric"
});
var ld = localStorage.getItem("OAX_localD");
var debug_console = document.getElementById("devCLI");
var darkmode = true;
if (ld !== undefined || ld !== null) {
if (isJsonString(atob(ld))) {
localData = JSON.parse(atob(ld));

updateLocalData();



installs = localData.installs;
if (localData.settings !== undefined) {
  setting_conf.gamesDir = localData.settings.gamesDir;


  //loadSettings();
  setTimeout(function(){
    loadSettings();
  },1000)
}else {
  addLocalData("settings",'');
  localData.settings = setting_conf;
  saveLocalData();
}

if (localData.themes !== undefined) {
  savedThemes = localData.themes;
  LoadSavedThemes();
}else {
  addLocalData("themes",'');
  localData.themes = [];
  saveLocalData();
}


if (localData.installs !== undefined) {
loadInstalls(setting_conf.lib_display);
}else {
  saveInstalls();
}
}
}
if (ld == undefined){
localData = defaultLocalData;
saveLocalData();
window.location.reload();
}

let atKeyPressTimestamps = [];
document.addEventListener("keydown", function(event) {
if (event.key === "@") {
const now = Date.now();

// Remove timestamps that are older than the time window
atKeyPressTimestamps = atKeyPressTimestamps.filter(timestamp => now - timestamp <= 200);

atKeyPressTimestamps.push(now);

// Check if there are three "@" key presses in quick succession
if (atKeyPressTimestamps.length === 2) {
  openSecretSettings();
  // Clear the timestamp array after triggering the function
  atKeyPressTimestamps = [];
}
}
});

let atKeyPressTimestamps2 = [];
document.addEventListener("keydown", function(event) {
if (event.key === "!") {
const now2 = Date.now();

// Remove timestamps that are older than the time window
atKeyPressTimestamps2 = atKeyPressTimestamps2.filter(timestamp => now2 - timestamp <= 200);

atKeyPressTimestamps2.push(now2);

// Check if there are three "@" key presses in quick succession
if (atKeyPressTimestamps2.length === 2) {
  offlinedev();
  // Clear the timestamp array after triggering the function
  atKeyPressTimestamps2 = [];
}
}
});


var currentCursorElm = null;



function updateCursorUI() {
  var currentC = document.getElementById("custom-cursor").src;
  for (let i = 0; i < document.getElementsByClassName("cursor-item").length; i++) {
      var e = document.getElementsByClassName("cursor-item")[i].getElementsByTagName("img")[0];
     // console.log(e.dataset.src);

      console.log(currentC,e.src);

      if (currentC == e.src) {
        console.log(true);
        currentCursorElm = document.getElementsByClassName("cursor-item")[i];
        document.getElementsByClassName("cursor-item")[i].classList.add("cursor-item-current");
        currentCursorElm.getElementsByTagName("h4")[1].innerHTML = ""
      }
  }
}



function changeCursor(img) {
  document.getElementById("custom-cursor").src = img;
  localData.currentCursor = img;
  saveLocalData();
}


function changeCursorSize(s) {
  document.documentElement.style.setProperty("--cursorSize",s+"px");
  document.getElementById("cSize").innerHTML = s + "px";
  localData.cursorSize = JSON.parse(s);
  saveLocalData();
}

function setCursor(elm) {
  if (currentCursorElm !== null) {
    currentCursorElm.classList.remove("cursor-item-current");
    currentCursorElm.getElementsByTagName("h4")[1].innerHTML = ""
  }
  currentCursorElm = elm;
  elm.classList.add("cursor-item-current");
  elm.getElementsByTagName("h4")[1].innerHTML = ""
  changeCursor(elm.getElementsByTagName('img')[0].src);
}


function loadCursorImgs() {
  for (let i = 0; i < document.getElementsByClassName("cimg").length; i++) {
    setTimeout(function(){    
      document.getElementsByClassName("cimg")[i].src = document.getElementsByClassName("cimg")[i].dataset.src;
  },1000)
  }
}
loadCursorImgs();


function updateLocalData() {
  var defKeys = Object.keys(defaultLocalData);
  var current = Object.keys(JSON.parse(atob(localStorage.getItem("OAX_localD"))));

  for (let i = 0; i < defKeys.length; i++) {
    if (!current.includes(defKeys[i])) {
      if (defKeys[i] == undefined || current[i] == undefined) {
        console.error(undefined);
        return;
      }
      console.log(defKeys[i]);

      localData[defKeys[i]] = defaultLocalData[defKeys[i]];
    }
  }

  setTimeout(function(){
   // saveLocalData();
  },100);

}





function convertToOASISCredits(amount) {
const conversionRates = {
    "USD": 1000, // 1 US Dollar = 10 OASIS Credits
    "cent": 10 // 1 US Cent = 0.1 OASIS Credits
};
currency = "USD"

if (!conversionRates.hasOwnProperty(currency)) {
    throw new Error("Unsupported currency");
}

const oasisCredits = amount * conversionRates[currency];
return oasisCredits;
}


function SUSMODE() {
  document.getElementById("logo").src = "https://cdn.jsdelivr.net/gh/jackb0back/streamingAssets@master/OASISX/sus%20logo.png";
  document.getElementById("logo").style.padding = "8px";
}

function openSecretSettings() {
newWindow("Secret settings",`
<h2>Secret settings</h2>
<h3 style="margin-left:0;">Enable plugins</h3>
<button class="css-button" onclick="localData.settings.plugins_allowed = !localData.settings.plugins_allowed;saveLocalData();window.location.reload()">Enable</button>
<h3 style="margin-left:0;">S.E.X mode</h3>
<button class="css-button" onclick="SUSMODE();">Enable</button>
`,600,400);
}

function loadToolTips() {
tippy('#pf_username', {
content: "<p class='tooltip'>click here to view your profile</p>",
placement: 'bottom',
arrow: true,
animation: 'fade',
allowHTML: true,
});
tippy('#addApp', {
content: "<p class='tooltip'>click here to add a custom app title</p>",
placement: 'bottom',
arrow: true,
animation: 'fade',
allowHTML: true,
followCursor: true,
});
tippy('#button-library', {
content: "<p class='tooltip'>This is where all your apps and games are stored</p>",
placement: 'bottom',
arrow: true,
animation: 'fade',
allowHTML: true,
});
tippy('#button-store', {
content: "<p class='tooltip'>Download apps and games here</p>",
placement: 'bottom',
arrow: true,
animation: 'fade',
allowHTML: true,
});
tippy('#button-chat', {
content: "<p class='tooltip'>Chat with other OASIS users</p>",
placement: 'bottom',
arrow: true,
animation: 'fade',
allowHTML: true,
});
tippy('#button-friends', {
content: "<p class='tooltip'>view other OASIS user profiles</p>",
placement: 'bottom',
arrow: true,
animation: 'fade',
allowHTML: true,
});
tippy('#button-news', {
content: "<p class='tooltip'>see the latest news from the developers</p>",
placement: 'bottom',
arrow: true,
animation: 'fade',
allowHTML: true,
});
tippy('#button-themes', {
content: "<p class='tooltip'>change how your client looks!</p>",
placement: 'bottom',
arrow: true,
animation: 'fade',
allowHTML: true,
});
tippy('#set_img', {
content: "<p class='tooltip'>change settings for the client</p>",
placement: 'bottom',
arrow: true,
animation: 'fade',
allowHTML: true,
});
tippy('#settings-save-data-loc', {
content: "<p class='tooltip'>change where your prefrences are stored</p>",
placement: 'top',
arrow: true,
animation: 'fade',
allowHTML: true,
});
tippy('#settings-gameFolder', {
content: "<p class='tooltip'>change the folder that your apps are stored</p>",
placement: 'top',
arrow: true,
animation: 'fade',
allowHTML: true,
});
tippy('#settings-gameFolder', {
content: "<p class='tooltip'>change the folder that your apps are stored</p>",
placement: 'top',
arrow: true,
animation: 'fade',
allowHTML: true,
});
tippy('#profile-rank', {
content: "<p class='tooltip'>this is your rank</p>",
placement: 'top',
arrow: true,
animation: 'fade',
allowHTML: true,
});

}

function openLibSet() {
newWindow("Library - settings",`
<h1>Library settings</h1>
Add app: Add a custom app to your library <br>
<button style="margin:10px;" onclick="openAppCreateor()" id="addApp" class="css-button">add app</button>
<br>
Export library: export your saved app titles <br>
<button style="margin:10px;" onclick="exportApps()" class="css-button">Export library</button> <br>
Import library: upload saved app titles from export <br>
<button style="margin:10px;" class="css-button" onclick="document.getElementById('appImp').click();">Import library</button>
<br>
Delete library: delete all saved app titles <br>
<button style="margin:10px; background-color:red !important;" onclick="delete_all_apps()" class="css-button">Delete library</button> <br>

`,600,400);
}

function delete_all_apps() {
if (confirm("Delete all app titles?")) {
if (confirm("are you sure?")) {
  installs = [];
  localData.installs = installs;
  saveLocalData();
  loadInstalls(setting_conf.lib_display);
}
}
}
function offlinedev() {
document.getElementById("login").style.display = "none";
  loadProfile();
  LoadOnlineAssets();
}

function importApps(apps) {
if (isJsonString(apps)) {
installs = JSON.parse(apps);
loadInstalls(setting_conf.lib_display);
setTimeout(function () {
  if (confirm("save imported library?")) {
    localData.installs = installs;
    saveLocalData();
    alert("saved.");
  }else {
    installs = localData.installs;
    loadInstalls(setting_conf.lib_display);
  }
}, 1500)
}
}
document.getElementById('appImp').addEventListener('change', function() {
  readSelectedFile('appImp', importApps);
});
function readSelectedFile(fileInputId, callback) {
const fileInput = document.getElementById(fileInputId);

if (!fileInput) {
console.error(`File input element with ID '${fileInputId}' not found.`);
return;
}

const selectedFile = fileInput.files[0];

if (!selectedFile) {
console.error('No file selected.');
return;
}

const reader = new FileReader();

reader.onload = function(event) {
const contents = event.target.result;
callback(contents);
};

reader.readAsText(selectedFile);
}


function exportApps() {
download("my_OASIS_library_"+formattedDate,JSON.stringify(installs));
}
function download(filename, text) {
var element = document.createElement('a');
element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
element.setAttribute('download', filename);

element.style.display = 'none';
document.body.appendChild(element);

element.click();

document.body.removeChild(element);
}

function AppCreateor_update_img(elm) {
//console.log(elm.value);
document.getElementById("appC_imgelm").src = elm.value;
}
function AppCreateor_create() {
var vals = {
"name":document.getElementById("appC_name").value,
"img":document.getElementById("appC_img").value,
"download":"",
"desc":document.getElementById("appC_desc").value,
"fileName":document.getElementById("appC_gameFile").value,
"category":document.getElementById("appC_cat").value
}
installs.push(vals);
localData.installs = installs;
saveLocalData();
loadInstalls(setting_conf.lib_display);
}

function openAppCreateor() {
newWindow("OASIS app creator",`
<div style="margin-bottom: 10px;" id="appC">
<button style="margin-top: 10px;margin-bottom: 10px;" class="css-button" onclick="AppCreateor_create()">create</button>
<br>
<p>name: </p><input type="text" style="height:25px;" id="appC_name" placeholder="name"><br>
<p> image: </p>
<input onchange="AppCreateor_update_img(this)" type="text" style="height:25px;" id="appC_img" placeholder="image url"><br>
<img id="appC_imgelm" class="game-img" style="margin-top:8px;" src="">
<p>category: </p>  
<select style="height:25px;" id="appC_cat">
<option value="app">App</option>
<option value="game">Game</option>
</select>
<p>description: </p><input type="text" style="height:25px;" id="appC_desc" placeholder="description"><br>
<br>
Game file: `+setting_conf.gamesDir+`
<input id="appC_gameFile" type="text" value="">

</div>
`,600,400);
}












document.addEventListener("keyup", function(event) {
if (event.key === '~') {
   if(isDev) {
    newWindow('DEBUG',`<iframe style='width:99%;height:98%;' src='`+setting_conf.dev.DevFolder+`/terminal.html?username=`+login_creds.username+`'></iframe>`,600,400);
   }
}
});

function customTheme(css, noNotif) {
  darkmode = false;

  const cssVariables = css.match(/--[\w-]+:[^;]+;/g); // Extract variable declarations
  console.log(cssVariables);

  if (cssVariables) {
    cssVariables.forEach(variable => {
      const [variableName, variableValue] = variable.split(':');
      const propertyName = variableName.trim();
      const propertyValue = variableValue.trim().slice(0, -1); // Remove the semicolon
      console.log(propertyName,propertyValue);
      console.log(propertyName)
      setTimeout(function(){
     
        document.documentElement.style.setProperty(propertyName, propertyValue);
      },500)
    });
  }

  setting_conf.theme = btoa(css);
  localData.theme = btoa(css);
  saveLocalData();
  toggleTheme();

  if (!noNotif)
    notify("theme", "Updated theme.");
}



function toggleTheme(note, save) {
  console.log("toggle");
  if (darkmode) {
      darkmode = false;
      if (save) {
          setting_conf.theme = "lightmode";
      }

      document.documentElement.style.setProperty('--background-color-body', 'white');
      document.documentElement.style.setProperty('--text-color', '#181818');
      document.documentElement.style.setProperty('--background-color-top', '#f0f0f0');
      document.documentElement.style.setProperty('--background-color-sidebar', '#f0f0f0');
      document.documentElement.style.setProperty('--background-color-sidebar-button', '#e0e0e0');
      document.documentElement.style.setProperty('--background-color-icon', '#333');
      document.documentElement.style.setProperty('--background-color-play', '#d0d0d0');
      document.documentElement.style.setProperty('--background-color-game', '#ccc');
      document.documentElement.style.setProperty('--background-color-window', '#e0e0e0');
      document.documentElement.style.setProperty('--background-color-window-title', '#aaa');
      document.documentElement.style.setProperty('--sidebar-hover', '#ccc');
      document.documentElement.style.setProperty('--image-invert', '1');
      document.documentElement.style.setProperty('--css-button', '#ccc');
      document.documentElement.style.setProperty('--background-color-game-play', '#f5f5f5');
      document.documentElement.style.setProperty('--news-background', '#ccc');
      document.documentElement.style.setProperty('--news-cont', '#e0e0e0');
      document.documentElement.style.setProperty('--main-font', "'Montserrat', sans-serif");
      document.documentElement.style.setProperty('--thick-trim', '5px solid rgba(0,0,0,0.5);');
      document.documentElement.style.setProperty('--trim', "none");
      document.documentElement.style.setProperty('--gradient', 'none');
      document.documentElement.style.setProperty('--button-gradient', "none");

      if (note)
          notify('theme', 'enabled lightmode.');
  } else {
      darkmode = true;
      if (save) {
          setting_conf.theme = "darkmode";
      }

      document.documentElement.style.setProperty('--background-color-body', '#181818');
      document.documentElement.style.setProperty('--text-color', 'white');
      document.documentElement.style.setProperty('--background-color-top', '#252525');
      document.documentElement.style.setProperty('--background-color-sidebar', '#252525');
      document.documentElement.style.setProperty('--background-color-sidebar-button', '#151515');
      document.documentElement.style.setProperty('--background-color-icon', '#333');
      document.documentElement.style.setProperty('--background-color-play', '#3c3c3c');
      document.documentElement.style.setProperty('--background-color-game', '#333');
      document.documentElement.style.setProperty('--background-color-window', '#151515');
      document.documentElement.style.setProperty('--background-color-window-title', '#555');
      document.documentElement.style.setProperty('--sidebar-hover', '#333');
      document.documentElement.style.setProperty('--image-invert', '0');
      document.documentElement.style.setProperty('--css-button', '#333');
      document.documentElement.style.setProperty('--background-color-game-play', '#121212');
      document.documentElement.style.setProperty('--news-background', '#333');
      document.documentElement.style.setProperty('--news-cont', '#212121');
      document.documentElement.style.setProperty('--main-font', "'Montserrat', sans-serif");
      document.documentElement.style.setProperty('--thick-trim', '5px solid rgba(0,0,0,0.5)');
      document.documentElement.style.setProperty('--trim', "none");
      document.documentElement.style.setProperty('--gradient', 'none');
      document.documentElement.style.setProperty('--button-gradient', "none");

      if (note)
          notify('theme', 'enabled darkmode.');
  }

  if (save) {
      localData.theme = setting_conf.theme;
      saveLocalData();
  }
}


function removeTheme(i) {

  savedThemes.splice(i,1);

  localData.themes = savedThemes;
  saveLocalData(); 
  LoadSavedThemes();
  notify("theme","removed theme",5000);
}

function saveTheme(name,v) {
if(confirm("save theme?")) {
savedThemes.push({name:name,theme:btoa(v)});
localData.themes = savedThemes;
saveLocalData(); 
LoadSavedThemes();
// alert("saved.");
notify("theme","saved theme",5000);
}
}

function LoadSavedThemes() {
document.getElementById("saved-themes").innerHTML = "";
for (let i = 0; i < savedThemes.length; i++) {
  var prev = getAverageColor(atob(savedThemes[i].theme));
document.getElementById("saved-themes").innerHTML += `
<button id="`+i+`" class="savedthemesbuttons" style="margin-bottom:10px;" onclick="customTheme(atob('`+savedThemes[i].theme+`'))" class="css-button"> <div style="background-color: `+prev+`;" class="themecolor"></div><p>[`+i+`] `+savedThemes[i].name+`</p>     <img src="`+streamingAssets.closeicon+`"  onclick="event.stopPropagation(); removeTheme('`+i+`');"></img></button>
<br>`;
}
}

function getAverageColor(colorString) {
  // Extract color codes using regular expression
  const colorCodes = colorString.match(/#(?:[0-9a-fA-F]{3}){1,2}/g);

  if (!colorCodes || colorCodes.length === 0) {
      console.error('No color codes found in the input string.');
      return;
  }

  // Calculate average color
  let totalRed = 0;
  let totalGreen = 0;
  let totalBlue = 0;

  colorCodes.forEach(colorCode => {
      const hex = colorCode.substring(1); // remove the '#' character
      totalRed += parseInt(hex.substring(0, 2), 16);
      totalGreen += parseInt(hex.substring(2, 4), 16);
      totalBlue += parseInt(hex.substring(4, 6), 16);
  });

  const averageRed = Math.round(totalRed / colorCodes.length);
  const averageGreen = Math.round(totalGreen / colorCodes.length);
  const averageBlue = Math.round(totalBlue / colorCodes.length);

  // Convert RGB to hex
  const averageColor = `#${averageRed.toString(16).padStart(2, '0')}${averageGreen.toString(16).padStart(2, '0')}${averageBlue.toString(16).padStart(2, '0')}`;

  return averageColor;
}

function getLhash(html) {
//console.log(atob(loginHash));
if (html) {
var a = "<br>Your login hash is: <br>" + "#" + loginHash + "<br><br> you can copy and paste this at the end of the url or click this link to automaticly login. <br> DO NOT SHARE THIS HASH IT CONTAINS YOUR ACCOUNT PASSWORD";
return a;
}else {
return "Your login hash is: \n \n" + "#" + loginHash + "\n \n you can copy and paste this at the end of the url to automaticly login. \n DO NOT SHARE THIS HASH IT CONTAINS YOUR ACCOUNT PASSWORD"
}
}


function saveSettings() {
if (confirm("save settings?")) {
setting_conf.gamesDir = document.getElementById("settings-gameFolder").value;
setting_conf.newWin = document.getElementById("settings-newWin?").checked;
setting_conf.tooltips = document.getElementById("settings-tooltips").checked;
setting_conf.lib_display == document.getElementById("settings-library-display").value;
if (isDev) {
  setting_conf.dev.DevFolder = document.getElementById("settings-dev-devAssets").value;
  setting_conf.dev.loginDebug = document.getElementById("settings-dev-ldebug").checked;
}

localData.settings = setting_conf;
saveLocalData();
loadSettings();
notify("settings","saved, reload page for changes to take effect.");
}
}
function loadSettings() {
setting_conf = localData.settings;
loadInstalls(setting_conf.lib_display);
db_conf.showDeets = setting_conf.dev.loginDebug;
if (setting_conf.tooltips) {
loadToolTips();
}
if (setting_conf.theme == "lightmode") {
darkmode = true;
toggleTheme();
}else if (setting_conf.theme !== "darkmode") {
customTheme(atob(setting_conf.theme),true);
}


if (setting_conf.plugins_allowed) {
  document.getElementById("plugin_btn").style.display = "block"
}

changeCursor(localData.currentCursor);
updateCursorUI();
changeCursorSize(localData.cursorSize);
document.getElementById("cursorSize").value = localData.cursorSize;

setTimeout(function(){
document.getElementById("settings-library-display").value = setting_conf.lib_display;
document.getElementById("settings-gameFolder").value = setting_conf.gamesDir;
document.getElementById("settings-dev-devAssets").value = setting_conf.dev.DevFolder;
document.getElementById("settings-newWin?").checked = setting_conf.newWin;
document.getElementById("settings-tooltips").checked = setting_conf.tooltips;
if(isDev) {
  document.getElementById("devCLI").src = setting_conf.dev.DevFolder + "terminal.html?username=" + login_creds.username;
  show("settings-dev");
  document.getElementById("settings-dev-ldebug").checked = setting_conf.dev.loginDebug;

}


if(setting_conf.newWin) {
  if (window.opener == null) {
    const width = window.screen.availWidth;
    const height = window.screen.availHeight;
    const options = `width=${width},height=${height},top=0,left=0`;
    var e = window.open(window.location.href, '_blank', options);
    e.window.eval("opend = true;")
  }
}


},1000);

}

if(window.location.hash) {
var u,p;
u = document.getElementById("username");
p = document.getElementById("password");

var a = JSON.parse(atob(window.location.hash.slice(1)));

u.value = a.username;
p.value = a.password;


//wait a sec for css to all load in
if (loadedDBs.store == false || loadedDBs.user == false) {
  getDatabaseURLS(function (){
    document.getElementById(`cd`).innerHTML = `<h4 style='color:cyan;text-align: center;'>getting latest info...</h4>`;
    setTimeout(function(){doLogin();},100);
  });
}else {
  setTimeout(function(){doLogin();},100);
  
}


}

for (let i = 0; i < navs.length; i++) {
navs[i].style.display = "none"
}
DisplayNav(currentNav);



//  <h2><span>`+fetchedData.users.usernames[i]+`</span></h2> <img id="USER-`+btoa(fetchedData.users.usernames[i])+`" class="icon frenIMG" src="`+fetchedData.users.profilePictures[i]+`"> <br>


function show(id) {
document.getElementById(id).style.display = "block";
}
function hide(id) {
document.getElementById(id).style.display = "none";
}

function LoadFrens() {
setTimeout(function(){
document.getElementById("myUL").innerHTML = "";
for (let i = 0; i < fetchedData.users.ranks.length; i++) {

 if (fetchedData.users.usernames[i] !== login_creds.username) {
   if (fetchedData.users.ranks[i].color == "rainbow") {
    // //console.log(i + " true")
   document.getElementById("myUL").innerHTML += `
 <li><a class="`+fetchedData.users.ranks[i].color+`" href="javascript:"><span>`+fetchedData.users.usernames[i]+`</span> (`+fetchedData.users.ranks[i].rank+`)<img id="USER-`+btoa(fetchedData.users.usernames[i])+`" class="icon-no-inv frenIMG" src="`+fetchedData.users.profilePictures[i]+`">    <button class="addFren">add friend</button></a></li>
 ` 
 }
 if(fetchedData.users.ranks[i].color == "gold") {
   document.getElementById("myUL").innerHTML += `
 <li><a class="`+fetchedData.users.ranks[i].color+`Fren" href="javascript:"><span>`+fetchedData.users.usernames[i]+`</span> (`+fetchedData.users.ranks[i].rank+`)<img id="USER-`+btoa(fetchedData.users.usernames[i])+`" class="icon-no-inv frenIMG" src="`+fetchedData.users.profilePictures[i]+`">    <button class="addFren">add friend</button></a></li>`
}
if(fetchedData.users.ranks[i].color == "#ff0000") {
  document.getElementById("myUL").innerHTML += `
<li><a class="`+fetchedData.users.ranks[i].color+`Fren" href="javascript:"><span>`+fetchedData.users.usernames[i]+`</span> (`+fetchedData.users.ranks[i].rank+`)<img id="USER-`+btoa(fetchedData.users.usernames[i])+`" class="icon-no-inv frenIMG" src="`+fetchedData.users.profilePictures[i]+`">    <button class="addFren">add friend</button></a></li>`
}
if(fetchedData.users.ranks[i].color == "#000000") {
  document.getElementById("myUL").innerHTML += `
<li><a class="`+fetchedData.users.ranks[i].color+`Fren" href="javascript:"><span>`+fetchedData.users.usernames[i]+`</span> (`+fetchedData.users.ranks[i].rank+`)<img id="USER-`+btoa(fetchedData.users.usernames[i])+`" class="icon-no-inv frenIMG" src="`+fetchedData.users.profilePictures[i]+`">    <button class="addFren">add friend</button></a></li>`
}

if (fetchedData.users.ranks[i].color === "grey") {
 //console.log(fetchedData.users.usernames[i] + " " + i);
 document.getElementById("myUL").innerHTML += `
 <li><a style="color:`+fetchedData.users.ranks[i].color+`;" href="javascript:"><span>`+fetchedData.users.usernames[i]+`</span> (`+fetchedData.users.ranks[i].rank+`)<img id="USER-`+btoa(fetchedData.users.usernames[i])+`" class="icon-no-inv frenIMG" src="`+fetchedData.users.profilePictures[i]+`">    <button class="addFren">add friend</button></a></li>
 ` 
 }

}
}
},1500)
//document.getElementById("allUsers").innerHTML = "";

}
show("findPPL")

function findUser() {
var input, filter, ul, li, a, i, txtValue;
input = document.getElementById("findUser");
filter = input.value.toUpperCase();
ul = document.getElementById("myUL");
li = ul.getElementsByTagName("li");
for (i = 0; i < li.length; i++) {
    a = li[i].getElementsByTagName("a")[0];
    txtValue = a.textContent || a.innerText;
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
        li[i].style.display = "";
    } else {
        li[i].style.display = "none";
    }
}
}







function showSource(){;
var source = "<html>";
source += document.getElementsByTagName('html')[0].innerHTML;
source += "</html>";
//now we need to escape the html special chars, javascript has escape
//but this does not do what we want
source = source.replace(/</g, "&lt;").replace(/>/g, "&gt;");
//now we add <pre> tags to preserve whitespace
source = "<pre>"+source+"</pre>";
//now open the window and set the source as the content
sourceWindow = window.open('','Source of page','height=800,width=800,scrollbars=1,resizable=1');
sourceWindow.document.write(source);
sourceWindow.document.close(); //close the document for writing, not the window
//give source window focus
if(window.focus) sourceWindow.focus();
} 








function DriveDownload(drive_id) {
  notify("download", "Downloading file... ", 6000);
  
  window.open("https://drive.google.com/uc?export=download&id="+drive_id);
}


function openMaximizedWindow(url) {
const width = window.screen.availWidth;
const height = window.screen.availHeight;
const options = `width=${width},height=${height},top=0,left=0`;
window.open(url, '_blank', options);
}


function loadScript(src) {
var a = document.createElement("script");
a.src = src;
a.onload = function() {
debug_console.contentWindow.d.echo("Loaded: " + src);
}
document.body.appendChild(a);
//console.log("loaded: " + src);

}


function searchAndSortByTitle(inputTitle) {




var a = [];
for (let i = 0; i < fetchedData.store.length; i++) {
if(fetchedData.store[i] !== "") {
a.push(JSON.parse(atob(fetchedData.store[i])));
}
}
if (inputTitle == "") {
displayStore();
sortedStore = a;
return false;
}
// Given array of objects
const data = a;

if(inputTitle.toLowerCase() === "game"|| inputTitle.toLowerCase() === "app") {
  var filteredData = data.filter((item) => item.category.toLowerCase().includes(inputTitle.toLowerCase()))
} else {
  var filteredData = data.filter((item) => item.name.toLowerCase().includes(inputTitle.toLowerCase()))
}

// Filter the data based on the input title

// Sort the filtered data by title name in ascending order
const sortedData = filteredData.sort((a, b) => a.name.localeCompare(b.name));
sortedStore = sortedData;
displayStore(true);
return sortedData;
}

function searchAndSortByName(inputTitle) {




  var a = [];
  for (let i = 0; i < fetchedData.redeemables.length; i++) {
  if(fetchedData.redeemables[i] !== "") {
  a.push(JSON.parse(atob(fetchedData.redeemables[i])));
  }
  }
  if (inputTitle == "") {
  displayRedeemables();
  sortedShop = a;
  return false;
  }
  // Given array of objects
  const data = a;

  if(inputTitle.toLowerCase() === "theme"|| inputTitle.toLowerCase() === "cursor"||inputTitle.toLowerCase() === "rank") {
    var filteredData = data.filter((item) => item.type.toLowerCase().includes(inputTitle.toLowerCase()))
  } else {
    var filteredData = data.filter((item) => item.name.toLowerCase().includes(inputTitle.toLowerCase()))
  }

  // Filter the data based on the input title

  
  
  // Sort the filtered data by title name in ascending order
  const sortedData = filteredData.sort((a, b) => a.name.localeCompare(b.name));
  sortedShop = sortedData;
  displayRedeemables(true);
  return sortedShop;
  }


function changeDispType(val) {
  setting_conf.lib_display = val;
  loadInstalls(val);
}





function Fav(ind) {
  settings = true;

  localData.favs.push(ind);
  saveLocalData();
  notify("info","Added " + installs[ind].name + " to your favorites")

  setTimeout(function () {
    settings = false;
    loadInstalls(setting_conf.lib_display);
    }, 100)
}

function RMFav(ind) {
  settings = true;
notify("alert","removed " + installs[localData.favs[ind]].name + "from favs.");
  console.log(localData.favs);

  localData.favs.splice(ind, 1);

console.log(localData.favs);

saveLocalData();

setTimeout(function () {
  settings = false;
  loadInstalls(setting_conf.lib_display);
  }, 100)
}

function loadInstalls(dispType) {
document.getElementById("library-games").innerHTML = "";
document.getElementById("library-favs").innerHTML = "<h3>Favorites</h3>";
var classType = "";
if (dispType == "list") {
  classType = "list-game"
}else {
  classType = "game"
}
for (let i = installs.length - 1 ; i >= 0 ; i--) {


console.log(localData.favs.includes(i));
if (localData.favs.includes(i)) {
  document.getElementById("library-games").innerHTML += `
  <div onclick="Play('`+installs[i].fileName+`')" class="`+classType+`">
    <img  src="`+installs[i].img+`" class="`+classType+`-img" alt="">
     <h1 class="`+classType+`-name">`+installs[i].name+`</h1>
       <img src="`+streamingAssets.dots+`" class="`+classType+`-edit `+classType+`-set-img" alt="" onclick="Edit(`+i+`);">
  
       </div>
  `;
}else {
document.getElementById("library-games").innerHTML += `
<div onclick="Play('`+installs[i].fileName+`')" class="`+classType+`">
  <img  src="`+installs[i].img+`" class="`+classType+`-img" alt="">
   <h1 class="`+classType+`-name">`+installs[i].name+`</h1>
     <img src="`+streamingAssets.dots+`" class="`+classType+`-edit `+classType+`-set-img" alt="" onclick="Edit(`+i+`);">
     <img src="https://cdn.jsdelivr.net/gh/jackb0back/streamingAssets@main/OASISX/golden-star-icon-png.png" class="`+classType+`-edit `+classType+`-fav-img" alt="" onclick="Fav(`+i+`);">

     </div>
`;
}

}



for (let i = 0; i < localData.favs.length; i++) {
  console.log(installs[localData.favs[i]].name);
  document.getElementById("library-favs").innerHTML += `
<div onclick="Play('`+installs[localData.favs[i]].fileName+`')" class="`+classType+`">
  <img  src="`+installs[localData.favs[i]].img+`" class="`+classType+`-img" alt="">
   <h1 class="`+classType+`-name">`+installs[localData.favs[i]].name+`</h1>
     <img src="`+streamingAssets.dots+`" class="`+classType+`-edit `+classType+`-set-img" alt="" onclick="Edit(`+i+`);">
     <img src="https://icones.pro/wp-content/uploads/2022/05/icone-fermer-et-x-rouge.png" class="`+classType+`-edit `+classType+`-fav-img" alt="remove fav" onclick="RMFav(`+i+`);">

     </div>
`;
}



}

function uninstall(iID) {
if (confirm("Are you sure you whould like to uninstall this?")) {
//console.log("uninstalling...");
var d = installs[iID];
installs.splice(iID,1);
loadInstalls(setting_conf.lib_display);
document.getElementById("win"+iID).innerHTML = "<h1>Uninstalled: " + d.name + "</h1>";
notify("alert","uninstalled " + d.name);
setTimeout(function(){
saveLocalData();
},500)

}else {
//console.log("user said no :(");
}
}











function saveGameChanges(index) {
  //console.log(index);
  if (confirm("save changes?")) {
    installs[index].fileName = document.getElementById("win"+index+"_gameFile").value;
    saveInstalls();
    notify("settings","saved changes.");
    loadInstalls(setting_conf.lib_display);
  }
}









function Edit(d) {
settings = true;
var da = installs[d];
//console.log(da);
newWindow(da.name+ " - settings",`
<div id="win`+d+`">
<button style="margin-top: 10px;" class="css-button" onclick="saveGameChanges(`+d+`)">save changes</button>
<button style="margin-top: 10px;background-color:red;" class="css-button" onclick="uninstall(`+d+`)">uninstall</button>
<br>
<img class="game-img" style="margin-top:8px;" src="`+da.img+`">
<p>category: `+da.category+`</p>
<p>description: "`+da.desc+`"</p>
Game file: `+setting_conf.gamesDir+`
<input id="win`+d+`_gameFile" type="text" value="`+da.fileName+`">

</div>
`,600,400);


setTimeout(function () {
settings = false;
}, 100)
}



function saveInstalls() {
addLocalData("installs","[]");
localData.installs = installs;
saveLocalData();
}

function install(app,download) {

if(installs == undefined) {
installs = [];
localData.installs = [];
}

//console.log(JSON.parse(atob(app)));
installs.push(JSON.parse(atob(app)));
if (download) {
DriveDownload(JSON.parse(atob(app)).download);
}
loadInstalls(setting_conf.lib_display);
saveInstalls();
notify("download","added " + JSON.parse(atob(app)).name + " to your library."); 
}

function Play(src) {
if (settings) return;
localStorage.setItem("OAX_launchkey",btoa(src));
openMaximizedWindow(setting_conf.gamesDir+src);
}


function saveLocalData() {
localStorage.setItem("OAX_localD",btoa(JSON.stringify(localData)));
}

function addLocalData(name,data) {
var d = data;
eval(`localData.`+name+` = '` + d + `';`);
//console.log(localData);
localStorage.setItem("OAX_localD",btoa(JSON.stringify(localData)));
}



function changeSaveDataLoc(val) {
//console.log(val);
}



function newWindow(title,cont,w,h) {

var eg = new jswindow({title: title, icon: ""});
            eg.innerWindow.innerHTML = cont;
            eg.open({width: w, height: h});

}



function hideAllNavs() {
  for (let i = 0; i < navs.length; i++) {
    navs[i].style.display = "none";
  }
}

function DisplayNav(index) {
  hideAllNavs();
navs[currentNav].style.display = "none";
currentNav = index;
navs[currentNav].style.display = "block"
//console.log("displayed " + navs[currentNav].id + " currentNav: " + currentNav);

if(currentNav == 1) {
if(tryLoad.store && !loaded.store) {
  getStore();
}
}
if(currentNav == 10) {
  if(tryLoad.redeemables && !loaded.redeemables) {
    getRedeemables();
  }
  }
if(currentNav == 5) {
if(tryLoad.news && !loaded.news) {
  getNews();
}
}
if(currentNav == 8) {
if(tryLoad.themes && !loaded.themes) {
  getThemes();
}
}
}



function doGetUsernames() {
getUsernames().then(result => {
    if (result.result === 'success') {
      //console.log(result);
      fetchedData.users = result;
      
      for (let i = 0; i < fetchedData.users.ranks.length; i++) {
        if (isJsonString(fetchedData.users.ranks[i])) {
          fetchedData.users.ranks[i] = JSON.parse(fetchedData.users.ranks[i]);
          }else {
            fetchedData.users.ranks[i] = JSON.parse(cleanJSONfromSheet(fetchedData.users.ranks[i]));
          }
          
      }
        LoadFrens();
    } else {
      //console.log(result.message);
    
    }
  })
  .catch(error => {
    console.error(error);
  });   
}

document.getElementById("password").addEventListener("keyup", function(event) {
  if (event.key === "Enter") {
    document.getElementById(`cd`).innerHTML = `<h4 style='color:cyan;text-align: center;'>getting latest info...</h4>`; 
    getDatabaseURLS(function (){ setTimeout(function(){doLogin();},1500); });
  }
});

function reloadCss()
{
var links = document.getElementsByTagName("link");
for (var cl in links)
{
    var link = links[cl];
    if (link.rel === "stylesheet")
        link.href += "";
}
}

function loadProfile() {
if (loginData.account_data[4] == "yes") {
    isDev = true;
    document.getElementById("dev_btn").style.display = "block";
    document.getElementById("dev_storeEdit").style.display = "inline-block";

    loadScript(setting_conf.dev.DevFolder + "terminal_inj.js");
    setTimeout(function(){
      document.getElementById("devCLI").src = setting_conf.dev.DevFolder + "terminal.html?username=" + login_creds.username;
    },1000)
  }
  document.title = "OASIS X ("+loginData.account_data[0]+")";
  document.getElementById("pf_username").innerHTML = "<span>" + loginData.account_data[0]+ "</span>";
  document.getElementById("pfp_img").src = loginData.account_data[3];
  document.getElementById("profile-pfp").src = loginData.account_data[3];
  document.getElementById("profile-pfp-url").value = loginData.account_data[3];
  document.getElementById("profile-username").innerHTML = "<h1>" + loginData.account_data[0]+ "</h1>";
  document.getElementById("profile-date").innerHTML = "date created: " +loginData.account_data[2];
  document.getElementById("profile-dev").innerHTML = "is developer? " + isDev;
  document.getElementById("themes-css").value = "/*default*/ \n --gradient: none; \n --button-gradient: none; \n --thick-trim: 5px solid rgba(0,0,0,0.15); \n --trim: none; \n--background-color-body: #181818;\n  --text-color: white;\n  --background-color-top: #252525;\n  --background-color-sidebar: #252525;\n  --background-color-sidebar-button: #151515;\n  --background-color-icon: #333;\n  --background-color-play: #3c3c3c;\n  --background-color-game: #333;\n  --background-color-window: #151515;\n  --background-color-window-title: #555;\n  --sidebar-hover: #333;\n  --image-invert: 0;\n  --css-button: #333;\n  --background-color-game-play: #121212;\n  --news-background: #333;\n  --news-cont: #212121;"
  document.getElementById("profile-rank").innerHTML = "Rank: " + loginData.rank.rank;
  document.getElementById("profile-rank").style.fontFamily = "sans-serif";
  if (loginData.rank.rank === "VIP") {
    document.getElementById("logo").src = streamingAssets.viplogo;
    document.getElementById("login-logo").src = streamingAssets.viplogo;
  }else if (loginData.rank.rank === "Infinity") {
    document.getElementById("logo").src = 'https://i.ibb.co/CBpQLGW/Infinity-Logo.png'
    document.getElementById("login-logo").src = 'https://i.ibb.co/CBpQLGW/Infinity-Logo.png';
  }else if (loginData.rank.rank === "GOD") {
    document.getElementById("logo").src = 'https://i.ibb.co/48hnQ4J/GodLogo.png'
    document.getElementById("login-logo").src = 'https://i.ibb.co/48hnQ4J/GodLogo.png';
  }

  if (loginData.rank.rank != "User") {
    document.getElementById("sidead").style.display = 'none'
    for(let i = 2; i <=9; i++) {
      document.getElementById('adc'+i+'').style.display = 'none'
    }
  } else{
    document.getElementById("sidead").style.display = 'flex'
    for(let i = 2; i <=9; i++) {
      document.getElementById('adc'+i+'').style.display = 'block'
    }
  }
      
if(!isDev) {
  customcolors.style.display = 'none'
}
  
  



  for (let i = 0; i < loginData.ranks.length; i++) {
    document.getElementById("profile-ranks").innerHTML += `
    <option value="${btoa(JSON.stringify(loginData.ranks[i]))}">${loginData.ranks[i].rank}</option>
    `
  }
  document.getElementById("profile-ranks").value = btoa(JSON.stringify(loginData.rank));

  //document.getElementById("wallet-bal").innerHTML += loginData.wallet.credits;
  if(loginData.rank.color == "rainbow" || loginData.rank.color == "gold") {
    document.getElementById("profile-rank").classList.add(loginData.rank.color);
  }else {
  document.getElementById("profile-rank").style.color = loginData.rank.color;
  }
  if (loginData.rank.color == "gold") {
    //document.getElementById("profile-date").style.marginTop = "35px"
  }



  for(let i=0; i<=(JSON.parse(loginData.account_data[8]).length-1); i++) {

    const selectedItem = JSON.parse(loginData.account_data[8])[i]

    var itemType = selectedItem.type;

  if(itemType === "theme") {

    if (savedThemes.some(e => e.name === selectedItem.theme.name)) {
    } else {
      savedThemes.push(selectedItem.theme);
    }
    LoadSavedThemes();
  } else if (itemType === "cursor") {
    cursors = document.getElementById("theme-cursor")
    cursors.innerHTML += `<div class="cursor-item" onclick="setCursor(this)">
    <h4>`+selectedItem.name+`</h4><h4></h4>
    <img src="`+selectedItem.img+`" alt=""  class="cimg" > 
  </div>`
  }
  
}
doGetUsernames();
}


function saveProfile() {
loginData.account_data[3] = document.getElementById("profile-pfp-url").value;
//updateCell("D"+loginData.row,document.getElementById("profile-pfp-url").value,login_creds.password);
updateDataClient(login_creds.username,login_creds.password,"D"+loginData.row,loginData.account_data[3])


notify("settings","updated profile.");

loadProfile();
}


function LoadOnlineAssets() {
setTimeout(function(){getStore();
setTimeout(function(){getNews();},500);
setTimeout(function(){getThemes();},1000);  
setTimeout(function(){getRedeemables();},1500)},500)


 
  
}



function rdeem(v) {
  if (v == "Rank") {
    OpenredeemRank();
  } 
}


function doLogin() {
  getClientVer();
document.getElementById("cd").innerHTML = "<h4 style='color:cyan;text-align: center;'>logging in...</h4>";
login(document.getElementById("username").value, document.getElementById("password").value)
.then(result => {
if (result.result === 'success') {
  //console.log(result);
  document.getElementById("login").classList.add("fadeout");
  //document.getElementById("Cbal").dataset.countTo = loginData.wallet.credits;
  setTimeout(function(){
    document.getElementById("login").style.display = "none";
        const counters = document.querySelectorAll('.counter');
    counters.forEach((counter) => {
      const countTo = getNumber(counter);
      const animationDuration = getSpeed(counter);
    animate(counter, countTo, animationDuration);
    });
  },2000)
  loadProfile();

  LoadOnlineAssets();
  document.getElementById("themes-css").value = defaultTheme;

  login_creds.username = document.getElementById("username").value;
  login_creds.password = document.getElementById("password").value;
  loginHash = btoa(JSON.stringify(login_creds));
  document.getElementById("info-loginToken").innerHTML = "Login token: " + loginData.token;
  document.getElementById("info-lastLogin").innerHTML = "Last login: " + loginData.account_data[6];
  //alert("logged in!");
 loadSettings();
 showAd();
 console.log("logged in!");

 loggedIn = true;
  // Additional logic for a successful login

  
} else {
  console.log(result);
  document.getElementById("cd").innerHTML = "<h4 style='color:red;text-align: center;'>Error logging in.</h4>";
 
  // Additional logic for a failed login
}
})
.catch(error => {
console.error(error);
});
}

function loadStreamingAssets() {
document.getElementById("lib_img").src = streamingAssets.library;
document.getElementById("store_img").src = streamingAssets.download;
document.getElementById("fren_img").src = streamingAssets.frens;
document.getElementById("set_img").src = streamingAssets.settings;
document.getElementById("news_img").src = streamingAssets.news;
document.getElementById("dev_img").src = streamingAssets.dev;
//document.getElementById("chat_img").src = streamingAssets.chat;
document.getElementById("theme_img").src = streamingAssets.themes;
document.getElementById("library-settings").src = streamingAssets.settings;
document.getElementById("info_img").src = streamingAssets.info;
document.getElementById("shop_img").src = streamingAssets.store;
document.getElementById("plugin_img").src = streamingAssets.plugins;


// for (let i = 0; i <   document.getElementsByClassName("game-set-img").length; i++) {
//  document.getElementsByClassName("game-set-img")[i].src = streamingAssets.settings;
// }

changeFavIco(streamingAssets.x_icon);
}

function changeFavIco(ico) {
var link = document.querySelector("link[rel~='icon']");
if (!link) {
link = document.createElement('link');
link.rel = 'icon';
document.head.appendChild(link);
}
link.href = ico;
}

function convertToReadableTime(milliseconds) {
if (typeof milliseconds !== 'number' || milliseconds < 0) {
throw new Error('Input must be a non-negative number.');
}

if (milliseconds < 1000) {
return milliseconds + 'ms';
}

const seconds = milliseconds / 1000;
return seconds + 's';
}
/*
function notify(type, content,delay) {
var invert = 0;
if(notifying) {
close();
} 

setTimeout(function () {
notifying = true;
//var content = content
const notificationdiv = document.createElement('div')
const notification = document.getElementById('notification')
const timerdiv = document.getElementById("timerdiv");

if (delay == "" || delay == undefined || delay == 0) {
delay = 8000;
}
if (delay <p 1000) {
delay = 1000;
}

if (type == "download") {
type = "download.png"
invert = 1;
}
if (type == "alert") {
type = "alert.svg"
invert = 1;
}
document.documentElement.style.setProperty('--notif-delay', convertToReadableTime(delay));

timerdiv.style.transition = "width 5s ease"


notificationdiv.innerHTML="<img style='filter: invert("+invert+");fill: white;'id='typeimage' src='" + streamingAssetURL +type+ "'></img><p style='opacity: 1; margin: 20px;'>" + content + "</p> <a href='javascript:close();'class='close'>X</a>"
notificationdiv.id = "notifdiv"
notification.appendChild(notificationdiv)

notification.style.marginLeft = '69.6vw'
timerdiv.style.width = '0px'
setTimeout(function() {close();}, delay)
}, 500)
}

function close() {
//console.log('dees nuts');
notification.style.marginLeft = '125vw'; 
timerdiv.style.transition = "none"
timerdiv.style.backgroundColor = 'transparent'
timerdiv.style.width = '29vw'

setTimeout(function() {  const notification = document.getElementById('notification')
const notificationdiv = document.getElementById('notifdiv')
timerdiv.style.backgroundColor = "var(--background-color-window-title)"
notification.removeChild(notificationdiv)
notifying = false;
}, 700)


}
*/




function notify(type,message,dur) {

if (dur == undefined || dur == "" || dur == 0) {
dur = 3000;
}
if (dur < 1000) {
dur = 1000;
}

notyf.open({
type: type,
message: "<p class='n-msg'><strong>" + message + "</strong></p>",
duration: dur,
ripple: false,
dismissible: true
});
}

let popups = 0;

function popup(tit,cont) {
  const myPopup = new Popup({
    id: "popup",
    title: tit,
    content: cont,
    backgroundColor: "var(--background-color-top)",
    titleColor: "var(--text-color)",
    textColor: "var(--text-color)",
    closeColor: "red"
});

popups++;

myPopup.show();
}


function openAccC() {
  var l = {
    user: document.getElementById("username").value,
    password: document.getElementById("password").value
  }

  popup("Create Account",`
<p>Username</p><input type="text" id="accC_uname" value="`+l.user+`">
<p>Password</p><input type="password" style="margin-top:0;" id="accC_password" value="`+l.password+`"> 
<p>confirm pwd</p><input type="password" style="margin-top:0;" class="accC_cpassword" value="">
<h5>By clicking 'Next' you agree to <a href="http://oasisx.rf.gd/tos.html">these</a> terms and conditions<h5>  
<button class="css-button" onclick="tospop();">Next</button>

`);

}

function tospop() {

  popup("Create Account", `
  <iframe width="75%" height="200px;" src="https://docs.google.com/document/d/e/2PACX-1vQ68WQmmib3G_E9vKXVXQ03pIqEM6veC6NURP8sxraLwmeEZuOX0bKt6maXrQSfS9yi7nJlVv1t6lrw/pub?embedded=true"></iframe>
  <label><input type="checkbox" id="agreeBox"></input>I have read, understood, and agree to the terms of service.</label>
  <button id="createAcc" class="css-button" onclick="doCreate('accC_uname','accC_password','accC_cpassword');">Create Account</button>

  `)

  var createAcc = document.getElementById('createAcc');
var agreeBox = document.getElementById('agreeBox');

createAcc.style.display = "none";

agreeBox.addEventListener("change", () => {
  if (agreeBox.checked) {
    createAcc.style.display = "inline";
  } else {
    createAcc.style.display = "none";
  }
});
}



function OpenredeemRank() {

  popup("Redeem rank",`
  Rank Key <br> <input type="text" id="rRank_key" value="" placeholder="XXXX-XXXX-XXXX">
  <button onclick="RedeemRank(document.getElementById('rRank_key').value)" class="css-button">Redeem rank</button>
  `)
}




function openIntroMenu() {
popup("OASIS X intro",`
<button class="css-button" onclick="showIntro();">Play tutorial</button>
`);
}




function showIntro() {
  document.getElementsByClassName("popup fade-in")[0].remove();
  const driver = window.driver.js.driver;
  var navID = 0;
const driverObj = driver({
  showProgress: true,
  steps: [
    { element: '#sidebar', popover: { title: 'Sidebar', description: 'This is the main navagation sidebar, you use this to navagate diffrent pages.' } },
    { element: '#content', popover: { title: 'Content', description: 'This is where diffrent pages will be displayed.' } },
    { element: '#top', popover: { title: 'Top nav', description: 'This is the top navagation bar. If you click on your profile or username you can acsess your profile or if you click the gear icon you can open the OASIS X setings.' } },
    { element: '#library-settings', popover: { title: 'Library settings', description: 'This is the library settings, there you can import an existing library save file or export your library save file or delete your entire library.' } },
    { element: '#content', popover: { title: 'Game store', description: 'Here you can download items from the OASIS store, some items are VIP only execlusives that will be free later. clicking <b>install</b> adds the game to your library and <b>download and install</b> downloads the game files and adds it to your library.' } },
    { element: '#Shop-redeem', popover: { title: 'Shop - Redeeming items from store', description: 'Select the type of item here and click the button to open the product redeem menu, then you will be prompted with the product key' } },
    { element: '#content', popover: { title: 'Themes', description: "Here you can change OASIS X's theme and mouse cursor, The theme downloader allows you to save themes to your account or you can create your own theme with the textbox, Remember to click <b>Save theme</b> to save changes" } },
    { element: '#content', popover: { title: 'Social', description: "Here here is the social tab, here you can chat with other OASIS users with our direct messaging system and you can find users by clicking <b>Find users</b> and then click <b style='color:lime;'>Add friend</b> to add a user as a friend" } },
    { element: '#content', popover: { title: 'News', description: "Here is the news this is where you can find the latest post from OASIS's creators and our journalist you can learn more about the latest updates and new games" } },
    { element: 'body', popover: { title: 'All done!', description: "Thats all for this if you have any questions contact us on our website or look at the other resources in the help tab <b>(info --> help --> more)</b> " } },
  ],
  onNextClick:() => {
  navID++;
  console.log(navID);
  if (navID == 3) {
    DisplayNav(0);
  }
  if (navID == 4) {
    DisplayNav(1);
  }
  if (navID == 5) {
    DisplayNav(10);
  }
  if (navID == 6) {
    DisplayNav(8);
  }
  if (navID == 7) {
    DisplayNav(2);
  }
  if (navID == 8) {
    //news
    DisplayNav(5);
  }
  if (navID == 9) {
    DisplayNav(1);
  }
  driverObj.moveNext();
  }
},
);

driverObj.drive();
}

const customcolors = document.getElementById('customcolors');








function updateRainbowColor() {
  const colors = ['#ff0000', '#ff7f00', '#ffff00', '#00ff00', '#00ffff', '#0000ff', '#4b0082', '#9400d3', '#ff1493', '#ff69b4'];

  let index = 0;

  function changeColor() {
    document.documentElement.style.setProperty('--rainbow', colors[index]);
    index = (index + 1) % colors.length;
  }

  setInterval(changeColor, 700); // Change color every second
}

updateRainbowColor();eRainbowColor();

function showAd () {
  sideAd.style.right = '0px'
}

function hideAd () {
  sideAd.style.right = '-250px'
}



function saveRank() {
  if (atob(document.getElementById("profile-ranks").value) !== JSON.stringify(loginData.rank)) {
    console.log(JSON.parse(atob(document.getElementById("profile-ranks").value)))
    updateRank(JSON.parse(atob(document.getElementById("profile-ranks").value)));
  }

}

function SearchByType (cat) {
  const searchBar = document.getElementById("redeemables-search")
  const NavInd = document.getElementById("NavIndicator2")

  if(cat === "all") {
    searchBar.style.display = 'inline'
    NavInd.style.left = "36.5%"
    searchAndSortByName('');

  } else if(cat === "rank"){
    searchBar.style.display = 'none'
    NavInd.style.left = "45.55%"
    searchAndSortByName(cat);


  } else if(cat === "theme"){
    searchBar.style.display = 'none'
    NavInd.style.left = "54.5%"
        searchAndSortByName(cat);


  }else {
    searchBar.style.display = 'none'
    NavInd.style.left = "63.5%"
    searchAndSortByName(cat);

  }

}

function SearchByCategory (cat) {
  const searchBar = document.getElementById("store-search")
  const NavInd = document.getElementById("NavIndicator")

  if(cat === "all") {
    searchBar.style.display = 'inline'
    NavInd.style.left = "43%"
    searchAndSortByTitle('');

  } else if(cat === "game"){
    searchBar.style.display = 'none'
    NavInd.style.left = "50%"
    searchAndSortByTitle(cat);


  } else {
    searchBar.style.display = 'none'
    NavInd.style.left = "57%"

    searchAndSortByTitle(cat);
  }

}

function buy(price, name, obj,type) {
  popup("Purchase Item", `<h4>`+name+`</h4>
  <h3 style="color: limegreen;">`+price+`</h3>
  <h4>Please Select A Payment Type.</h4>
  <button onclick="payWithCashApp('`+price+`','`+name+`','`+obj+`','`+type+`');">Pay With CashApp <span style="color: cyan;">(Recommened)</span></button>
  <button onclick="payWithCash('`+price+`','`+name+`','`+obj+`','`+type+`');">Pay With Cash (In Person)</button>`);
}


function payWithCashApp(amt, name, obj, type) {


  popup(`Purchase With CashApp`, `
  <h5>Scan the QR code below to send your item amount to us.</h5>
  <h3 style="color: limegreen;">Your amount is: `+amt+`</h3>
  <img id="cdon" style="width: 150px;" src="https://cdn.jsdelivr.net/gh/jackb0back/streamingAssets@main/OASISX/cashapp (no name).png" alt="">
  <p>Input your email below so we can verify this is a legitimate purchase. <span style="color: red;">If you do not complete your E-mail, your purchase will be invalidated.</span></p>
  <input type="text" id="email-form" placeholder="Input Your Email..."></input>
  <p>Once you're done, press "Complete Purchase."</p>
  <button id="compPurch" style="" onclick="completePurchase('`+amt+`','`+name+`','cashapp','`+obj+`','`+type+`')">Complete Purchase</button>
  `)

  
var emailform = document.getElementById('email-form')

document.getElementById('compPurch').style.display = 'none'

emailform.addEventListener("keyup", () => {
    if(emailform.value === "") {
      document.getElementById('compPurch').style.display = 'none'
    } else {
      document.getElementById('compPurch').style.display = "inline";
    }
});
}

function payWithCash(amt, name, obj,type) {

  popup(`Purchase With Cash`, `
  <h5>You've chosen to do an in-person transaction. To view our policy on in-person transactions, visit <a style="color: blue" href="http://0asisx.rf.gd/tos.html">this page</a>.</h5>
  <h3 style="color: limegreen;">Your amount is: `+amt+`</h3>
  <p>To make your purchase, you'll work with one of our team members to complete it.</p>
  <p>Input your email below so we can verify this is a legitimate purchase. <span style="color: red;">If you do not complete your E-mail, your purchase will be invalidated.</span></p>
  <input type="text" id="email-form2" placeholder="Input Your Email..."></input>
  <p>Once you're done, press "Complete Purchase."</p>
  <button id="compPurchase2" style="" onclick="completePurchase('`+amt+`','`+name+`','cash','`+obj+`','`+type+`')">Complete Purchase</button>
  `)

  
var emailform = document.getElementById('email-form2')

document.getElementById('compPurchase2').style.display = 'none'

emailform.addEventListener("keyup", () => {
    if(emailform.value === "") {
      document.getElementById('compPurchase2').style.display = 'none'
    } else {
    document.getElementById('compPurchase2').style.display = "inline";
    }
});
}

function completePurchase (amt, name, method, obj, type) {
if (name==="ad"){
  if (method === "cashapp") {
    var email = document.getElementById("email-form").value;
    } else if (method === "cash") {
    var email = document.getElementById("email-form2").value;
    }

  if (method === "cashapp") {
    popup("Purchase Item", `<h2 style="margin: 0; color: green">Purchase Completed!</h2>
    <p>We'll send you and E-mail at <span style="color: purple">`+email+`</span> to confirm your purchase. Once we've verified and checked that the payment is complete, we'll send an email to get the images for your ad(s).</p>
    <h4 style="margin-bottom: 40px;">Thanks for purchasing to help keep OASIS X supported.</h4>`)
  } else if (method === "cash") {
    popup("Purchase Item", `<h2 style="margin: 0; color: green">Purchase Completed!</h2>
    <p>We'll send you and E-mail at <span style="color: purple">`+email+`</span> to confirm your purchase. Once the payment is complete, we'll send you an email to get the images for your ad(s).</p>
    <h4 style="margin-bottom: 40px;">Thanks for purchasing to help keep OASIS X supported.</h4>`)
  }

  let key = 'no key, this is an ad purchase ;)'
  let obj = 'no object, silly'

  var a = create(email,login_creds.username,amt,name,method,obj,key);

  Dev_logPurchase(a,'TEST')

}else {
  if (method === "cashapp") {
  var email = document.getElementById("email-form").value;
  } else if (method === "cash") {
  var email = document.getElementById("email-form2").value;
  }

  

  if (method === "cashapp") {
    popup("Purchase Item", `<h2 style="margin: 0; color: green">Purchase Completed!</h2>
    <p>We'll send you and E-mail at <span style="color: purple">`+email+`</span> to confirm your purchase. Once we've verified and checked that the payment is complete, we'll give you a redeemable code you can use to cash in your item.</p>
    <h4 style="margin-bottom: 40px;">Thanks for purchasing to help keep OASIS X supported.</h4>`)
  } else if (method === "cash") {
    popup("Purchase Item", `<h2 style="margin: 0; color: green">Purchase Completed!</h2>
    <p>We'll send you and E-mail at <span style="color: purple">`+email+`</span> to confirm your purchase. Once the payment is complete, we'll give you a redeemable code you can use to cash in your item.</p>
    <h4 style="margin-bottom: 40px;">Thanks for purchasing to help keep OASIS X supported.</h4>`)
  }
    
  var key = newKey();
  var a = create(email,login_creds.username,amt,name,method,obj,key);

  console.log(a);

  Dev_logPurchase(a,'TEST')




  if(type==="theme"){
    var b = {
      key: key,
      type: type,
      theme: obj
    }
  } else if(type==="rank") {
  var b = {
    key: key,
    type: type,
    rank: obj
  }
  } else if(type==="cursor") {
    var b = {
      key: key,
      type: type,
      cursor: obj
    }
  }
  
  var objkey = JSON.stringify(b);
  appendKey(objkey,'TEST')

  
      setTimeout(function(){
        if(name === "VIP Rank") {
          var viptheme = {
            key: newKey(),
            type: 'theme',
            theme: btoa('{"type":"theme","theme":{"name":"VIP Theme","theme":"LS1ncmFkaWVudDogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgcmdiYSgwLDAsMCwwKSAzNSUsIHJnYigyNTUsIDI1NSwgMCwwLjI1KSAxMDAlOyk7IAotLXRoaWNrLXRyaW06IDNweCBzb2xpZCBnb2xkOyAtLXRyaW06IDFweCBzb2xpZCBnb2xkOyAtLXRleHQtY29sb3I6IGdvbGQ7IC0tYmFja2dyb3VuZC1jb2xvci1ib2R5OiAjMTExMTExOyAtLWJhY2tncm91bmQtY29sb3ItdG9wOiAjMTMxMzEzOyAtLWJhY2tncm91bmQtY29sb3Itc2lkZWJhcjogIzEzMTMxMzsgLS1iYWNrZ3JvdW5kLWNvbG9yLXNpZGViYXItYnV0dG9uOiAjMDgwODA4OyAtLWJhY2tncm91bmQtY29sb3ItaWNvbjogIzIyMjsgLS1iYWNrZ3JvdW5kLWNvbG9yLXBsYXk6ICMzYzNjM2M7IC0tYmFja2dyb3VuZC1jb2xvci1nYW1lOiAjMjIyOyAtLWJhY2tncm91bmQtY29sb3Itd2luZG93OiAjMTUxNTE1OyAtLWJhY2tncm91bmQtY29sb3Itd2luZG93LXRpdGxlOiAjNTU1OyAtLXNpZGViYXItaG92ZXI6ICMxNjE2MTY7IC0taW1hZ2UtaW52ZXJ0OiAwOyAtLWNzcy1idXR0b246ICMyMzIzMjM7IC0tYmFja2dyb3VuZC1jb2xvci1nYW1lLXBsYXk6ICMxMjEyMTI7IC0tbmV3cy1iYWNrZ3JvdW5kOiAjMjIyOyAtLW5ld3MtY29udDogIzIxMjEyMTs="}}')
          }
        } else if(name === "Infinity Rank") {
          var viptheme = {
            key: newKey(),
            type: 'theme',
            theme: btoa('{"type":"theme","theme":{"name":"Infinity Theme","theme":"LS1ncmFkaWVudDogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgcmdiYSgwLDAsMCwwKSAxNSUsIHdoaXRlIDUwJSwgcmdiYSgwLDAsMCwwKSA4NSU7KTsKLS1idXR0b24tZ3JhZGllbnQ6IGxpbmVhci1ncmFkaWVudCh0byB0b3AsIHJnYmEoMjU1LDI1NSwyNTUsMC41KSAwJSwgcmdiYSgwLDAsMCwwKSA3MCU7KTsKLS10cmltOiAxcHggc29saWQgd2hpdGU7Ci0tYmFja2dyb3VuZC1jb2xvci1zaWRlYmFyOiByZ2IoMjUsMjUsMjUpOwotLWJhY2tncm91bmQtY29sb3ItdG9wOiByZ2IoMjUsMjUsMjUpOwotLXRoaWNrLXRyaW06IDNweCBzb2xpZCBncmF5OwotLXRleHQtY29sb3I6IGxpZ2h0Z3JheTsKICAtLWJhY2tncm91bmQtY29sb3ItYm9keTogIzE4MTgxODsKICAtLWJhY2tncm91bmQtY29sb3Itc2lkZWJhci1idXR0b246ICMxNTE1MTU7CiAgLS1iYWNrZ3JvdW5kLWNvbG9yLWljb246ICMyMjI7CiAgLS1iYWNrZ3JvdW5kLWNvbG9yLXBsYXk6ICMzYzNjM2M7CiAgLS1iYWNrZ3JvdW5kLWNvbG9yLWdhbWU6ICMyMjI7CiAgLS1iYWNrZ3JvdW5kLWNvbG9yLXdpbmRvdzogIzE1MTUxNTsKICAtLWJhY2tncm91bmQtY29sb3Itd2luZG93LXRpdGxlOiAjNTU1OwogIC0tc2lkZWJhci1ob3ZlcjogIzMzMzsKICAtLWNzcy1idXR0b246ICMyMTIxMjE7CiAgLS1iYWNrZ3JvdW5kLWNvbG9yLWdhbWUtcGxheTogIzEyMTIxMjsKICAtLW5ld3MtYmFja2dyb3VuZDogIzMzMzsKICAtLW5ld3MtY29udDogIzIxMjEyMTsKICAtLW1haW4tZm9udDogJ01vbnRzZXJyYXQnLCBzYW5zLXNlcmlmOw=="}}')
          }
        } else if(name === "GOD Rank") {
          var viptheme = {
            key: newKey(),
            type: 'theme',
            theme: btoa('{"type":"theme","theme":{"name":"God Theme","theme":"LS1ncmFkaWVudDogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgcmdiYSgwLDAsMCwwKSAxNSUsIHJlZCAzMCUsIG9yYW5nZSA0NSUsIHllbGxvdyA2MCUsIGxpbWVncmVlbiA3NSUsIGJsdWUgOTAlLCBwdXJwbGUgMTAwJSk7Ci0tYnV0dG9uLWdyYWRpZW50OiBsaW5lYXItZ3JhZGllbnQodG8gdG9wLCByZ2JhKDI1NSw1MCw1MCwwLjUpIDAlLCByZ2JhKDAsMCwwLDApIDcwJTspOwotLXRyaW06IDFweCBzb2xpZCByZ2IoMjAwLDEwMCwwKTsKLS1iYWNrZ3JvdW5kLWNvbG9yLXNpZGViYXI6IHJnYigxMCwxMCwxMCk7Ci0tYmFja2dyb3VuZC1jb2xvci10b3A6IHJnYigxMCwxMCwxMCk7Ci0tdGhpY2stdHJpbTogM3B4IHNvbGlkIHJnYmEoMjAwLDUwLDAsMC41KTsKLS10ZXh0LWNvbG9yOiBsaWdodGdyYXk7CiAgLS1iYWNrZ3JvdW5kLWNvbG9yLWJvZHk6ICMxMTE7CiAgLS1iYWNrZ3JvdW5kLWNvbG9yLXNpZGViYXItYnV0dG9uOiAjMTUxNTE1OwogIC0tYmFja2dyb3VuZC1jb2xvci1pY29uOiAjMTExOwogIC0tYmFja2dyb3VuZC1jb2xvci1wbGF5OiAjM2MzYzNjOwogIC0tYmFja2dyb3VuZC1jb2xvci1nYW1lOiAjMTExOwogIC0tYmFja2dyb3VuZC1jb2xvci13aW5kb3c6ICMxMTE7CiAgLS1iYWNrZ3JvdW5kLWNvbG9yLXdpbmRvdy10aXRsZTogIzMzMzsKICAtLXNpZGViYXItaG92ZXI6ICMzMzM7CiAgLS1jc3MtYnV0dG9uOiAjMjEyMTIxOwogIC0tYmFja2dyb3VuZC1jb2xvci1nYW1lLXBsYXk6ICMxMjEyMTI7CiAgLS1uZXdzLWJhY2tncm91bmQ6ICMzMzM7CiAgLS1uZXdzLWNvbnQ6ICMyMTIxMjE7CiAgLS1tYWluLWZvbnQ6ICdNb250c2VycmF0Jywgc2Fucy1zZXJpZjs"}}')
          }
        }
        var ptheme = JSON.stringify(viptheme);
        appendKey(ptheme,'TEST')
      },500)
    }
}



function create(email,username,amt,name,method,obj,key) {
  var a = {
      email: email,
      username: username,
      amount: amt,
      method: method,
      productName: name,
      obj: obj,
      key: key
  }
  return JSON.stringify(a);
}


function Dev_logPurchase(item,password) {
  const formData = new FormData();
  formData.append("action","dev");
  formData.append("password",password);
  formData.append("data",item);
  formData.append("type","purchase");
  const url1 = storeDatabase;
  fetch(url1,{
      method:'POST',
      body : formData
  })
  .then(res => res.json())
  .then(data => {
    //console.log(data);
     
  })
} 

function appendKey(item,password) {
  const formData = new FormData();
  formData.append("action","dev");
  formData.append("password",password);
  formData.append("data",item);
  formData.append("type","rank");
  const url1 = storeDatabase;
  fetch(url1,{
      method:'POST',
      body : formData
  })
  .then(res => res.json())
  .then(data => {
    //console.log(data);
  })
} 

function buyAds() {
  /*popup("Purchase An Ad", `<h5>Unfortunately, online ad purchases have not been set up yet.</h5>
  <p>If you want an ad, you can talk to me or email me at jerrycantcode@gmail.com.</p><br>`)*/
  popup("Buy an ad", `<h5>Purchase an ad to promote anything on OASIS X.</h5>
  <button onclick="purchaseAds('$3','1')">Buy 1 ad <span style="color: limegreen; font-size: 23px;"> ($3)</span></button>
  <button onclick="purchaseAds('$7','3')">Buy 3 ads <span style="color: limegreen; font-size: 23px;"> ($7)</span></button>
  <button onclick="purchaseAds('$11','5')">Buy 5 ads <span style="color: limegreen; font-size: 23px;"> ($11)</span></button>`)
}

function purchaseAds(price,amt) {
  popup("Buy an ad", `<h5>Please select payment for your <span style="color: green;">`+amt+`</span> ads.</h5>
  <button onclick="payWithCashApp('`+price+`','ad','','ad');">Pay With CashApp <span style="color: cyan;">(Recommened)</span></button>
  <button onclick="payWithCash('`+price+`','ad','','ad');">Pay With Cash (In Person)</button>`)
}




function loadRankStore() {
  DisplayNav(10);
  document.getElementById("redeemables-search").value = "Doesnt Like Ads";
  searchAndSortByName("Doesnt Like Ads");
}

function makeid(length) {
  let result = '';
  const characters = '123456789123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const charactersLength = characters.length;
  let counter = 0;
  while (counter < length) {
result += characters.charAt(Math.floor(Math.random() * charactersLength));
   counter += 1;
}
return result;
}

function newKey() {
  return makeid(4)+'-'+makeid(4)+'-'+makeid(4)
}