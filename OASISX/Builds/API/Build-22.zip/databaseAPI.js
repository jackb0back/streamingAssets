
var catalogLength = 100;
var news_per_page = 100;
var database = null;
var storeDatabase = null;


const resDatabase = "https://script.google.com/macros/s/AKfycbwh3--Rn9lRtVFGE-woauOOhuPXy_lE3Qyd_i37sD_Mss5QO6Pgv-WwgoyCoeSzwNaH7A/exec";
var loadedDBs = {
  store: false,
  user: false
}
if (localStorage.getItem("OAX_udb") !== undefined && localStorage.getItem("OAX_udb") !== null) {
  database = localStorage.getItem("OAX_udb");
  console.log("localDB url found");
  loadedDBs.user = true;
}else {
  console.error("local userDB not found");
 // getDatabaseURLS();
}
if (localStorage.getItem("OAX_sdb") !== undefined && localStorage.getItem("OAX_sdb") !== null) {
  storeDatabase = localStorage.getItem("OAX_sdb");
  console.log("localDB url found");
  loadedDBs.store = true;
}else {
  console.error("local storeDB not found");
  //getDatabaseURLS();
}
var loginData = [];
var fetchedData = {
    users: null,
    store: [],
    news: []
}
var tmp;
var newsTMP;
var db_conf = {
  showDeets: false,
}
var loaded = {
  store: false,
  themes: false,
  news: false,
  redeemables: false,
  cursors: false
}
var tryLoad = {
  store: false,
  themes: false,
  news: false,
  redeemables: false,
  cursors: false
}


function getDatabaseURLS(callback) {
  var lu = false;
  var su = false;
  resDB_getVal("D2",function (d) {
    //user database
    lu = true;
    var str = removeCharactersBeforeAt(d[0]);
    console.log("user database URL: " + str);
    database = str;
    if (str !== database) {
      console.log("new URL");
    }
    loadedDBs.user = true;
    localStorage.setItem("OAX_udb",str);
    if (su) {
      if (typeof callback === 'function') {
        callback();
      }
    }
});
resDB_getVal("D3",function (d) {
  //store database
  su = true;
  var str = removeCharactersBeforeAt(d[0]);
  console.log("store database URL: " + str);
  storeDatabase = str;
  if (str !== storeDatabase) {
    console.log("new URL");
  }
  loadedDBs.store = true;
  localStorage.setItem("OAX_sdb",str);
  if (lu) {
    if (typeof callback === 'function') {
      callback();
    }
  }
});


}


function resDB_getVal(val, callback) {
  const formData = new FormData();
  formData.append("action", "getVal");
  const url1 = `${resDatabase}?key=${val}`;
  
  fetch(url1, {
    method: 'POST',
    body: formData
  })
  .then(res => res.json())
  .then(data => {
   // console.log(data.flat());
    if (typeof callback === 'function') {
      callback(data.flat());
    }
  })
  .catch(error => {
    console.error('An error occurred:', error);
    if (typeof callback === 'function') {
      callback(data.flat());
    }
  });
}

function removeCharactersBeforeAt(inputString) {
  const atIndex = inputString.indexOf('@');
  
  if (atIndex !== -1) {
    return inputString.slice(atIndex + 1);
  } else {
    return inputString; // If "@" is not found, return the original string
  }
}



function resDB_Dev_editCell(cell,data,password) {
const formData = new FormData();
formData.append("action","dev");
formData.append("password",password);
formData.append("data",data);
formData.append("location",cell);
formData.append("d_action","add");
const url1 = resDatabase;
fetch(url1,{
    method:'POST',
    body : formData
})
.then(res => res.json())
.then(data => {
console.log(data);

}) 
}





function displayThemes() {
 document.getElementById("theme-store").innerHTML = "<h3>Theme downloader</h3>";

 for(let i = 0; i < fetchedData.themes.length; i++) {
  document.getElementById("theme-store").innerHTML += `
  <h4>`+fetchedData.themes[i].name+`</h4>
  <button class="css-button" onclick="customTheme(atob('`+fetchedData.themes[i].theme+`'))">try it out</button>
  <button class="css-button" onclick="saveTheme('`+fetchedData.themes[i].name+`',atob('`+fetchedData.themes[i].theme+`'))">Save theme</button>
  `
 }
 loaded.themes = true; 
}

function displayCursors() {
  for(let i = 0; i < fetchedData.cursors.length; i++) {
   document.getElementById("cursors").innerHTML += `
   <div class="cursor-item" onclick="setCursor(this)">
     <h4>`+fetchedData.cursors[i].name+`</h4><h4></h4>
     <img src="`+fetchedData.cursors[i].img+`" alt="" > 
   </div>`
  }
  loaded.cursors = true; 
 }
 function getCursors() {
  
  setTimeout(function () {
  getStoreVal("I2:"+"I100");
  setTimeout(function () {
    tryLoad.cursors = true;
      fetchedData.cursors = tmp.flat();
     tmp = null;
     var b = [];
     for (let i = 0; i < fetchedData.cursors.length; i++) {
      if(fetchedData.cursors[i] !== "" && fetchedData.cursors[i] !== " ") {
        b.push(JSON.parse(fetchedData.cursors[i]));
      }
     }
     fetchedData.cursors = b;
     // //console.log(fetchedData);
      displayCursors();
  }, 3000)
},6000);
}


function getThemes() {
  setTimeout(function () {
  getStoreVal("B2:"+"B250");
  setTimeout(function () {
    tryLoad.themes = true;
      fetchedData.themes = tmp.flat();
     tmp = null;
     var a = [];
     for (let i = 0; i < fetchedData.themes.length; i++) {
      if(fetchedData.themes[i] !== "" && fetchedData.themes[i] !== " ") {
        a.push(JSON.parse(fetchedData.themes[i]));
      }
     }
     fetchedData.themes = a;
     // //console.log(fetchedData);
      displayThemes();
  }, 2000)
},4000);
}



function Dev_editStoreCell(cell,data,password) {
  const formData = new FormData();
  formData.append("action","devEdit");
  formData.append("cell",cell);
  formData.append("data",data);
  formData.append("password",password);
  const url1 = `${storeDatabase}`;
  fetch(url1,{
      method:'POST',
      body : formData
  })
  .then(res => res.json())
  .then(data => {
      console.log(data);
  })  
}


function updateClient() {

  notify("alert","fetching latest download url");

  const formData = new FormData();
  formData.append("action","getVal");
  const url1 = `${storeDatabase}?key=${"D3"}`;
  fetch(url1,{
      method:'POST',
      body : formData
  })
  .then(res => res.json())
  .then(data => {
      window.open(data);
  })  
}

function getClientVer(note) {
  const formData = new FormData();
  formData.append("action","getVal");
  const url1 = `${storeDatabase}?key=${"D2"}`;
  fetch(url1,{
      method:'POST',
      body : formData
  })
  .then(res => res.json())
  .then(data => {
     // //console.log(data);
     server_data.version = data[0][0];
    //console.log(server_data.version);
    document.getElementById("current-verison").innerHTML = "latest version: " + server_data.version;
  
    if (server_data.version !== client_data.version) {
      document.getElementById("info-update?").innerHTML = "yes"
      document.getElementById("info-update?").style.color = "lime";
      document.getElementById("info-update").style.display = "inline";
      popup("Update found",`
      <h5 style="color:lime;margin:0;">A new update is ready, We highly reccomend updating in order for things to work properly.</h5>
     <button class="css-button" onclick="updateClient()">Update</button>
      `)
      if(note)
      notify("alert","Update found!");
    }else {
      document.getElementById("info-update?").innerHTML = "no"
      document.getElementById("info-update?").style.color = "red";
      document.getElementById("info-update").style.display = "none";
      if(note)
      notify("alert","no updates found.");
    }

  })   
}


function getStoreVal(val) {
    const formData = new FormData();
    formData.append("action","getVal");
    const url1 = `${storeDatabase}?key=${val}`;
    fetch(url1,{
        method:'POST',
        body : formData
    })
    .then(res => res.json())
    .then(data => {
       // //console.log(data);
        tmp = data;
    })   
}

function isJsonString(str) {
  try {
    JSON.parse(str);
  } catch (e) {
    return false;
  }
  return true;
}
//var a = {name:"Test123",img:"offline resources/favicon.png",download:"",desc:"HELLO WORLD"}
function displayStore(search) {
    document.getElementById("store-cat").innerHTML = "";
  if (!search) {
    for (let i = fetchedData.store.length - 1; i >= 0; i--) {
      var isValid = false;
      var data = atob(fetchedData.store[i]);
      if (isJsonString(data)) {
          isValid = true;
          data = JSON.parse(data);
      }

      if (isValid) {

         document.getElementById("store-cat").innerHTML += `
<div class="bigApp">
<div class="app">
<img src="`+data.img+`" alt="" class="appImg">
<div class="appDesc">
<h3 class="rbow">`+data.name+`</h3>
<p class="categ">category: `+data.category+`</p><br>
<p>`+data.desc+`</p>
<br><br>
</div>
<button onclick="install('`+btoa(JSON.stringify(data))+`',true)" class="PLAY pdown">Download and Install</button>
<button onclick="install('`+btoa(JSON.stringify(data))+`',false)" class="PLAY pinstall" style="margin-right:235px;">Install</button>
<div class="MURICA" id="countdown`+i+`">
<?xml version="1.0" ?><svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M4 8V6a6 6 0 1 1 12 0v2h1a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2v-8c0-1.1.9-2 2-2h1zm5 6.73V17h2v-2.27a2 2 0 1 0-2 0zM7 6v2h6V6a3 3 0 0 0-6 0z"/></svg>

<h1>This app has been locked!</h1>
<h3>It will unlock when the timer reaches 0.</h3>
            <div class="box">
                <span class="num" id="day-box`+i+`">00</span>
                <span class="text">Days</span>
            </div>
            <div class="box">
                <span class="num" id="hr-box`+i+`">00</span>
                <span class="text">Hours</span>
            </div>
            <div class="box">
                <span class="num" id="min-box`+i+`">00</span>
                <span class="text">Minutes</span>
            </div>
            <div class="box">
                <span class="num" id="sec-box`+i+`">00</span>
                
                <span class="text">Seconds</span>
            </div>
            <p>Users ranked <a href="javascript:loadvip();">VIP</a> or above will get instant access to games.</p>
            <p>Users with the <a href="javascript:loadgamer();">Gamer</a> rank will get earlier access to games.</p>
        </div>
</div>

</div>
`
loaded.store = true;
}
}
  }else {
    for (let i = 0; i < sortedStore.length; i++) {
      var isValid = true;
      var data = sortedStore[i];

      if (isValid) {
        if(document.getElementById("countdown"+i+"")){
          alert('impostor.')
        }
  document.getElementById("store-cat").innerHTML += `
  <div class="bigApp">
<div class="app">
<img src="`+data.img+`" alt="" class="appImg">
<div class="appDesc">
<h3 class="rbow">`+data.name+`</h3>
<p>`+data.desc+`</p>
<br><br>
</div>
<button onclick="install('`+btoa(JSON.stringify(data))+`',true)" class="PLAY">Download and install</button>
<button onclick="install('`+btoa(JSON.stringify(data))+`',false)" class="PLAY" style="margin-right:235px;">Install</button>
<div class="MURICA" id="countdown`+i+`">
<?xml version="1.0" ?><svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M4 8V6a6 6 0 1 1 12 0v2h1a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2v-8c0-1.1.9-2 2-2h1zm5 6.73V17h2v-2.27a2 2 0 1 0-2 0zM7 6v2h6V6a3 3 0 0 0-6 0z"/></svg>
<h1>This app has been locked!</h1>
<h3>It will unlock when the timer reaches 0.</h3>
            <div class="box">
                <span class="num" id="day-box`+i+`">00</span>
                <span class="text">Days</span>
            </div>
            <div class="box">
                <span class="num" id="hr-box`+i+`">00</span>
                <span class="text">Hours</span>
            </div>
            <div class="box">
                <span class="num" id="min-box`+i+`">00</span>
                <span class="text">Minutes</span>
            </div>
            <div class="box">
                <span class="num" id="sec-box`+i+`">00</span>
                
                <span class="text">Seconds</span>
            </div>
            <p>Users ranked <a href="javascript:loadvip();">VIP</a> or above will get instant access to games.</p>
            <p>Users with the <a href="javescript:loadgamer();">Gamer</a> rank will get earlier access to games.</p>
        </div>
</div>

        </div>
`
}
}
  }
  prepare(search);
}

function displayRedeemables(search) {
  document.getElementById("redeemables-cat").innerHTML = "";
if (!search) {
  for (let i = fetchedData.redeemables.length - 1; i >= 0; i--) {
    var isValid = false;
    var data = atob(fetchedData.redeemables[i]);
    if (isJsonString(data)) {
        isValid = true;
        data = JSON.parse(data);
    }

    if (isValid) {
document.getElementById("redeemables-cat").innerHTML += `
<div class="app">
              <img src="`+data.img+`" alt="" class="itemImg">
              <div class="itemDesc">
              <h3 class="rbow">`+data.name+`</h3>
              <p>Type: `+data.type+`</p>
              <p>`+data.desc+`</p>
              <br><br>
              </div>
              <button onclick="buy('`+data.price+`','`+data.name+`','`+btoa(JSON.stringify(data.obj))+`','`+data.type+`')" class="PLAY pdown">Purchase (`+data.price+`)</button>
            </div>
`
loaded.redeemables = true;
}
}
}else {
  for (let i = 0; i < sortedShop.length; i++) {
    var isValid = true;
    var data = sortedShop[i];

    if (isValid) {
document.getElementById("redeemables-cat").innerHTML += `
<div class="app">
              <img src="`+data.img+`" alt="" class="itemImg">
              <div class="itemDesc">
              <h3 class="rbow">`+data.name+`</h3>
              <p>Type: `+data.type+`</p>
              <p>`+data.desc+`</p>
              <br><br>
              </div>
              <button onclick="buy('`+data.price+`','`+data.name+`','`+btoa(JSON.stringify(data.obj))+`','`+data.type+`')" class="PLAY pdown">Purchase (`+data.price+`)</button>
            </div>
`
}
}
}
}


function getNews() {
    document.getElementById("news-cont").innerHTML = "<h2>Loading latest news</h2>";
    setTimeout(function(){
      tryLoad.news = true;
        getStoreVal("C2:"+"C"+catalogLength);
        setTimeout(function () {
            fetchedData.news = tmp.flat();
           tmp = null;
            //console.log(fetchedData);
            LoadNews();
        }, 2000)
    },2500)
}

var exampNews = {
    title: "Test news post",
    date: "7/29/2023",
    poster: "Jackboback",
    content: `<p>wiggler whipper</p>`
}

function LoadNews() {
  loaded.news = true;
  document.getElementById("news-cont").innerHTML = "";
    for (let i = fetchedData.news.length - 1; i >= 0; i--) {
      if (fetchedData.news[i] !== '') {
      
        
        var data = atob(fetchedData.news[i]);
        if (isJsonString(data)) {
            data = JSON.parse(data);
        }

        document.getElementById("news-cont").innerHTML += `
        
        <div class="news">
        <div class="newsDesc">
             <h2>`+data.title+`</h2>
             <h5>Posted by: `+data.poster+` on `+data.date+`</h5>
            <p>`+data.content+`</p>
            <br><br>
        </div>
        </div>
        
        `;
    }
}
}



function getStore() {
  document.getElementById("store-cat").innerHTML = "<h2>Loading store...</h2>";
  getStoreVal("A2:" + "A" + catalogLength);
  setTimeout(function () {
    tryLoad.store = true;
      try {
          fetchedData.store = tmp.flat();
      } catch (error) {
          console.error("Error occurred during flat():", error);
          //console.log("Executing custom flattening method...");
          fetchedData.store = customFlatten(tmp);
      }

      tmp = null;
      //console.log(fetchedData);
      displayStore();
      searchAndSortByTitle("");
  }, 2000);
}

function getRedeemables() {
  document.getElementById("redeemables-cat").innerHTML = "<h2>Loading redeemables...</h2>";
  getStoreVal("G2:" + "G" + catalogLength);
  setTimeout(function () {
    tryLoad.redeemables = true;
      try {
          fetchedData.redeemables = tmp.flat();
      } catch (error) {
          console.error("Error occurred during flat():", error);
          //console.log("Executing custom flattening method...");
          fetchedData.redeemables = customFlatten(tmp);
      }

      tmp = null;
      //console.log(fetchedData);
      displayRedeemables();
      searchAndSortByName("");
  }, 2000);
}

function customFlatten(arr) {
  return arr.reduce((result, item) => {
      if (Array.isArray(item)) {
          result.push(...customFlatten(item));
      } else {
          result.push(item);
      }
      return result;
  }, []);
}









function formatDate(inputDate) {
  const date = new Date(inputDate);
  const month = String(date.getUTCMonth() + 1).padStart(2, "0");
  const day = String(date.getUTCDate()).padStart(2, "0");
  const year = date.getUTCFullYear();
  return `${month}/${day}/${year}`;
}





function displayAccData() {
  var a = loginData.account_data;
  loginData.account_data[6] = formatDate(loginData.account_data[6]);
  var b = [];
  for (let i = 9; i < a.length; i++) {
    b.push(a[i]);
  }
var d = {
  username: a[0],
  password: a[1],
  token: loginData.token,
  date: a[2],
  pfp: a[3],
  otherData: b
}
document.getElementById("cd").innerHTML = "";
document.getElementById("cd").innerHTML += "<h4 style='color:lime;text-align: center;'>Logged in!</h4>";
if (db_conf.showDeets) {
document.getElementById("cd").innerHTML += "Login Token: " + d.token + "<br><br>";
document.getElementById("cd").innerHTML += "Username: " + d.username + "<br><br>";
document.getElementById("cd").innerHTML += "Password hash: " + d.password + "<br><br>";
document.getElementById("cd").innerHTML += "Date created: " + d.date + "<br><br>";
document.getElementById("cd").innerHTML += `Profile picture: <img style="width:35px;display:inline;" src="`+ d.pfp +`"><br><br>`;
document.getElementById("cd").innerHTML += `<p style="margin:0;color:`+loginData.rank.color+`">Rank: `+loginData.rank.rank+`</p><br>`
document.getElementById("cd").innerHTML += `isDev? ` + loginData.isDev + `<br><br>`;
document.getElementById("cd").innerHTML += "Credits: " + loginData.wallet.credits + "<br><br>";
document.getElementById("cd").innerHTML += "Other data: " + d.otherData + "<br><br>";
}



}





function doGetData(cell,password) {
  getCellData(password, cell)
  .then(function(cellData) {
    // Use the retrieved cell data
    //console.log('Cell data:', cellData);
  })
  .catch(function(error) {
    // Handle any errors that occurred during retrieval
    console.error('An error occurred:', error);
  });

}

function doCreate(uid,pid,cpid) {

  document.getElementsByClassName("popup-close")[document.getElementsByClassName("popup-close").length-1].click();

  if(document.getElementById(pid).value !== document.getElementsByClassName("accC_cpassword")[0].value) {
    console.log(document.getElementById(pid).value,document.getElementsByClassName("accC_cpassword")[0].value)
    notify("alert","passwords do not match");
    return;
  }else {
    notify("alert","createing account...")
  }


  createAccount(document.getElementById(uid).value,document.getElementById(pid).value).then(result => {
    if (result.result === 'success') {
      //console.log(result.message);
      notify("ok","Successfully created account! Welcome to OASIS X.");
      document.getElementById("username").value = document.getElementById(uid).value
      document.getElementById("password").value = document.getElementById(pid).value

      doLogin();
      jumpscare();
      // Additional logic for a successful account creation
    } else {
      //console.log(result.message);
      notify("alert",result.message);
      // Additional logic for a failed account creation
    }
  })
  .catch(error => {
    console.error('An error occurred during account creation:', error);
  });
}

function doLogin() {
    document.getElementById("cd").innerHTML = "<h4 style='color:yellow;text-align: center;'>logging in...</h4>";

  login(document.getElementById("username").value, document.getElementById("password").value)
  .then(result => {
    if (result.result === 'success') {
      //console.log(result);
     
     //alert("logged in!");
      // Additional logic for a successful login
    } else {
      console.log(result.message);
      document.getElementById("cd").innerHTML = "<h4 style='color:red;text-align: center;'>Error logging in.</h4>";
     
      // Additional logic for a failed login
    }
  })
  .catch(error => {
    console.error('An error occurred during login:', error);
  });
}

function cleanJSONfromSheet(jsonString) {
  // Replace backslashes with nothing to remove them
  const cleanedString = jsonString.replace(/\\/g, '');
  
  // Parse the cleaned JSON string
  const parsedJSON = JSON.parse(cleanedString);
  
  return parsedJSON;
}


function login(username, password) {
  const formData = new FormData();
  formData.append('action', 'login');
  formData.append('username', username);
  formData.append('password', password);

  const options = {
    method: 'POST',
    body: formData
  };

  return fetch(database, options)
    .then(response => response.json())
    .then(data => {
      console.log(data);
      if (data.Offline !== undefined) {
       document.getElementById("cd").innerHTML = `<h4 style="color:red;text-align: center;">OASIS X is offline. please come again later</h4>`
        return;
      }
      loginData = data;
      loginData.account_data = JSON.parse(loginData.account_data);
      loginData.account_data[2] = formatDate(loginData.account_data[2]);
      loginData.wallet = {
        credits: loginData.account_data[8]
      }
      loginData.ranks = JSON.parse(loginData.account_data[7]);
      if (loginData.account_data[4] == "yes") {
        loginData.isDev = true;
      }else {
        loginData.isDev = false;
      }
      if (isJsonString(loginData.account_data[5])) {
      loginData.rank = JSON.parse(loginData.account_data[5]);
      }else {
        loginData.rank = cleanJSONfromSheet(loginData.account_data[5]);
      }
      displayAccData();
      return data; // Return the login result to the caller
    })
    .catch(error => {
      console.error(error);
      return { 'result': 'error', 'message': 'An error occurred during login' };
    });
}

function createAccount(username, password) {
  const formData = new FormData();
  formData.append('action', 'createAccount');
  formData.append('username', username);
  formData.append('password', password);

  const options = {
    method: 'POST',
    body: formData
  };

  return fetch(database, options)
    .then(response => response.json())
    .then(data => {
      if (data.result === "Erorr") {
        popup("Error creating account.",data.message);
      }
      return data; // Return the account creation result to the caller
    })
    .catch(error => {
      console.error('An error occurred during account creation:', error);
      return { 'result': 'error', 'message': 'An error occurred during account creation' };
    });
}

function doGetUsernames() {
    getUsernames().then(result => {
        if (result.result === 'success') {
          //console.log(result);
          fetchedData.users = result;

          for (let i = 0; i < fetchedData.users.ranks.length; i++) {
            if (isJsonString(fetchedData.users.ranks[i])) {
              fetchedData.users.ranks[i] = JSON.parse(fetchedData.users.ranks[i]);
              }else {
                fetchedData.users.ranks[i] = JSON.parse(cleanJSONfromSheet(fetchedData.users.ranks[i]));
              }
              
          }


        } else {
          //console.log(result.message);
        
        }
      })
      .catch(error => {
        console.error(error);
      });   
}

function getUsernames() {
    const formData = new FormData();
    formData.append('action', 'getUsers');
  
    const options = {
      method: 'POST',
      body: formData
    };
  
    return fetch(database, options)
      .then(response => response.json())
      .then(data => {
        return data; // Return the update result to the caller
      })
      .catch(error => {
        console.error('An error occurred:', error);
        return { 'result': 'error', 'message': 'An error occurred' };
      });
  }


function updateDataClient(username, password, cellIndex, data) {
    const formData = new FormData();
    formData.append('action', 'update');
    formData.append('username', username);
    formData.append('password', password);
    formData.append('cell', cellIndex);
    formData.append('data', data);
  
    const options = {
      method: 'POST',
      body: formData
    };
  
    return fetch(database, options)
      .then(response => response.json())
      .then(data => {
        return data; // Return the update result to the caller
      })
      .catch(error => {
        console.error('An error occurred during data update:', error);
        return { 'result': 'error', 'message': 'An error occurred during data update' };
      });
  }
  




//DO NOT USE UPDATECELL IS BROKEN
        function updateCell(index,data,password) {
        // Create a new FormData object
const formData = new FormData();

// Add form data to the FormData object
formData.append('cellVal', index);
formData.append('data', data);
formData.append('password', password);
formData.append('action', 'update');
// Prepare the fetch request
//var url = 'https://script.google.com/macros/s/AKfycbySQjXF8m_f1T3QZFWLRUiqdU0EeaCnSBXnYaNDlWfXXVemOH3mmGj1NR28TwHh4YFt/exec';
var url = database;
var options = {
  method: 'POST',
  body: formData
};

// Send the form data using fetch
fetch(url, options)
.then(response => response.json())
.then(data => {
  return data; // Return the account creation result to the caller
})
.catch(error => {
  console.error('An error occurred during account creation:', error);
  return { 'result': 'error', 'message': 'An error occurred during account creation' };
});
        }






        

function RedeemRank(key) {
  console.log(key);
  document.getElementsByClassName("popup-close")[document.getElementsByClassName("popup-close").length-1].click();

  for (let i = 0;document.getElementsByClassName("popup fade-out").length; i++) {
    document.getElementsByClassName("popup fade-out")[i].remove()
  }


  notify("info","checking key...",3000);
  const formData = new FormData();
  formData.append('action', 'redeemRank');
  formData.append("username",login_creds.username);
  formData.append("password",login_creds.password);
  formData.append("row",loginData.row);
  formData.append('key',key)

  const options = {
    method: 'POST',
    body: formData
  };


  return fetch(storeDatabase, options)
    .then(response => response.json())
    .then(data => {
      console.log(data);
      if (data.valid) {
      notify("ok","Claimed item!",3000)
      }else {
        notify("alert","invalid item code",3000);
      }
      return data; // Return the update result to the caller
    })
    .catch(error => {
      console.error('An error occurred:', error);
      return { 'result': 'error', 'message': 'An error occurred' };
    });

}











function updateRank(newRank) {
  const formData = new FormData();
  formData.append("username",login_creds.username);
  formData.append("password",login_creds.password);
  formData.append('action', 'updateRank');
  formData.append("newRank", JSON.stringify(newRank));

  const options = {
    method: 'POST',
    body: formData
  };

  return fetch(database, options)
    .then(response => response.json())
    .then(data => {
      notify("settings","Changed rank, reload to see effects");
      return data; // Return the update result to the caller
    })
    .catch(error => {
      console.error('An error occurred:', error);
      return { 'result': 'error', 'message': 'An error occurred' };
    });
}

