var plugins = []
var enabledPlugins = [];
var localPlugins = localStorage.getItem("OAX_localPlugs");
var localPluginList = localStorage.getItem("OAX_enabledPlugs");
if (localPlugins !== null) {
    plugins = JSON.parse(localPlugins);
    setTimeout(function(){
      if(setting_conf.plugins_allowed){

        if (localPluginList !== null) {
          enabledPlugins = JSON.parse(localPluginList);
        }else {
          for (let i = 0; i < plugins.length; i++) {
            enabledPlugins.push(i);
          }
          savePlugins();
        }

      loadPlugins();
      }
    },1500)
    
}





function addPluginByURL(url) {

if (plugins.includes(url)) {
  notify("alert","plugin already added");
  return;
}

plugins.push(url);
savePlugins();
setTimeout(function(){
  window.location.reload();
},500)
}
function addPluginByFile() {
document.getElementById("pluginInput").click();
}




function savePlugins() {
    localStorage.setItem("OAX_localPlugs",JSON.stringify(plugins));
    localStorage.setItem("OAX_enabledPlugs",JSON.stringify(enabledPlugins));
}
document.getElementById('pluginInput').addEventListener('change', async function selectedFileChanged() {
  if (this.files.length === 0) {
    console.log('No file selected.');
    return;
  }

  const reader = new FileReader();
  reader.onload = function fileReadCompleted() {
    // when the reader is done, the content is in reader.result.
    console.log(reader.result);
    addPluginByURL(reader.result);
return;
  };
  reader.readAsText(this.files[0]);
  
  
});


function removePlugin(id) {
  plugins = plugins.filter((element, index) => index !== id);
  savePlugins();

  notify("alert","removed plugin, reload to take effect");
}

function togglePlugin(id,btn) {
  if (btn.classList[1] == "pen") {
    btn.classList.remove("pen");
    btn.classList.add("pdis");
  }else {
    btn.classList.remove("pdis");
    btn.classList.add("pen");
  }

  if (enabledPlugins.includes(id)) {
      
    enabledPlugins[enabledPlugins.indexOf(id)] = "no";
  }else {
      if (enabledPlugins.indexOf("no") !== -1) {
          enabledPlugins[enabledPlugins.indexOf("no")] = id;
      }else {
    enabledPlugins.push(id);
      }
  }

  savePlugins();

  notify("alert","Toggled plugin. reload for changes to take effect.");
  }

async function loadPlugins() {
  //document.getElementById("plugins").innerHTML = "";
    for (let i = 0; i < plugins.length; i++) {


        
      

        var pluginLoader = new ZipLoader(plugins[i]);

        pluginLoader.on( 'progress',function (event) {
            console.log( 'loading', event.loaded, event.total );
          });
          pluginLoader.on( 'load', function ( e ) {

            var pluginDat;
            if (Object.keys(pluginLoader.files).includes("plugin.json")){
              pluginDat = pluginLoader.extractAsJSON("plugin.json");
            }else {
              pluginDat = {
                "name": "unnamed",
                "ver": "N/A",
                "execOrder": false
            }
            }
            console.log(pluginDat);
            var ae = enabledPlugins.includes(i);
            if (ae) {
              ae = "pen"
            }else {
              ae = "pdis"
            }
            document.getElementById("plugins").innerHTML += `
            <div id="plugin_`+i+`" class="plugin">
            <h3 class="plugin_name">`+pluginDat.name+`</h3> <button onclick="if(confirm('remove plugin?')){removePlugin(`+i+`);document.getElementById('plugin_`+i+`').remove();}" style="padding:5px !important;" class="css-button pdis">remove</button>
          <br>
            <h4 class="plugin_ver">v`+pluginDat.ver+`</h4>
            <br>
            src: <input class="plugin_src" type="text" value="`+plugins[i]+`" readonly>
            <br>
            <button onclick="togglePlugin(`+i+`,this)" class="css-button `+ae+`">Toggle</button>
          </div>
            `



            console.log("loaded: " + plugins[i], "id: " + i);

            if (pluginDat.execOrder !== false) {
             // pluginLoader.files = pluginDat.execOrder;
             
            }

            Object.keys(pluginLoader.files).forEach( function ( filename ) {
              console.log(filename);
                console.log(filename.endsWith(".js"));
                if (filename.endsWith(".js")) {
                  
      if (enabledPlugins.includes(i)) {

                    var ss = pluginLoader.extractAsBlobUrl(filename,'text/javascript');
                    var s = document.createElement("script");
                    s.src = ss;
                    console.log(s);
                    document.body.appendChild(s);
      }



                }

                document.getElementById('pluginInput').addEventListener('change', async function selectedFileChanged() {
  if (this.files.length === 0) {
    console.log('No file selected.');
    return;
  }

  const reader = new FileReader();
  reader.onload = function fileReadCompleted() {
    // when the reader is done, the content is in reader.result.
    console.log(reader.result);
    addPluginByURL(reader.result);

  };
  reader.readAsText(this.files[0]);
  
  
});
            } );
            
            
    
        } );
        

        pluginLoader.load();
        await new Promise(r => setTimeout(r, 500));
  }
}




function testP() {
  var bb = new Xplugins.navContent("Cursors","<h1>test</h1>");
  var aa = new Xplugins.navButton("Cursors","http://127.0.0.1:5500/streamingAssets/cursors/Defaullt.png","Xplugin_content_Cursors");
  
}


//plugin API

var Xplugins = {
  navButton: function(name,img,elmID) {
    this.name = name;
    this.img = img;
    this.elm = document.getElementById("nplugin"+elmID);
    this.buttonElm = document.createElement("li");
    this.buttonElm.id = "nplugin_"+name+"";
    this.buttonElm.innerHTML = `
    <a href="javascript:hideAllNavs();show('`+elmID+`')"><button id="button-`+name+`">`+name+`</button> <img id="`+name+`_img" class="icon" src="`+img+`"></a>
    `
    document.getElementById("snav").appendChild(this.buttonElm);
  },
  navContent: function(name,content) {
    this.name = name;
    this.navElm = document.createElement("div");
    navs.push(this.navElm);
    this.navElm.id = "Xplugin_content_"+name;
    this.navID = navs.length;
    this.navElm.classList.add("cont");
    this.navElm.innerHTML = content;
    document.getElementById("content").appendChild(this.navElm);
  }
}