var Xapi = {
  connected: false,
  onlineData: {
      storeDB: "offline",
      UserDB: "offline",
      resDB: "https://script.google.com/macros/s/AKfycbxCp2xdYDtrj2s6itVT4dcqOTZOLGBGx7H7lE8VTsirpG0pn23HArKpBwhxXgBORnDE/exec"
  },
  //Connect to the resDB and get latest info + check if able to connect
  connect: async function() {
      var lu = false;
      var su = false;
      Xapi.misc.resDB_getVal("D2",function (d) {
        //user database
        lu = true;
        var str = Xapi.misc.removeCharactersBeforeAt(d[0]);
        console.log("user database URL: " + str);
        if (str !== Xapi.onlineData.UserDB) {
        //  console.log("new URL");
        }
        
        Xapi.onlineData.UserDB = str;
        if (su) {
          if (typeof callback === 'function') {
            callback();
          }
        }
    });
    Xapi.misc.resDB_getVal("D3",function (d) {
      //store database
      su = true;
      var str = Xapi.misc.removeCharactersBeforeAt(d[0]);
      console.log("store database URL: " + str);
      Xapi.onlineData.storeDB = str;
      if (str !== Xapi.onlineData.storeDB) {
       // console.log("new URL");
      }
     // loadedDBs.store = true;
     // localStorage.setItem("OAX_sdb",str);
      if (lu) {
        if (typeof callback === 'function') {
          callback();
        }
      }
    });
    

    while (true) {
      if (Xapi.onlineData.storeDB !== "offline") {
          Xapi.connected = true;
          console.log("Connected!");
          return;
      }

      await new Promise(resolve => setTimeout(resolve,100))
    }
    
  },
  //store database connection
  storeConnection: function() {
      this.data = "";
      this.dataHis = [];
      this.getVal = async function(val) {

          while (Xapi.connected !== true) {
              // You can add a delay here if needed
              await new Promise(resolve => setTimeout(resolve, 100)); 
            }

          const formData = new FormData();
          formData.append("action","getVal");
          const url1 = `${Xapi.onlineData.storeDB}?key=${val}`;
          fetch(url1,{
              method:'POST',
              body : formData
          })
          .then(res => res.json())
          .then(data => {
             // //console.log(data);
              this.data = data;
              this.dataHis.push(data);
              console.log(this.data);
          }) 
      },
      this.getAds = async function(num) {
        while (Xapi.connected !== true) {
          // You can add a delay here if needed
          await new Promise(resolve => setTimeout(resolve, 100)); 
        }
        var adData = null;
        const formData = new FormData();
        formData.append("action","getAds");
        formData.append("ads",num);
        const url1 = Xapi.onlineData.storeDB;
        fetch(url1,{
            method:'POST',
            body : formData
        })
        .then(res => res.json())
        .then(data => {
           // //console.log(data);
            this.data = data;
            this.dataHis.push(data);
            adData = data;
            console.log(this.data);
        });
        while (adData == null) {
          // You can add a delay here if needed
          await new Promise(resolve => setTimeout(resolve, 100)); 
        }
        return adData;
      }
  },
  //user database connection
  UserConnection: function() {
      this.loginData;
      this.authenticated = false;
      this.gu = async function() {
        const formData = new FormData();
        formData.append('action', 'getUsers');
      
        const options = {
          method: 'POST',
          body: formData
        };
      
        return fetch(Xapi.onlineData.UserDB, options)
          .then(response => response.json())
          .then(data => {
            return data; // Return the update result to the caller
          })
          .catch(error => {
            console.error('An error occurred:', error);
            return { 'result': 'error', 'message': 'An error occurred' };
          });
      }
      this.loadUsers = async function() {
        this.gu().then(result => {
          if (result.result === 'success') {
            //console.log(result);
            var fetchedData;
            fetchedData.users = result;
  
            for (let i = 0; i < fetchedData.users.ranks.length; i++) {
              if (isJsonString(fetchedData.users.ranks[i])) {
                fetchedData.users.ranks[i] = JSON.parse(fetchedData.users.ranks[i]);
                }else {
                  fetchedData.users.ranks[i] = JSON.parse(cleanJSONfromSheet(fetchedData.users.ranks[i]));
                }
                
            }
            console.log(fetchedData);
  
          } else {
            //console.log(result.message);
          
          }
        })
        .catch(error => {
          console.error(error);
        });  
      }
      this.login = async function(username,password) {
          while (Xapi.connected !== true) {
              // You can add a delay here if needed
              await new Promise(resolve => setTimeout(resolve, 100)); 
            }
          const formData = new FormData();
          formData.append('action', 'login');
          formData.append('username', username);
          formData.append('password', password);
            var ran = false;
          const options = {
            method: 'POST',
            body: formData
          };
        
          return fetch(Xapi.onlineData.UserDB, options)
            .then(response => response.json())
            .then(data => { 
              this.loginData = data;
              this.loginData.loggedIn = true;
              this.loginData.account_data = JSON.parse(this.loginData.account_data);
              this.loginData.account_data[2] = Xapi.misc.formatDate(this.loginData.account_data[2]);
              this.loginData.wallet = {
                credits: this.loginData.account_data[8]
              }
              if (this.loginData.account_data[4] == "yes") {
                this.loginData.isDev = true;
              }else {
                this.loginData.isDev = false;
              }
              if (Xapi.misc.isJsonString(this.loginData.account_data[5])) {
              this.loginData.rank = JSON.parse(this.loginData.account_data[5]);
              }else {
                this.loginData.rank = Xapi.misc.cleanJSONfromSheet(this.loginData.account_data[5]);
              }
              this.authenticated = true;
              console.log(true);
              ran = true;
              return data; // Return the login result to the caller
            })
            .catch(error => {
              this.authenticated = "failed";
              ran = true;
              console.error('An error occurred during login:', error);
              return { 'result': 'error', 'message': 'An error occurred during login' };
            });

            
      }
      
  },
  //Helper functions
  misc: {
      isJsonString: function(str) {
          try {
            JSON.parse(str);
          } catch (e) {
            return false;
          }
          return true;
        },
      resDB_getVal:function (val, callback) {
          const formData = new FormData();
          formData.append("action", "getVal");
          const url1 = `${Xapi.onlineData.resDB}?key=${val}`;
          
          fetch(url1, {
            method: 'POST',
            body: formData
          })
          .then(res => res.json())
          .then(data => {
           // console.log(data.flat());
            if (typeof callback === 'function') {
              callback(data.flat());
            }
          })
          .catch(error => {
            console.error('An error occurred:', error);
            if (typeof callback === 'function') {
              callback(data.flat());
            }
          });
        },
        removeCharactersBeforeAt: function(inputString) {
          const atIndex = inputString.indexOf('@');
          
          if (atIndex !== -1) {
            return inputString.slice(atIndex + 1);
          } else {
            return inputString; // If "@" is not found, return the original string
          }
        },
        formatDate: function(inputDate) {
          const date = new Date(inputDate);
          const month = String(date.getUTCMonth() + 1).padStart(2, "0");
          const day = String(date.getUTCDate()).padStart(2, "0");
          const year = date.getUTCFullYear();
          return `${month}/${day}/${year}`;
        },
        cleanJSONfromSheet: function(jsonString) {
          // Replace backslashes with nothing to remove them
          const cleanedString = jsonString.replace(/\\/g, '');
          
          // Parse the cleaned JSON string
          const parsedJSON = JSON.parse(cleanedString);
          
          return parsedJSON;
        }
  }
}