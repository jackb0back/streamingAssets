function testThing() {
    console.log("Deez");
}

alert("loaded script1");