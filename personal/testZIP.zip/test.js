function test() {
console.log("hello world");
}