
var FFmpegModule;



addEventListener('message', async ({ data }) => {
//    console.log("ffworker got msg: ",data);
    if (data.cmd == 'ping') {
    
        self.postMessage( {'res' : 'pong'});
        
    } else if (data.cmd == 'init') {
		try {
			if (WebAssembly.validate(new Uint8Array([0,97,115,109,1,0,0,0,1,5,1,96,0,1,123,3,2,1,0,10,10,1,8,0,65,0,253,15,253,98,11]))) {
				self.importScripts('ffmpeg-simd-nosab-1699985172.js');
			} else {
				self.importScripts('ffmpeg-nosab-1699985172.js');	    
			}
		} catch (e) {
			console.log("Failed to load ffmpeg (js)");
		}
	    
	    FFmpegModule = await FFmpegModuleCreate();
        self.postMessage({ 'cmd' : 'init', 'res' : 'ready' });

//	    console.log("ffworker init done");
    } else if (data.cmd == 'openfile') {
		
		FFmpegModule._openFile(data.args.fileHandleID, data.args.offset_h, data.args.offset_l, data.args.size_h, data.args.size_l, 0, data.args.ref);

    } else if (data.cmd == 'filereadres') {
    	
    	let bufflen = data.buff.length;
		var ptr = FFmpegModule._malloc(bufflen);
		FFmpegModule.HEAPU8.set(data.buff, ptr);
	    FFmpegModule._deliverFileHandleReadResult(data.reqID, ptr, bufflen);
	    FFmpegModule._free(ptr);
    	self.filereadresolve();
    } else if (data.cmd == 'startFFVideoDecoder') {
		var filename_str_ptr  = FFmpegModule.allocate(FFmpegModule.intArrayFromString(data.args.filename), FFmpegModule.ALLOC_NORMAL);
		
		var ffinfo_ptr = FFmpegModule._malloc(data.args.infobuff.length);
		FFmpegModule.HEAPU8.set(data.args.infobuff, ffinfo_ptr);
		
		FFmpegModule._startFFVideoDecoder(filename_str_ptr, data.args.vid, ffinfo_ptr);
		FFmpegModule._free(filename_str_ptr);
    
    } else if (data.cmd == 'getFFAudioData') {
		FFmpegModule._getFFAudioData(data.args.vid, data.args.reqid, data.args.offs_l, data.args.offs_h, data.args.scnt);
    } else if (data.cmd == 'getFFVideoDecoderFrame') {
		FFmpegModule._getFFVideoDecoderFrame(data.args.vid, data.args.reqid, data.args.ts);
    } else if (data.cmd == 'closeFFVideoDecoder') {
		FFmpegModule._closeFFVideoDecoder(data.args.vid);
    } else if (data.cmd == 'firstframe') {
		let h264filestream = FFmpegModule.FS.open("firstframe.h264", 'w+');
		let uarr = data.buff;
		FFmpegModule.FS.write(h264filestream, uarr, 0, uarr.length, 0);    	
    } else if (data.cmd == 'start_bg_encode2') {
    	var filename_str_ptr  = FFmpegModule.allocate(FFmpegModule.intArrayFromString(data.args.fn), FFmpegModule.ALLOC_NORMAL);
    	FFmpegModule._start_bg_encode2(data.args.rid, filename_str_ptr, data.args.width, data.args.height, data.args.fps, data.args.format, data.args.bitrate, data.args.pixformat, data.args.audiochannels);
		FFmpegModule._free(filename_str_ptr);
    } else if (data.cmd == 'queue_video_packet_mux') {
		var ptr = FFmpegModule._malloc(data.args.buff.length);
		FFmpegModule.HEAPU8.set(data.args.buff, ptr);
    	FFmpegModule._queue_video_packet_mux(data.args.rid, ptr, data.args.buff.length, data.args.iskey);
    } else if (data.cmd == 'set_h264_raw_colorspace') {
    	FFmpegModule._set_h264_raw_colorspace(data.args["p"],data.args["t"],data.args["m"],data.args["r"]);
    } else if (data.cmd == 'start_audio_frame_encode') {
    	var audbuff_ptr = FFmpegModule._malloc(data.args.buff.length);
        FFmpegModule.HEAPU8.set(data.args.buff, audbuff_ptr);
    	FFmpegModule._start_audio_frame_encode(data.args.rid, audbuff_ptr, data.args.buff.length);
    } else if (data.cmd == 'finish_bg_encode') {
    	FFmpegModule._finish_bg_encode(data.args.rid);
    }
});
