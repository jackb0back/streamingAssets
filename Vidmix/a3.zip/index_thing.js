
/*		if (window.location.href.indexOf("vidmix.app") != -1) {
			if (typeof SharedArrayBuffer === "undefined") {
				alert("SharedArrayBuffer missing!");
				window.location.href = "missingsupport.html";
			}
// 			if (navigator.userAgent.indexOf("iPhone") != -1) {
// 				window.location.href = "missingsupport.html";
// 			}
			if (window.safari !== undefined) {
				let safariOK = false;
				let uaparts = navigator.userAgent.split(" ");
				for (let ix = 0; ix < uaparts.length; ix++) {
					if (uaparts[ix].indexOf("Version/") == 0) {
						let vstr = uaparts[ix].substr(8); 
						let vparts = vstr.split(".");
						if (vparts.length >= 2) {
							let major = parseInt(vparts[0]); 
							let minor = parseInt(vparts[1]);
							alert("safari version: ",major,minor);
							if ((major >= 15) || (minor >= 4))
								safariOK = true;
						}
					}
				}
				if (!safariOK) {
					window.location.href = "missingsupport.html";				
				}				
			} else if ((navigator.userAgent.indexOf("Chrome") == -1) && (navigator.userAgent.indexOf("Firefox") == -1)) {
				alert("unknown browser");
				window.location.href = "missingsupport.html";
			}
		}
		*/
		
		function loadScript(src) {
			return new Promise(function (resolve, reject) {
				var s;
				s = document.createElement('script');
				s.src = src;
				s.onload = resolve;
				s.onerror = reject;
				document.head.appendChild(s);
			});
		}
		
		var FFmpegModule;
		var FFworker;

		async function startFF() {
				
			if ((typeof SharedArrayBuffer !== 'undefined') && (window.location.hash != "#nosab")) {
				try { 		
					if (WebAssembly.validate(new Uint8Array([0,97,115,109,1,0,0,0,1,5,1,96,0,1,123,3,2,1,0,10,10,1,8,0,65,0,253,15,253,98,11]))) {
			//			console.log("has SIMD, hardwareConcurrency: "+navigator.hardwareConcurrency);
						await loadScript("ffmpeg-simd-1705683713.js");
					} else {
			//			console.log("no SIMD, hardwareConcurrency: "+navigator.hardwareConcurrency);
						await loadScript("ffmpeg-1705683713.js");
					}
				} catch (e) {
					console.log("Failed to load ffmpeg (js)");
				}
					
				FFmpegModuleCreate().then(function(fmodule) {
					FFmpegModule = fmodule;
				
					FFmpegModule.FS.mkdir("/LayerAssets");
					FFmpegModule.FS.mount(FFmpegModule.FS.filesystems.PROXYFS, {
						root: "/LayerAssets/",
						fs: FS
					}, "/LayerAssets/");					

					_jsFFmpegModuleFinishedLoading();							
				}).catch(function(error) {
					alert("..." + error);
				});
			} else {
			 	FFworker = new Worker(OZIPS['ffbgworker.js']);
	 			FFworker.postMessage({"cmd":"init"});
	  			FFworker.addEventListener('message',function(event) {
					if (event.data.cmd == "init") {
						_jsFFWorkerFinishedLoading();
					}
	  			});


			}
			 
		}
		
		window.addEventListener('beforeunload', function (e) {
		  e.preventDefault();
		  e.returnValue = '';
		});
		
		function quoteMarkThatDoesntKillEmscripten() {
			return "\"";
		}
		
		function jsChromeVersion() {
		    var raw = navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./);

			if (raw) {
				return parseInt(raw[2], 10);
				
			}
			return 0;		
		}

		function jsIsOldChrome() {
		    var raw = navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./);
			if (raw) {
				var parsed = parseInt(raw[2], 10);
				if (parsed < 92)
					return 1;
			}
			return 0;
		}
		
		function receiveOpenedFile(file /*buffer,filename*/) {
			(async () => {
				var fnarg  = allocate(intArrayFromString(file.name),  ALLOC_NORMAL);
				if (_jsOpenFileNeedsCopy(fnarg)) {
					let buffer = await file.arrayBuffer();
					FS.writeFile("/dnd-"+file.name,new Uint8Array(buffer));
					const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
					const hashArray = Array.from(new Uint8Array(hashBuffer));
					const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
					var arg1  = allocate(intArrayFromString("/dnd-"+file.name),  ALLOC_NORMAL);
					var arg2  = allocate(intArrayFromString(hashHex),  ALLOC_NORMAL);
					_jsReceiveDragAndDropFile(-1,-1,-1,arg1,arg2);
					_free(arg1);
					_free(arg2);
				} else {
					if (typeof window.openFileHandles === 'undefined') {
						window.openFileHandles = {};
						window.openFiles = {};
					}
					let fid = _jsGetNextFileHandleID();
					window.openFiles[fid] = file;
	                let fsize_lo = file.size & 0x0fffffff;
    	            let fsize_hi = (file.size - fsize_lo) / 0x0fffffff;
					var argname  = allocate(intArrayFromString(file.name),  ALLOC_NORMAL);
					_jsReceiveDragAndDropFile(fid, fsize_lo, fsize_hi, argname, 0);
					_free(argname);
				}
				
				_free(fnarg);
			})();
		}
		
		if ('launchQueue' in window) {
//			console.log('File handling API is supported!');

			launchQueue.setConsumer(launchParams => {
				for (const f of launchParams.files) {
					(async (file) => {
//						console.log('${file.name} received');
						const blob = await file.getFile();
						var buffer = await blob.arrayBuffer();
						receiveOpenedFile(buffer,file.name);
					})(f);
				}
			});
		} else {
//			console.error('File handling API is not supported!');
		}

		
		if (console.loghistory === undefined) {
	
			function submitLogHistory() {
				if (console.errorsent === undefined) {
					console.errorsent = 1;
					setTimeout(() => {
						var s = "";
	
						console.loghistory.forEach((it) => {
							s += it.value + "\n";
						});
//						navigator.sendBeacon(window.beaconURL, s);
						var xhr = new XMLHttpRequest();
						xhr.open("POST", window.beaconURL, true);
						xhr.send(s);

					},500);
				}			
			};

			console.loghistory = [];
			function TS(){
				return (new Date).toLocaleString("sv", { timeZone: 'UTC' }) + "Z"
			}
			window.onerror = function (message, source, line, col, error) {
				console.loghistory.push({
				  type: "exception",
				  timeStamp: TS(),
				  value:  source + ":"+line +" "+message
				});
				if (console.errorsent === undefined) {	
					console.errorsent = 1;
//					navigator.sendBeacon(window.beaconURL, source + ":"+line +" "+message);			
					var xhr = new XMLHttpRequest();
					xhr.open("POST", window.beaconURL, true);
					let errs = "";
					try {
//						console.log("window.onerror");
						console.log(error);
						if (error) {
// 							console.log(error);
// 							console.log(error.stack);
							errs = error + " ::: " +error.stack;
						}
						else
							errs = "-";
					} catch (e) {
						errs = "?";
					}
//					console.log("window.onerror e: "+errs);
					xhr.send(source + ":"+line +":"+col+":"+message+" ; e: "+errs);
				}
				return false;
			}
			window.onunhandledrejection = function (e) {
				console.loghistory.push({
				  type: "promiseRejection",
				  timeStamp: TS(),
				  value: e.reason
				});
				submitLogHistory();
			} 

			function hookLogType(logType) {
				const original = console[logType].bind(console);
				return function(){
				  console.loghistory.push({ 
					type: logType, 
					timeStamp: TS(), 
					value: Array.from(arguments) 
				  });
				  original.apply(console, arguments);
				  if (logType == "error") {
					submitLogHistory();
				  }	
				}
			}

			['error', 'warn', 'debug'].forEach(logType=>{
				console[logType] = hookLogType(logType)
			});
		}       
	
        var canv = document.getElementById('canvas');

        var Module = {
            canvas: canv,
            preRun: [function() {
				FS.mkdir("/LayerAssets");
            }],
		    onRuntimeInitialized: function() {

		    	startFF();

				_jsSetupUIEventHandlers();
				
				
		    }
        };


		canv.style.width = window.innerWidth + "px";
		canv.style.height = window.innerHeight + "px";

		var devicePixelRatio = window.devicePixelRatio || 1;
		canv.width = window.innerWidth * devicePixelRatio;
		canv.height = window.innerHeight * devicePixelRatio;
        
        canv.addEventListener('webglcontextlost', function(e) {
			var xhr = new XMLHttpRequest();
			xhr.open("POST", window.beaconURL, true);
			xhr.send("webglcontextlost");        
			console.log("webglcontextlost");
		    e.preventDefault();
		}, false);
		
        canv.addEventListener('webglcontextrestored', function(e) {
			var xhr = new XMLHttpRequest();
			xhr.open("POST", window.beaconURL, true);
			xhr.send("webglcontextrestored");        
			console.log("webglcontextrestored");
		}, false);
        
	    (async () => {
// 		    let isIframe = window.self !== window.top;
// 	    	console.log("isIframe: ",isIframe);
// 	    	
// 	    	if (isIframe) {
// 		    	console.log("referrer: ",document.location.ancestorOrigins[0]);
// 	    	}
// 	    
	    	let mainScript = "index-02381ede1db7.js";
			if ((typeof SharedArrayBuffer === "undefined") || (window.location.hash == "#nosab")) {
				mainScript = "index-nosab-5010e84dde7a.js";
			}	    
			await loadScript(mainScript);

			gl = canv.getContext('webgl2');				
		
			lastVideoID = 0;
			videos = {};
			videoBlobs = {};
			videoObjectUrls = {};
			audioBuffers = {};

			fileparts = {};
			
		})();
		
		