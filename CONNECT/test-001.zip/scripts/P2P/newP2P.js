/** @global */


class PeerJSInstance {
    constructor(options) {
        /* CONFIG */
        this.enableLogs = true;
        this.selfID = generateUUID();
        this.signFunction = false;
        this.PeerJSConfig = {
            config: {
                iceServers: [ 
                    { url: 'stun:stun.l.google.com:19302' },
                    { url: 'stun:stun1.l.google.com:19302' },
                ]
            },
            debug: 2
        };
        Object.assign(this, options);
        /* END CONFIG */

        this.peerJS = null;
        this.instances = {};
        this.IsConnected = false;
        this.GlobalActions = {};
        this.GlobalEvents = {};
        this.promises = {};
        this.init();
    }

    log(message) {
        if (this.enableLogs) {
            console.log("[PeerJS] " + message);
        }
    }

    init() {
        this.log("Initializing PeerJSInstance...");
        let peer = new Peer(this.selfID, this.PeerJSConfig);

        peer.on("open", (id) => {
            this.log(`Connected under ID "${id}"`);
            this.IsConnected = true;
        });

        peer.on("connection", (conn) => this.newConnection(conn, false));

        this.NewAction("return", (key, ...args) => {
            this.resolvePromise(key, ...args);
        }, true);

        this.peerJS = peer;
    }

    async invokeEvent(name, ...args) {
        if (this.GlobalEvents[name]) {
            this.GlobalEvents[name].forEach(func => func(...args));
        }
    }

    async eventListener(name, func) {
        if (!this.GlobalEvents[name]) {
            this.GlobalEvents[name] = [];
        }
        this.GlobalEvents[name].push(func);
    }

    NewAction(actionName, func, isGlobal = false) {
        let action = {
            name: actionName,
            // FIX: Using rest parameters (...args) instead of the undefined 'arguments' object
            func: (...args) => {
                func(action, ...args);
            },
            isGlobal: isGlobal
        };

        if (isGlobal) {
            this.GlobalActions[actionName] = action;
        }
        return action;
    }

    newPromise(timeout) {
        let prom = {
            key: generateUUID(),
            promise: null,
            resolve: null,
            reject: null,
            timeout: null,
            timeOutClear: function () {
                clearTimeout(this.timeout);
            }
        };

        let _promise = new Promise((resolve, reject) => {
            let _timeout = setTimeout(() => {
                reject("timeout");
            }, timeout);
            prom.timeout = _timeout;
            prom.resolve = resolve;
            prom.reject = reject;
        });

        prom.promise = _promise;
        this.promises[prom.key] = prom;
        return _promise;
    }

    resolvePromise(key, ...args) {
        let promise = this.promises[key];
        if (!promise) {
            this.log(`[resolvePromise] promise "${key}" not found.`);
            return;
        }
        promise.timeOutClear();
        promise.resolve(...args);
        delete this.promises[key];
    }

    rejectPromise(key, ...args) {
        let promise = this.promises[key];
        if (!promise) {
            this.log(`[rejectPromise] promise "${key}" not found.`);
            return;
        }
        promise.timeOutClear();
        promise.reject(...args);
        delete this.promises[key];
    }

    // NEW: Method to actually send data to a remote peer
    SendAction(peerID, actionName, ...args) {
        let instance = this.instances[peerID];
        if (!instance || !instance.connected) {
            this.log(`[SendAction] Cannot send. Peer "${peerID}" is not connected.`);
            return false;
        }

        let packet = {
            action: actionName,
            args: args
        };

        if (this.signFunction) {
            packet.signed = signFunction(packet);
        }

        if (instance.dataConnection.open) {
            instance.dataConnection.send(packet);
            this.log(`[SendAction] Sent action "${actionName}" to ${peerID}`);
            return true;
        } else {
            this.log(`[SendAction] Connection not open yet for "${peerID}". Queuing packet...`);
            if (!instance.queue) instance.queue = [];
            instance.queue.push(packet);
            return false;
        }
    }

    ActionCall(instanceID, actionName, ...args) {
        let action = null;
        let GlobalAction = null;

        // FIX: Check for instance-specific action first
        if (instanceID && this.instances[instanceID]) {
            action = this.instances[instanceID].actions[actionName];
        }
        GlobalAction = this.GlobalActions[actionName];

        if (action) {
            action.func(...args);
        } else {
            this.log(`[ActionCall] Action "${actionName}" not found for ${instanceID}`);
        }

        if (GlobalAction) {
            GlobalAction.func(this.instances[instanceID] || false, ...args);
        } else {
            this.log(`[ActionCall] Action "${actionName}" not found globally.`);
        }
    }

    ProcessData(instance, packet) {
        this.log(`[ProcessData] process data from ${instance.peer}`);
        this.log(`[ProcessData] packet: ${JSON.stringify(packet)}`);
        switch (typeof packet) {
            case "object":
                if (packet && packet.action) {
                    packet.args = packet.args || [];
                    this.ActionCall(instance.peer, packet.action, ...packet.args);
                }
                break;
            default:
                this.log(`[ProcessData] VV unknown packet data VV`);
                this.log(packet);
                break;
        }
    }

    /* @param {DataConnection} dataConnection
        @param {boolean} isCreator
    */
    newConnection(dataConnection, isCreator) {
        let existingInstance = this.instances[dataConnection.peer];

        if (existingInstance) {
            if (!existingInstance.connected || !existingInstance.dataConnection.open) {
                this.log(`Re-establishing connection with ${dataConnection.peer}`);
                existingInstance.dataConnection = dataConnection;
                existingInstance.isCreator = isCreator;

                // Re-bind the event listeners to the NEW data connection
                dataConnection.on("open", () => existingInstance.OnEvents.open());
                dataConnection.on("close", () => existingInstance.OnEvents.close());
                dataConnection.on("error", (err) => existingInstance.OnEvents.error(err));
                dataConnection.on("data", (data) => existingInstance.OnEvents.data(data));
            } else {
                // If it IS connected, and they are establishing a new connection to us, we should just let the new one live on its own or ignore it?
                // PeerJS allows multiple connections, but we store them by peer ID.
                // We shouldn't overwrite if existing is fully functional. We simply bind standard listeners so it doesn't crash, but don't overwrite.
                dataConnection.on("data", (data) => existingInstance.OnEvents.data(data));
            }
            return existingInstance;
        }

        // Standard instance creation
        let instance = {
            dataConnection: dataConnection,
            isCreator: isCreator,
            peer: dataConnection.peer,
            connected: false,
            promises: {},
            actions: {},
            events: {},
            ActionCall: (action, ...args) => {
                this.ActionCall(instance.peer, action, ...args);
            },
            CreateAction: (name, func) => {
                instance.actions[name] = this.NewAction(name, func);
            },
            OnEvents: {
                open: () => {
                    this.log(`Connected to ${instance.peer}`);
                    instance.connected = true;
                    if (instance.queue && instance.queue.length > 0) {
                        for (let p of instance.queue) {
                            if (instance.dataConnection.open) {
                                instance.dataConnection.send(p);
                                this.log(`[Queue] Sent queued action "${p.action}"`);
                            }
                        }
                        instance.queue = [];
                    }
                },
                close: () => {
                    this.log(`Connection to ${instance.peer} closed.`);
                    instance.connected = false;
                },
                error: (err) => {
                    this.log(`Error on connection with ${instance.peer}`);
                    console.error(err);
                },
                data: (packet) => {
                    this.ProcessData(instance, packet);
                }
            }
        };

        dataConnection.on("open", () => instance.OnEvents.open());
        dataConnection.on("close", () => instance.OnEvents.close());
        dataConnection.on("error", (err) => instance.OnEvents.error(err));
        dataConnection.on("data", (data) => instance.OnEvents.data(data));

        this.instances[instance.peer] = instance;
        return instance;
    }

    connect(peerID) {
        let conn = this.peerJS.connect(peerID);
        let inst = this.newConnection(conn, true);
        return inst;
    }
}



class DMInstance {
    constructor(intID) {
        if (!sesh.loggedIn) {
            throw new Error("Not logged in.");
        }
        this.PID = intToStrID(intID);
        this.PIID = intID;
        this.PeerJSID = generatePeerJSID(intID);
        this.p2p = sesh.P2P;
        this.peerIdentity = false;
        this.ready = false;
        this.peerConnected = false;
        this.Messages = {
            "self": {},
            "peer": {}
        }
        this.Widget = false;
        this.WidgetOpts = {};
        this.messageList = [];
        this.chatStatus = "disconnected";
        this.isOpen = false;
        this.peerInitialized = false;
        this.typingIndicator = {
            interval: null,
            typing: false,
            cancelAfter: 3000 //ms
        };
    }

    disconnect() {
        this.peerConnected = false;
        this.peerIdentity = false;
        this.chatStatus = "disconnected";
        this.ready = false;
    }

    reconnect() {
        this.init();
        this.renderAll();
        this.p2p.SendAction(this.PeerJSID, "chat_status", true);
    }

    async setPeerIdentity(profile) {
        this.peerIdentity = {
            peerID: this.PeerJSID,
            profile: profile,
            RSA: new SimpleRSA(profile.key)
        }
        this.peerConnected = true;
        this.chatStatus = "chatting";
        this.Widget.updateUserStatus(this.PID, "idle");
        await sleep(100);
        this.requestSync();
        this.p2p.SendAction(this.PeerJSID, "chat_status", true);
        this.p2p.SendAction(this.PeerJSID, "chat_reqData", "chat_status");
        await sleep(100);
        this.updateMessageStatuses();
    }

    onMessageStatus(hash) {
        console.log("OIL UP DIDDYBLUD","Request message status for: " + hash);
    }

    async init() {
        let _ = this;
        let p2p = this.p2p;

        let instance = p2p.instances[this.PeerJSID];
        if (!instance || !instance.connected) {
            p2p.connect(this.PeerJSID);
            instance = p2p.instances[this.PeerJSID];
        }

        let alreadyValid = cache.funcs.isValidPeer(this.PIID);
        if (alreadyValid !== false) {
            this.setPeerIdentity(await getUser(this.PIID));
        }

        if (!instance.actions["chat_message"]) {
            instance.CreateAction("chat_message", (actionPacket, packet) => _.recieveMessage(packet, instance.peer));
            instance.CreateAction("chat_read", (actionPacket, messageHash) => _.messageRead(messageHash, instance.peer));
            instance.CreateAction("chat_sync", (actionPacket, syncData) => _.sync(syncData, instance.peer));
            instance.CreateAction("chat_ReqSync", (actionPacket, req) => _.onSyncReq(req));
            instance.CreateAction("chat_ReqMessageStatus", (actionPacket, hash) => _.onMessageStatus(hash));
            instance.CreateAction("chat_reqData",(actionPacket, req) => {
                switch (req) {
                    case "chat_status":
                        _.p2p.SendAction(_.PeerJSID, "chat_status", _.isOpen);
                    break;
                    default:
                    break;
                }
            });
            instance.CreateAction("chat_status", (actionPacket, inRoom) => {
                if (inRoom) {
                    _.Widget.updateUserStatus(_.PID, "online");
                    this.chatStatus = "chatting";
                    this.peerInitialized = true;
                }else {
                    _.Widget.updateUserStatus(_.PID, "idle");
                    this.chatStatus = "inRoom";
                }
            });
            instance.CreateAction("chat_type", (actionPacket, isTyping) => {
                if (instance.peer !== _.peerIdentity?.peerID) return;
                if (isTyping) {
                    _.Widget.addTypingIndicator(_.peerIdentity.profile.username);
                } else {
                    _.Widget.removeTypingIndicator(_.peerIdentity.profile.username);
                }
            });
        }

        // Global listeners
        this.typingIndicator.interval = setInterval(function () {
            let lastInputUpdate = _.Widget.$lastInput;
            if ((lastInputUpdate + _.typingIndicator.cancelAfter) <= Date.now()) {
                if (_.typingIndicator.typing) {
                    _.typingIndicator.typing = false;
                    p2p.SendAction(_.PeerJSID, "chat_type", false);
                }
            } else {
                if (!_.typingIndicator.typing) {
                    _.typingIndicator.typing = true;
                    p2p.SendAction(_.PeerJSID, "chat_type", true);
                }
            }
        }, 200);

        p2p.eventListener("PeerAcknowledged", async function (peerID, profile) {
            if (peerID === _.PeerJSID) {
                _.setPeerIdentity(profile);
            }
        });

        p2p.eventListener("userOffline", async function (strID, intID) {
            if (intID == _.PIID) {
                _.peerConnected = false;
                _.chatStatus = "inRoom";
                _.Widget.updateUserStatus(_.PID, "offline");
                _.peerIdentity = false;
            }
        });

        this.chatStatus = "inRoom";
        // The old roomHash format was for Trystero, but DB still uses it to store history.
        let DM_RID = generateDMroomID(sesh.account.ID, this.PIID);
        let msgHistory = await MessageDB.getRoomHistory(DM_RID);
        if (msgHistory.hashList && msgHistory.hashList.length > 0) {
            this.Messages.self = msgHistory[sesh.account.id] || {};
            this.Messages.peer = msgHistory[this.PID] || {};
            this.messageList = msgHistory.hashList;
            this.renderAll();
        }
        await sleep(500);
        this.ready = true;
    }

    onSyncReq(syncRequest) {
        let blocklist = syncRequest.blocklist || [];
        let lastUpdate = syncRequest.lastUpdate || 0;
        let missing = this.messageList.filter(hash => !blocklist.includes(hash));
        let missing_messages = {}
        missing_messages[sesh.account.id] = this.Messages["self"]
        missing_messages[this.PID] = this.Messages["peer"]
        console.log("Missing messages:", missing);
        for (let hash of missing) {
            this.messageRead(hash, this.PeerJSID);
        }
        if (missing.length == 0) {
            this.p2p.SendAction(this.PeerJSID, "chat_sync",{
                missing: false,
            });
        } else {
            this.p2p.SendAction(this.PeerJSID, "chat_sync",{
                missing: missing,
                messages: missing_messages
            });
        }
    }

    sync(data, peerID) {
        if (peerID !== this.PeerJSID) return;
        console.log("GOT SYNC:", data);
        if (data.missing == false) {
            console.log("Messages all up to date");
            return;
        }
        let DM_RID = generateDMroomID(sesh.account.ID, this.PIID);
        for (let hash of data.missing) {
            console.log("Syncing message: " + hash);
            let messages = data.messages[this.PID];
            let message = messages[hash] || data.messages[sesh.account.id][hash];
            console.log("MESSAGE:",message, messages, hash)
            let prevHash = message.prevHash;
            let authorID = message.author.strID;
            message.readAt = false;
            this.Messages[authorID == this.PID ? "peer" : "self"][hash] = message;
            let prevIndex = this.messageList.indexOf(prevHash);
            if (prevIndex == -1) {
                console.log("Previus index not found", prevHash, prevIndex)
                this.messageList.push(hash);
            } else {
                this.messageList.splice(prevIndex + 1, 0, hash);
            }
            MessageDB.addMessage(DM_RID, message);
        }
        this.renderAll();
    }

    requestSync() {
        if (this.peerConnected) {
            let latestMessage = this.Messages.self[this.messageList.at(-1)] || this.Messages.peer[this.messageList.at(-1)]
            let lastestTimestamp = !latestMessage ? 0 : latestMessage.timestamp;
            this.p2p.SendAction(this.PeerJSID, "chat_ReqSync", {
                blocklist: this.messageList,
                lastUpdate: lastestTimestamp
            });
        }
    }

    updateMessageStatuses() {
        for (let hash of this.messageList) {
            let PeerMSG = this.Messages.peer[hash];
            let SelfMSG = this.Messages.self[hash];
            if (SelfMSG && SelfMSG.status == "sent") {
                if (this.peerConnected) {
                    this.p2p.SendAction(this.PeerJSID, "chat_ReqMessageStatus", hash);                    
                }
            }
            if (PeerMSG && PeerMSG.status == "recieved") {
                this.Messages.peer[hash].status = "read";
                this.p2p.SendAction(this.PeerJSID, "chat_read", hash);
            }
        }
    }

    async renderAll() {
        let ident;
        if (!this.peerConnected) {
            console.warn("Peer not connected.");
            let user = await getUser(this.PIID);
            ident = {
                peerID: false,
                profile: user,
                RSA: new SimpleRSA(user.key)
            }
        } else {
            ident = this.peerIdentity;
            this.updateMessageStatuses();
        }
        renderMessage({
            "mode": "all",
            "type": "dm",
            "hashList": this.messageList,
            "self": this.Messages.self,
            "peer": this.Messages.peer,
            "widget": this.Widget,
            "peerProfile": ident.profile
        });
    }

    messageRead(messageHash, peerID) {
        if (peerID !== this.PeerJSID) return;
        let msg = this.Messages.peer[messageHash] || this.Messages.self[messageHash];
        if (msg.status == "read" || msg.readAt !== false) {
            return;
        }
        msg.readAt = Date.now();
        msg.status = "read";
        let CUI_UserMessage = this.Widget.MessageItems[messageHash];
        if (!CUI_UserMessage) {
            console.error("Could not find message: " + messageHash);
            return;
        }
        CUI_UserMessage.updateStatus("read", { readAt: Date.now() });
        MessageDB.updateStatus(messageHash, "read", msg.readAt);
    }

    recieveMessage(messagePacket, peerID) {
        if (peerID !== this.PeerJSID) return;
        let processed = processMessage(messagePacket);
        console.log("Processed message:", processed);
        let prevHash = this.messageList.at(-1) || CryptoJS.SHA256("HASH ZERO").toString();

        let message_newHash = processed.hash;
        let message_prevHash = processed.prevHash;
        let rawCompHashStr = `${processed.author.combString}|${processed.messageHash}|${processed.timestamp}|${message_prevHash}`;
        let computedHash = CryptoJS.SHA256(rawCompHashStr).toString()
        if (computedHash == message_newHash) {
            let DM_RID = generateDMroomID(sesh.account.ID, this.PIID);
            let toStore = {
                "author": processed.author,
                "rawMessage": processed.rawMessage,
                "hash": processed.hash,
                "prevHash": processed.prevHash,
                "timestamp": processed.timestamp,
                "readAt": Date.now(),
                "status": "read"
            }
            this.messageList.push(processed.hash);
            this.Messages.peer[processed.hash] = toStore;
            MessageDB.addMessage(DM_RID, toStore);
            renderMessage({
                "mode": "append",
                "message": toStore,
                "type": "dm",
                "messageOptions": { "status": "read" },
                "widget": this.Widget,
                "peerProfile": this.peerIdentity.profile
            });
            this.p2p.SendAction(this.PeerJSID, "chat_read", toStore.hash);
        } else {
            console.log("INVALID BLOCK", computedHash, message_newHash);
        }
    }

    async sendMessage(msgText) {
        let ident;
        if (!this.peerConnected) {
            let user = await getUser(this.PIID);
            ident = { peerID: false, profile: user, RSA: new SimpleRSA(user.key) }
        } else {
            ident = this.peerIdentity;
            this.p2p.SendAction(this.PeerJSID, "chat_type", false);
        }
        let prevHash = this.messageList.at(-1) || false;
        let message = new Message(sesh.account, sesh.RSAkeys, msgText, prevHash);
        let encrypted = message.encryptFor(ident.RSA.keypair.public);
        let toStore = message.messagePacket;
        toStore.readAt = false;

        if (this.peerConnected && this.chatStatus == "chatting") {
            toStore.status = "sent";
            this.p2p.SendAction(this.PeerJSID, "chat_message", encrypted);
        } else {
            if (cache.funcs.getStatus(this.PIID) != "online") {
                await pingUser(this.PIID);
            }
            if (cache.funcs.getStatus(this.PIID) == "online") {
                whisperTo(this.PIID, encrypted);
                toStore.status = "sent";
            } else {
                toStore.status = "waiting";
            }
        }
        let DM_RID = generateDMroomID(sesh.account.ID, this.PIID);
        MessageDB.addMessage(DM_RID, toStore);
        this.messageList.push(toStore.hash);
        this.Messages.self[toStore.hash] = toStore;
        renderMessage({
            "mode": "append",
            "message": toStore,
            "type": "dm",
            "messageOptions": { "status": toStore.status },
            "widget": this.Widget,
            "peerProfile": sesh.publicProfile
        });
    }

    initChatWidget(chat_options = {}) {
        this.WidgetOpts = chat_options;
        let DM_RID = generateDMroomID(sesh.account.ID, this.PIID);
        $("#chat-" + DM_RID).remove();
        UI.MessageUI.chatwidget.append(`<div class="chat-instance" id="chat-${DM_RID}"></div>`);
        this.Widget = new ChatWidget(`chat-${DM_RID}`, this.WidgetOpts);
    }

    openWidget() {
        if (this.Widget) {
            this.isOpen = true;
            this.Widget.open(this.WidgetOpts.inChat[0].username);
        }
    }

    minimize() {
        let _ = this;
        let p2p = this.p2p;
        let instance = p2p.instances[this.PeerJSID];
        this.isOpen = false;
        this.Widget.close();
        if (instance) {
            p2p.SendAction(this.PeerJSID, "chat_status", false);
        }
    }
}