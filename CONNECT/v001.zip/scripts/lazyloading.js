var NavComponents = {
    "sideNav": {},
    "nav": {
        "main": "pages/main.html",
        "messages": "pages/messages.html",
        // "chatrooms": "pages/chatrooms.html",
        "community": "pages/community.html",
        // "feed": "pages/feed.html",
        // "forums": "pages/forums.html",
        // "files": "pages/files.html",
        "account": "pages/account.html",
        "settings": "pages/settings.html",
        "misc": "pages/misc.html",
        "notifications": "pages/notifications.html"
    }
}

let loadedNavs = [];

function loadNav(name) {
    if (name in NavComponents.nav) {
        if (!loadedNavs.includes(name)) {
            loadedNavs.push(name);
            console.log("LOADING NAV: " + name);
            
            // Use native fetch so the interceptor catches it
            fetch(NavComponents.nav[name])
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.text(); // Parse the response as plain text/HTML
                })
                .then(data => {
                    // Inject the HTML using your existing jQuery selector
                    $("#cont-" + name).html(data);
                })
                .catch(error => {
                    console.error("Error loading nav " + name + ":", error);
                    // Optionally remove from loadedNavs so it can be retried later
                    // loadedNavs.splice(loadedNavs.indexOf(name), 1);
                });
        }
    }
}

function loadAllNavs() {
    for (let i = 0; i < Object.keys(NavComponents.nav).length; i++) {
        loadNav(Object.keys(NavComponents.nav)[i]);
    }
}

loadAllNavs();
