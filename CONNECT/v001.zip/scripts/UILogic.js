let dummyData = {
    friends: ["Jackboback", "Jane Doe", "John Smith", "Alice Wonderland", "CoolGamer", "NewUser123"],
    recentChats: [],
    favoriteChats: []
}
var guis = document.getElementsByClassName("gui-cont");
var currentGUI = "main";
var navs = document.getElementsByClassName("nav");
var currentNav = "main";
var disabledNavs = ["feed", "forums", "files", "chatrooms"];
var lowerNavs = ["account", "notifications", "settings"];
var _params = new URLSearchParams(window.parent.location.search);
const delay = millis => new Promise((resolve, reject) => {
    setTimeout(_ => resolve(), millis)
});
let page_param = _params.get("page");
//DEVELOPER FEATURE, REMMOVE LATER
if (_params.get("nologin") !== null) {
    hideLoginOverlay();
}
var guiHistory = [];
let UI = {};
let PAGES = {};
function initUI() {
    PAGES = {
        messages: {
            container: $("#cont-messages"),
            onUnload: function () {
                if (currentDM !== false) {
                    let instance = MessageInstances[currentDM];
                    if (instance && instance.Widget.isVisible) {
                        // sesh.P2P.SendAction(instance.PeerJSID, "chat_status", false);
                        // instance.disconnect();
                        showContacts();
                    }
                }
            },
            onload: function () {
                if (currentDM !== false) {
                    let instance = MessageInstances[currentDM];
                    if (instance && instance.Widget.isVisible) {
                        instance.reconnect();
                        instance.renderAll();
                    }
                }
                if (sesh.loggedIn) {
                    for (friendID of sesh.account.friends) {
                        updateAllStatusIndicatorsFor(friendID);
                    }
                }
            }
        }
    }
    UI = {
        SideNav: {
            main: {
                main: $("#gui-cont-main"),
                messages: $("#gui-cont-messages"),
                chatrooms: $("#gui-cont-chatrooms"),
                chatrooms_join: $("#gui-cont-chatrooms-join"),
                community: $("#gui-cont-community"),
                feed: $("#gui-cont-feed"),
                forums: $("#gui-cont-forums"),
                files: $("#gui-cont-files"),
            },
            lower: {
                account: $("#account"),
                username: $("#lgl-username"),
                settings: $("#settings"),
                notifications: $("#notifications"),
                notifications_badge: $("#notifications-num"),
            },
            funcs: {

            }
        },
        MiscUI: {
            newsList: $(".news-feed") 
        },
        MessageUI: {
            contactsElm: $(".contacts-container .contacts-content"),
            contactsSearchElm: $(".contact-search-input"),
            favoritesNavElm: $("#gcm-messages-favorites"),
            recentsNavElm: $("#gcm-messages-recents"),
            chatwidget: $("#chat-widget-messages"),
            funcs: {
                loadMessageUI: function () {
                    UI.MessageUI.funcs.displayContacts();
                    UI.MessageUI.funcs.initContactsAutocomplete();
                    UI.MessageUI.funcs.displayRecentChats();
                    UI.MessageUI.funcs.displayFavoriteChats();
                },
                displayContacts: async function () {
                    UI.MessageUI.contactsElm.empty();
                    if (!sesh.loggedIn) {
                        return;
                    }
                    let friends = await getUser(sesh.account.friends);
                    friends.forEach(contact => {
                        UI.MessageUI.contactsElm.append($(`
                        <div onclick="openChat(${contact.ID})" data-username="${contact.username}" class="contact">
                            <div class="avatar-wrapper">
                                <img class="avatar" src="${contact.picture}" alt="${contact}">
                                <div data-status="${contact.id}" class="status-indicator status-${cache.funcs.getStatus(contact.ID)}"></div>
                            </div>
                            <div class="contact-info">
                                <h3>${contact.username}</h3>
                                <p class="contact-handle">${contact.id}</p>
                                <p class="contact-status-text" data-status-text="${contact.id}">${cache.funcs.getStatus(contact.ID)}</p>
                            </div>
                        </div>
                    `));
                    });
                },
                initContactsAutocomplete: async function () {
                    if (!sesh.loggedIn) {
                        return;
                    }
                    let friends = await getUser(sesh.account.friends);
                    UI.MessageUI.contactsSearchElm.autocomplete({
                        source: friends.map(contact => contact.username)
                    });
                },
                displayRecentChats: async function () {
                    let recents = storage.Messaging.recents;
                    recents = recents.filter(ID => !storage.Messaging.favorites.includes(ID));
                    UI.MessageUI.recentsNavElm.empty();
                    let users = await getUser(recents);
                    users.forEach(contact => {
                        UI.MessageUI.recentsNavElm.append($(`
                    <div onclick="openChat(${contact.ID})" data-username="${contact.username}"
                        class="nav-item gcm-messages-recent">
                        <h3>${contact.username}
                        <span class="nav-item-ID">${contact.id}</span>
                        </h3>
                        <div class="nav-avatar-wrapper icon contact-img">
                            <img src="${contact.picture}" alt="${contact.username}" />
                            <div data-status="${contact.id}" class="status-indicator status-${cache.funcs.getStatus(contact.ID)}"></div>
                        </div>
                    </div>
                        `));
                    });
                    if (recents.length == 0) {
                        UI.MessageUI.recentsNavElm.append($(`
                    <div class="nav-item gcm-messages-recent disabled">
                        <h3>No recent chats...</h3>
                    </div>
                        `));
                    }
                    InitGUIFocus("#gui-cont-messages", false);
                    return true;
                },
                displayFavoriteChats: async function () {
                    UI.MessageUI.favoritesNavElm.empty();
                    let users = await getUser(storage.Messaging.favorites);
                    users.forEach(contact => {
                        UI.MessageUI.favoritesNavElm.append($(`
                    <div onclick="openChat(${contact.ID})" data-username="${contact.username}"
                        class="nav-item gcm-messages-favorite">
                        <h3>${contact.username}
                        <span class="nav-item-ID">${contact.id}</span>
                        </h3>
                        <div class="nav-avatar-wrapper icon contact-img">
                            <img src="${contact.picture}" alt="${contact.username}" />
                            <div data-status="${contact.id}" class="status-indicator status-${cache.funcs.getStatus(contact.ID)}"></div>
                        </div>
                    </div>
                        `));
                    });
                    if (users.length == 0) {
                        UI.MessageUI.favoritesNavElm.append($(`
                    <div class="nav-item gcm-messages-favorite disabled">
                        <h3>No favorited chats...</h3>
                    </div>
                        `));
                    }
                    InitGUIFocus("#gui-cont-messages", false);
                    return true;
                }
            }
        },
        AccountUI: {
            avatar: $("#account-avatar"),
            username: $("#account-username"),
            usernameText: $(".profile-username"),
            ID: $(".profile-userid"),
            bio: $("#account-bio"),
            email: $("#account-email"),
            sessionToken: $("#account-session-token"),
            newPassword: $("#account-new-password"),
            confirmPassword: $("#account-confirm-password"),
            funcs: {
                loadAccountUI: function () {
                    UI.AccountUI.username.val(sesh.account.username);
                    UI.AccountUI.usernameText.text(sesh.account.username);
                    UI.AccountUI.ID.text(sesh.account.id);
                    UI.AccountUI.bio.val(sesh.account.profile.bio);
                    UI.AccountUI.email.val(sesh.account.email);
                    UI.AccountUI.sessionToken.val(sesh.sessionToken);
                    UI.AccountUI.avatar.attr("src", sesh.account.picture);
                },
                updateEmail: async function () {
                    let newEmail = UI.AccountUI.email.val();
                    if (newEmail === sesh.account.email) {
                        toast("info", "Email is already your current email.");
                        return;
                    }
                    if (confirm("Are you sure you want to update your email?") === false) {
                        toast("info", "Email update cancelled");
                        return;
                    }
                    toast("info", "Updating email...");
                    let res = await sesh.updateAccountInfo({
                        email: newEmail
                    })
                    if (res == true) {
                        toast("success", "Email updated");
                    } else {
                        toast("error", "Failed to update email");
                    }
                },
                updateProfile: async function () {
                    let bio = UI.AccountUI.bio.val();
                    sesh.account.profile.bio = bio;
                    let res = await sesh.updateAccountInfo({
                        profile: sesh.account.profile
                    })
                    if (res == true) {
                        toast("success", "Profile updated");
                    } else {
                        toast("error", "Failed to update profile");
                    }
                }
            }
        },
        notifications: {
            container: $(".notifications-container"),
            list: $(".notification-list"),
            badge: $("#notifications-num"),
            funcs: {
                test: function() {
                    UI.notifications.list.empty();
                    let notif = new Notification("friendRequest",{message:"user wants to be friends."});
                    let notif2 = new Notification("message",{id:"message",message:"What is up my goon",title:"New Message from BigTester"});
                    UI.notifications.list.prepend(notif.render())
                    UI.notifications.list.prepend(notif2.render())
                },
                updateBadge: function(num) {
                    UI.notifications.badge.show();
                    if (num <= 0) {
                        UI.notifications.badge.hide();
                    }
                    UI.notifications.badge.html(num);
                },
                showUnreadIcon: function() {
                    let count = 0;
                    for (let key in NotificationInstances) {
                        let notifInstance = NotificationInstances[key];
                        if (notifInstance.read == false) {
                            count++;
                        } 
                    }
                    UI.notifications.funcs.updateBadge(count);
                }
            },
            onload: function() {
                // UI.notifications.funcs.updateBadge(0);
                UI.notifications.funcs.showUnreadIcon();
            }
            // onload: function () {
            //     // $(".notification-item").css("margin-left", "100%");
            //     UI.notifications.offload();
            //     Array.from($(".notification-item")).forEach((item, index) => {
            //         setTimeout(function () {
            //             $(item).css("margin-left", `0px`);
            //         }, (index + 1) * 75);
            //     });
            // },
            // offload: function () {
            //     $(".notification-item").css("margin-left", "120%");
            // }
        },
        SettingsUI: {
            general: {
                elm: $("#settings-tab-general"),
                notificationsSound: $("#setting-general-notifications-sound"),
                messageNotifications: $("#setting-general-message-notifications"),
            },
            cloud: {
                elm: $("#settings-tab-cloud"),
                syncMessages: $("#setting-cloud-sync-messages"),
                downloadMessages: $("#setting-cloud-download-messages"),
                deleteSync: $("#setting-cloud-delete-sync"),
            },
            home: {
                elm: $("#settings-tab-home"),
                clock: $("#setting-home-clock"),
                notifications: $("#setting-home-notifications"),
                client: $("#setting-home-client"),
                news: $("#setting-home-news"),
            },
            network: {
                elm: $("#settings-tab-network"),
                status: {
                    masterDB: {
                        indicator: $("#setting-network-masterdb-indicator"),
                        status: $("#setting-network-masterdb-status"),
                        requestTime: $("#setting-network-masterdb-request-time"),
                    },
                    cacheServer: {
                        indicator: $("#setting-network-cacheserver-indicator"),
                        status: $("#setting-network-cacheserver-status"),
                    },
                    p2p: {
                        indicator: $("#setting-network-p2p-indicator"),
                        status: $("#setting-network-p2p-status"),
                        connections: $("#setting-network-p2p-connections"),
                    },
                },
                EnableCacheServer: $("#setting-network-enable-cacheserver"),
                MDBHost: $("#setting-network-mdb-host"),
                CacheServerHost: $("#setting-network-cacheserver-host"),

            },
            help: {
                elm: $("#settings-tab-help"),
            },
            funcs: {
                loadSettings: function () {
                    for (let category in settings) {
                        console.log(category);
                        for (let setting in settings[category]) {
                            let value = settings[category][setting];
                            let elm = UI.SettingsUI[category][setting];
                            if (!elm) {
                                console.error(`UI element for setting ${category}.${setting} not found.`);
                                return;
                            }
                            switch (typeof value) {
                                case "boolean":
                                    elm.prop("checked", value);
                                    break;
                                case "string":
                                    elm.val(value);
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                }
            }
        },
        CommunityUI: {
            elm: $("#gui-cont-community"),
            friendsList: $("#community-friends-list"),
            resultsList: $("#community-results-list"),
            searchInput: $("#community-search-input"),
            resultsCount: $("#community-results-count"),
            friendRequestsCount: $("#community-friend-requests-count"),
            sentFriendRequestsCount: $("#community-outgoing-friend-requests-count"),
            friendRequestsList: $("#community-friend-requests-list"),
            sentFriendRequestsList: $("#community-outgoing-friend-requests-list"),
            funcs: {
                buttons: {
                    addFriend: function() {
                        //Yeah my ass is to lazy to do it another way
                        $('.nav-item[data-ident="community-search"]').click()
                    },
                    chat: async function (elm, id) {
                        displayGUI("messages");
                        openChat(id);
                    },
                    send: async function (elm, id) {
                        let button = $(elm);
                        if (button.prop("disabled")) {
                            return;
                        }
                        toast("info","Sending friend request...");
                        button.prop("disabled", true);
                        sendFriendRequest(id).then(async () => {
                            await sesh.refreshAccount();
                            UI.CommunityUI.funcs.init();
                        }).finally(() => {
                            button.prop("disabled", false);
                        });
                    },
                    cancel: async function (elm, id) {
                        let button = $(elm);
                        if (button.prop("disabled")) {
                            return;
                        }
                        button.prop("disabled", true);
                        cancelFriendRequest(id).then(async () => {
                            await sesh.refreshAccount();
                            UI.CommunityUI.funcs.init();
                        }).finally(() => {
                            button.prop("disabled", false);
                        });
                    },
                    remove: async function (elm, id) {
                        if (!confirm("Are you sure you want to remove this friend?")) {
                            return;
                        }
                        let button = $(elm);
                        if (button.prop("disabled")) {
                            return;
                        }
                        button.prop("disabled", true);
                        removeFriend(id).then(async () => {
                            await sesh.refreshAccount();
                            UI.CommunityUI.funcs.init();
                        }).finally(() => {
                            button.prop("disabled", false);
                        });
                    },
                    pingAll: async function (elm) {
                        let button = $(elm);
                        if (button.prop("disabled")) {
                            return;
                        }
                        toast("info",`Refreshing statuses...`);
                        button.prop("disabled", true);
                        await pingUser(sesh.account.friends, true);
                        button.prop("disabled", false);
                    },
                    ping: async function (elm, id) {
                        let button = $(elm);
                        if (button.prop("disabled")) {
                            return;
                        }
                        let user = await getUser(id);
                        toast("info",`Checking ${user.username}'s status...`);
                        button.prop("disabled", true);
                        await pingUser(id, true).then((profile) => {
                            toast("ok",`${user.username} is online!`);
                        }).catch(() => {
                            toast("error",`${user.username} is offline.`);
                        });
                        updateAllStatusIndicatorsFor(id);
                        button.prop("disabled", false);
                    }
                },
                init: function () {
                    UI.CommunityUI.funcs.displayFriends();
                    UI.CommunityUI.funcs.displayFriendRequests();
                    UI.CommunityUI.funcs.displaySentFriendRequests();
                },
                searchUser: async function () {
                    let query = UI.CommunityUI.searchInput.val();
                    if (!query) {
                        toast("info", "Please enter a username to search.");
                        return;
                    }
                    UI.CommunityUI.resultsList.empty();
                    UI.CommunityUI.resultsList.append("<p style='padding: 20px;'>Searching...</p>");
                    try {
                        let results = await searchUser(query);
                        UI.CommunityUI.resultsList.empty();
                        if (results.response === "OK") {
                            results = results.message;
                        } else {
                            toast("error", results.message);
                            return;
                        }
                        if (results && results.length > 0) {
                            UI.CommunityUI.resultsCount.text(results.length);
                            results.forEach(user => {
                                let resultHTML = `
                                <div class="user-result-row">
                                    <div class="friend-left-content">
                                        <div class="friend-avatar-wrapper">
                                            <img src="${user.picture || 'assets/people.png'}" class="friend-avatar" alt="User">
                                        </div>
                                        <div class="friend-info">
                                            <h3 class="friend-name">${user.username}</h3>
                                            <p class="friend-status">${user.id}</p>
                                        </div>
                                    </div>
                                    <button onclick="UI.CommunityUI.funcs.buttons.send(this,${user.ID})" class="add-friend-btn">Send Request</button>
                                </div>
                                `;
                                UI.CommunityUI.resultsList.append(resultHTML);
                            });
                        } else {
                            UI.CommunityUI.resultsCount.text(0);
                            UI.CommunityUI.resultsList.append("<p style='padding: 20px;'>No users found.</p>");
                        }
                    } catch (e) {
                        console.error("Search failed", e);
                        UI.CommunityUI.resultsList.empty();
                        UI.CommunityUI.resultsList.append("<p style='padding: 20px;'>Search failed. Please try again.</p>");
                    }
                },
                displayFriends: async function () {
                    UI.CommunityUI.friendsList.empty();
                    if (!sesh.loggedIn) {
                        return;
                    }
                    let friendIDs = sesh.account.friends;
                    $("#community-friends-count").text(friendIDs.length);
                    for (ID of friendIDs) {
                        let user = await getUser(ID);
                        console.log(ID, user);
                        let isfav = storage.Messaging.favorites.includes(user.ID);
                        let userHTML = `
                        <div class="friend-row" data-user-id="${user.ID}" id="community-friend-${user.username}">
                <div class="friend-left-content">
                    <div class="friend-avatar-wrapper">
                        <img src="${user.picture || 'assets/people.png'}" class="friend-avatar" alt="Friend">
                        <div data-status="${user.id}" class="status-indicator-community status-${cache.funcs.getStatus(user.ID)}"></div>
                    </div>
                    <div class="friend-info">
                        <h3 class="friend-name">${user.username}</h3>
                        <p class="friend-status" data-status-text="${user.id}">${cache.funcs.getStatus(user.ID)}</p>
                    </div>
                </div>
                <div class="friend-actions">
                <!-- disabled calling for now -->
                <!--
                    <button class="action-btn call-btn" title="Call">
                        <img src="assets/call.png" alt="Call" />
                    </button>
                    <button class="action-btn video-btn" title="Video Call">
                        <img src="assets/video.png" alt="Video" />
                    </button>
                -->
                    <button onclick=UI.CommunityUI.funcs.buttons.chat(this,${user.ID}) class="action-btn message-btn" title="Message">
                        <img src="assets/message.png" alt="Message" />
                    </button>
                    <button onclick="UI.CommunityUI.funcs.buttons.ping(this,${user.ID})" class="action-btn ping-btn" title="Ping">
                        <img src="assets/ping.png" alt="Ping" />
                    </button>
                    <button class="action-btn ${isfav ? "unfavorite-btn" : "favorite-btn"}" title="${isfav ? "Unfavorite" : "Favorite"}">
                        <img src="${isfav ? "assets/star-colored.png" : "assets/star.png"}" alt="${isfav ? "Unfavorite" : "Favorite"}" />
                    </button>
                    <button onclick="UI.CommunityUI.funcs.buttons.remove(this,${user.ID})" class="action-btn remove-btn" title="Remove Friend">
                        <img src="assets/close.png" alt="Remove" />
                    </button>
                </div>
            </div>`;
                        UI.CommunityUI.friendsList.append(userHTML);
                        let favBtn = $(`#community-friend-${user.username} .${isfav ? "unfavorite-btn" : "favorite-btn"}`);
                        favBtn.off("click");
                        favBtn.on("click", function () {
                            console.log("Clicked. Current state isFav:", isfav);

                            if (isfav) {
                                // --- CASE: User IS a favorite. We want to REMOVE them. ---
                                storageFunctions.removeFavoriteContact(user.ID);

                                // 1. Update UI to "Not Favorite" state
                                favBtn.removeClass("unfavorite-btn").addClass("favorite-btn");
                                favBtn.find("img").attr("src", "assets/star.png");

                                // 2. Update the variable so the next click works correctly
                                isfav = false;

                            } else {
                                // --- CASE: User is NOT a favorite. We want to ADD them. ---
                                storageFunctions.addFavoriteContact(user.ID);

                                // 1. Update UI to "Is Favorite" state
                                favBtn.removeClass("favorite-btn").addClass("unfavorite-btn");
                                favBtn.find("img").attr("src", "assets/star-colored.png");

                                // 2. Update the variable so the next click works correctly
                                isfav = true;
                            }

                            // Refresh other UI components
                            UI.MessageUI.funcs.displayFavoriteChats();
                            UI.MessageUI.funcs.displayRecentChats();
                        });
                    }
                },
                displayFriendRequests: async function () {
                    if (!sesh.loggedIn) {
                        return;
                    }
                    UI.CommunityUI.friendRequestsList.empty();
                    let pending = await getUser(sesh.account.pendingFriends);
                    UI.CommunityUI.friendRequestsCount.text(pending.length);
                    if (pending.length == 0) {
                        UI.CommunityUI.friendRequestsList.append("<h4>No incoming friend requests...</h4>")
                        return;
                    }
                    for (profile of pending) {
                        let userHTML = `
                    <div class="friend-row" data-user-id="${profile.username}" id="community-friendRequest-${profile.ID}">
                        <div class="friend-left-content">
                            <div class="friend-avatar-wrapper">
                                <img src="${profile.picture}" class="friend-avatar" alt="Friend">
                            </div>
                            <div class="friend-info">
                                <h3 class="friend-name">${profile.username}</h3>
                                <p class="friend-status">${profile.id}</p>
                            </div>
                        </div>
                        <div class="friend-actions">
                            <button onclick="UI.CommunityUI.funcs.buttons.send(this,${profile.ID})" class="action-btn accept-btn" title="Accept">
                                <img src="assets/check.png" alt="Accept" />
                            </button>
                            <button class="action-btn remove-btn" title="Decline">
                                <img src="assets/close.png" alt="Remove" />
                            </button>
                        </div>
                    </div>
                        `
                        UI.CommunityUI.friendRequestsList.append(userHTML)
                    }
                },
                displaySentFriendRequests: async function () {
                    if (!sesh.loggedIn) {
                        return;
                    }
                    UI.CommunityUI.sentFriendRequestsList.empty();
                    let pending = await getUser(sesh.account.sentFriendR);
                    UI.CommunityUI.sentFriendRequestsCount.text(pending.length);
                    if (pending.length == 0) {
                        UI.CommunityUI.sentFriendRequestsList.append("<h4>No outgoing friend requests...</h4>")
                        return;
                    }
                    for (profile of pending) {
                        let userHTML = `
                    <div class="friend-row" data-user-id="${profile.username}" id="community-sentFriendRequest-${profile.ID}">
                        <div class="friend-left-content">
                            <div class="friend-avatar-wrapper">
                                <img src="${profile.picture}" class="friend-avatar" alt="Friend">
                            </div>
                            <div class="friend-info">
                                <h3 class="friend-name">${profile.username}</h3>
                                <p class="friend-status">${profile.id}</p>
                            </div>
                        </div>
                        <div class="friend-actions">
                            <button onclick="" class="action-btn remove-btn" title="Cancel">
                                <img src="assets/close.png" alt="Remove" />
                            </button>
                        </div>
                    </div>
                        `
                        UI.CommunityUI.sentFriendRequestsList.append(userHTML)
                    }
                }
            }
        },
        ChatroomsUI: {
            rooms: $("#chatrooms-browse-list"),
            searchBar: $("#chatrooms-search-input"),
            prevBtn: $("#chatrooms-lower-btn-back"),
            nextBtn: $("#chatrooms-lower-btn-next"),
            funcs: {
                CurrentPage: 1,
                nextPage: function () {

                },
                displayPage: async function (page = 1) {
                    if (UI.ChatroomsUI.rooms.length == 0) {
                        initUI();
                    }

                    // Show loading, clear current list
                    UI.ChatroomsUI.rooms.empty();
                    $("#chatrooms-loading").show();

                    let rooms = await cache.funcs.getRoomPage(page);
                    let itemsPerPage = 8;
                    if (rooms.length == 0) {
                        let request = await listRooms(page);
                        if (request.response == "OK") {
                            rooms = request.message;
                        }
                    }

                    // Hide loading before rendering
                    $("#chatrooms-loading").hide();
                    UI.ChatroomsUI.rooms.empty();
                    if (rooms.length < itemsPerPage) {
                        UI.ChatroomsUI.nextBtn.attr("disabled", true);
                    } else {
                        UI.ChatroomsUI.nextBtn.attr("disabled", false);
                    }
                    if (page > 1) {
                        UI.ChatroomsUI.prevBtn.attr("disabled", false);
                    } else {
                        UI.ChatroomsUI.prevBtn.attr("disabled", true);
                    }
                    for (room of rooms) {
                        let publicty;
                        if (room.privacy == "public") {
                            publicty = "public";
                        } else {
                            publicty = "private";
                        }
                        let roomHTML = `
                            <div class="chatroom-card glass" id="chatroom-${room.RoomID}">
                                <img src="${room.image}" class="room-banner"></img>
                                <div class="room-content">
                                    <div class="room-header-row">
                                        <h3 class="room-name">${room.name}</h3>
                                        <span class="room-badge badge-${publicty}">${publicty}</span>
                                    </div>
                                    <div class="room-creator">
                                        <img src="${room.creator.picture}" alt="Creator" class="creator-icon">
                                        <span class="creator-name">${room.creator.username}</span>
                                    </div>
                                    <p class="room-description">${room.description}</p>
                                    <div class="room-meta">
                                        <span class="member-count">X members</span>
                                    </div>
                                    <button class="join-room-btn">Join Room</button>
                                </div>
                            </div>
                            `;
                        UI.ChatroomsUI.rooms.append(roomHTML);
                    }
                }
            }
        }
    }
    InitGUIFocus("#gui-cont-main");
    // UI.MessageUI.funcs.loadMessageUI();
    InitGUIFocus("#gui-cont-chatrooms");
    InitGUIFocus("#gui-cont-community");
    InitGUIFocus("#gui-cont-misc");

    // Community Search Listener
    UI.CommunityUI.searchInput.on("keydown", function (e) {
        if (e.key === "Enter") {
            UI.CommunityUI.funcs.searchUser();
        }
    });
}
initUI();

function selectNavItem(gui, item) {
    if (item[0] == "[") {
        item = " " + item;
    }
    let query = "#gui-cont-" + gui;
    $(query + " .nav-item.selected").removeClass("selected");
    $(query + item).addClass("selected");
}


async function displayGUI(gui, isBack = false, showNav = true) {
    if (disabledNavs.includes(gui)) {
        return;
    }

    if (!isBack && currentGUI !== "main") {
        guiHistory.push(currentGUI);
    }

    // If we are going back to main, clear the history
    if (gui === "main") {
        guiHistory = [];
    }

    currentGUI = gui;

    // If we are navigating to a main nav item, update the sidebar logic
    // We check if the gui exists in the main nav list by checking if a corresponding gcm- exists and if it is a main-item
    if (showNav && $("#gcm-" + gui).hasClass("main-item")) {
        displayNav(gui);
        $(".nav-item.main-item").removeClass('selected');
        $("#gcm-" + gui).addClass('selected');
    }

    if ($("#gui-cont-" + gui)[0].style.display !== "block" && $("#gui-cont-" + gui)[0].style.display !== "") {
        for (let i = 0; i < guis.length; i++) {
            guis[i].style.display = "none";
        }

        $(`#gui-cont-${gui} .nav-item`).css('margin-left', '-300px');
        $("#gui-cont-" + gui).show();
        for (let i = 0; i < $(`#gui-cont-${gui} .nav-item`).length; i++) {
            $($(`#gui-cont-${gui} .nav-item`)[i]).css('margin-left', '0px');
            await delay(100)
        }
    }
}

function goBack(sticky = true) {
    if (guiHistory.length > 0) {
        const previousGUI = guiHistory.pop();
        if (!sticky) {
            $("#gui-cont-" + previousGUI).children(".nav-item")[0].click();
        }
        displayGUI(previousGUI, true);
    } else {
        displayGUI("main", true, false);
    }
}

function displaySubNav(nav, subnav) {
    hideSubNavs(nav);
    if (nav !== currentNav) {
        displayNav(nav);
    }
    $(`#cont-${nav} #${nav}-${subnav}`).show();
}

function hideSubNavs(nav) {
    $(`#cont-${nav} .sub-nav`).hide();
}

function displayNav(nav, norefresh = false) {
    if (nav == currentNav && !norefresh) {
        return;
    }
    if (disabledNavs.includes(nav)) {
        return;
    }
    if (!loadedNavs.includes(nav) && $("#cont-" + nav).children().length == 0) {
        console.log("Loading nav: " + nav);
        loadNav(nav);
    }
    if (Object.keys(UI).includes(currentNav)) {
        if (UI[currentNav].offload) {
            UI[currentNav].offload();
        }
    }
    if (Object.keys(PAGES).includes(currentNav)) {
        let page = PAGES[currentNav];
        if (page.onUnload) {
            page.onUnload();
        }
    }
    currentNav = nav;
    if (Object.keys(UI).includes(nav)) {
        if (UI[nav].onload) {
            UI[nav].onload();
        }
    }
    if (Object.keys(PAGES).includes(nav)) {
        let page = PAGES[nav];
        if (page.onload) {
            page.onload();
        }
    }
    for (let i = 0; i < navs.length; i++) {
        navs[i].classList.remove("active");
        navs[i].style.display = "none";
    }
    if (lowerNavs.includes(nav)) {
        $(".gui-cont .main-item").removeClass("selected");
        $(".lower-icon").removeClass("active");
        $("#" + nav).addClass("active");
    } else {
        $(".lower-icon").removeClass("active");
    }
    $("#cont-" + nav).show();
}

function toggleSideNav() {
    var closed = $("#left-gui").hasClass("closed");
    if (closed) {
        openSideNav();
    } else {
        collapseSideNav();
    }
}

function collapseSideNav() {
    $("#left-gui").width(0)
    $("#left-gui").css("left", "-95px")
    $("#collapse").css("transform", "translateY(-50%) rotate(180deg)")
    $("#left-gui").addClass("closed")
    $("#left-gui-content").hide()
    $("#left-gui-lower").hide()
    $("#notifications-num").hide();
    setTimeout(() => {
        $("#collapse")[0].src = "assets/menu.png"
    }, 200);
}


function openSideNav() {
    $("#left-gui").width("280px")
    $("#collapse").css("transform", "translateY(-50%)")
    $("#left-gui").removeClass("closed")
    $("#left-gui").css("left", 0)
    $("#left-gui-content").show()
    $("#left-gui-lower").show()
    setTimeout(() => {
        $("#collapse")[0].src = "assets/collapse.png"
        $("#notifications-num").show();
    }, 200);
}


function onloop() {
    $("#notifications-num").css("top", $("#notifications").position().top - 5 + "px");
    $("#notifications-num").css("left", $("#notifications").position().left + 25 + "px");
    $("#main")[0].style.width = `calc(100vw - ${$("#left-gui").width()}px)`
}

function InitGUIFocus(query, _surface = true) {
    $(query + " .nav-item:not(.disabled)").off("click");
    $(query + " .nav-item:not(.disabled)")[0].classList.add("selected");
    $(query + " .nav-item:not(.disabled)").on("click", function () {
        if ($(this).hasClass("iscustom")) {
            return;
        }
        if (_surface == false) {
            $(query + " .nav-item:not(.disabled)").removeClass("selected");
        }
        $(this).addClass("selected");
        if (_surface == true) {
            $(this).siblings().removeClass("selected");
        }
    });
}


function updateUrlParameter(key, value) {
    let targetWindow = window;

    // Check if we are running inside an iframe
    if (window !== window.parent) {
        try {
            // Attempt to access the parent's location. 
            // If it's cross-origin, this will throw an error.
            if (window.parent.location.href) {
                targetWindow = window.parent;
            }
        } catch (e) {
            console.warn("Cross-origin restriction: Cannot access parent window URL. Falling back to iframe URL.");
        }
    }

    const url = new URL(targetWindow.location.href); // Get the URL of the target window
    url.searchParams.set(key, value); // Set the new parameter value

    // Update the URL in the browser's address bar without reloading
    if (targetWindow.history.replaceState) {
        targetWindow.history.replaceState({}, '', url.toString());
    }
}

setInterval(onloop, 10);

function switchLoginTab(tab) {
    const loginForm = document.getElementById('login-form');
    const createForm = document.getElementById('create-form');
    const tabs = document.querySelectorAll('.login-tab');

    if (tab === 'login') {
        loginForm.classList.remove('hidden');
        createForm.classList.add('hidden');
        tabs[0].classList.add('active');
        tabs[1].classList.remove('active');
    } else {
        loginForm.classList.add('hidden');
        createForm.classList.remove('hidden');
        tabs[0].classList.remove('active');
        tabs[1].classList.add('active');
    }
}

async function HandleGeneralLogin(doSession = true) {
    const username_input = $('#login-username').val();
    const password_input = $('#login-password').val();
    const loginButton = $("#login-btn");
    if (loginButton.prop("disabled") == true) {
        return;
    }
    loginButton.prop("disabled", true);
    let _sesh = false;
    if (doSession && _params.get("session") !== null) {
        try {
            let localCreds = localStorage.getItem("ODN_session");
            let decrypted = CryptoJS.AES.decrypt(localCreds, _params.get("session")).toString(CryptoJS.enc.Utf8);
            loginButton.text("Logging in with session token...");
            _sesh = await sesh.LogInWithSession(_params.get("session"));
            if (!_sesh) {
                toast("error", "Session expired. Please login again.");
            }
        } catch (error) {
            toast("error", "Invalid session token.");
            _sesh = false;
        }
    }
    if (!_sesh && username_input !== "" && password_input !== "") {
        loginButton.text("Logging in...");
        _sesh = await sesh.LogIntoNet(username_input, password_input);
        if (!_sesh) {
            toast("error", "Login failed. Check your credentials.");
        }
    }

    if (_sesh) {
        // Update UI with user info
        try {
            UI.SideNav.lower.account[0].src = sesh.account.picture || 'assets/OASIS-connect.png'; // Fallback
            UI.SideNav.lower.username.text(sesh.account.username);
        } catch (e) { console.error("UI Update failed", e); }
        toast("success", "Login successful.", { duration: 2000 });
        initAfterLogin()
        hideLoginOverlay();
    } else {
        loginButton.prop("disabled", false);
        loginButton.text("Login");
    }
}

async function initAfterLogin() {
    let local = getLocalStorage();
    if (local) {
        toast("info", "Loaded data from localStorage", { duration: 2000 });
    }
    if (UI.AccountUI.username.length == 0) {
        initUI();
    }
    initMessageDB();
    sesh.initP2P();
    UI.AccountUI.funcs.loadAccountUI();
    UI.MessageUI.funcs.loadMessageUI();
    UI.CommunityUI.funcs.init();
    UI.notifications.funcs.updateBadge(0);
    updateUrlParameter("session", sesh.sessionToken);
    preCache();
    await sleep(2000);
    createNetworkNotiifcations();
    storageFunctions.saveNetworkEvents();
}



function hideLoginOverlay() {
    const overlay = document.getElementById('login-overlay');
    overlay.classList.add('hiding');
    setTimeout(() => {
        overlay.style.display = 'none';
    }, 800);
}


async function handleCreateAccount() {
    const username = $('#create-username').val();
    const email = $('#create-email').val();
    const password = $('#create-password').val();
    const confirmPassword = $('#create-password-confirm').val();
    const button = $("#create-account-btn");
    if (button.prop("disabled") == true) {
        return;
    }
    if (!username || !email || !password || !confirmPassword) {
        toast("error", "Please fill in all fields.");
        return;
    }

    if (password !== confirmPassword) {
        toast("error", "Passwords do not match.");
        return;
    }
    button.prop("disabled", true);
    button.text("Creating account...");
    const success = await sesh.requestNewAccount(username, password, email);
    if (success) {
        toast("success", "Account created successfully! Please login.");
        switchLoginTab('login');
    } else {
        toast("error", "Failed to create account. Username might be taken.");
    }
    button.prop("disabled", false);
    button.text("Create Account");
}

$("#login-password").on("keydown", function (e) {
    if (e.key === "Enter") {
        HandleGeneralLogin(false);
    }
});