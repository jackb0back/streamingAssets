/** @global */



function isFriend(intID) {
    if (!sesh.loggedIn) {
        throw new Error("Not logged in.");
    }
    return sesh.account.friends.includes(intID);
}

function updateAllStatusIndicatorsFor(intID) {
    let statusList = ["status-online", "status-dnd", "status-idle", "status-offline"];
    let statuses = $(`[data-status="${intToStrID(intID)}"]`);
    let statusTexts = $(`[data-status-text="${intToStrID(intID)}"]`);
    statuses.removeClass(statusList);
    let userStatus = cache.funcs.getStatus(intID);
    statuses.addClass("status-" + userStatus);
    statusTexts.text(userStatus);
}

function intToStrID(id) {
    return "#" + id.toString().padStart(4, '0');
}

function strToID(strID) {
    return parseInt(strID.replaceAll("#", ""));
}

function generateDMroomID(self_intID, peer_intID) {
    if (self_intID < peer_intID) {
        return CryptoJS.SHA256(intToStrID(self_intID) + ":" + intToStrID(peer_intID)).toString()
    } else {
        return CryptoJS.SHA256(intToStrID(peer_intID) + ":" + intToStrID(self_intID)).toString()
    }
}


function generateSigRoomID(intID) {
    //10 peers per room
    let roomNumber = Math.ceil(intID / 10);
    let roomID = intToStrID(roomNumber);
    console.log("Generated sig room ID: " + roomID)
    return CryptoJS.SHA256(roomID).toString();
    // return CryptoJS.SHA256(username + ":" + StrID).toString();
}

function smartTimestamp(timestamp) {
    // Convert input to a Date object
    const date = new Date(timestamp);
    const now = new Date();

    // Handle invalid dates
    if (isNaN(date.getTime())) {
        return "Invalid Date";
    }

    // 1. Format the time (e.g., "10:30 AM")
    const timeString = date.toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
    });

    // Helper: Check if two dates are on the exact same calendar day
    const isSameDay = (d1, d2) => {
        return d1.getFullYear() === d2.getFullYear() &&
            d1.getMonth() === d2.getMonth() &&
            d1.getDate() === d2.getDate();
    };

    // Helper: Calculate difference in days (ignoring time of day)
    const oneDayMs = 24 * 60 * 60 * 1000;
    // Reset time portions to midnight to compare purely by calendar day
    const midnightDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    const midnightNow = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const diffDays = Math.floor((midnightNow - midnightDate) / oneDayMs);

    // LOGIC BRANCHES

    // Case A: Today
    if (isSameDay(date, now)) {
        return `Today at ${timeString}`;
    }

    // Case B: Less than a week old (1 to 6 days ago)
    if (diffDays > 0 && diffDays < 7) {
        const dayOfWeek = date.toLocaleDateString('en-US', { weekday: 'long' });
        return `${dayOfWeek} at ${timeString}`;
    }

    // Case C: More than a week old (or in the future) -> dd/mm/yyyy
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed
    const year = date.getFullYear();

    return `${day}/${month}/${year} at ${timeString}`;
}


function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

if (page_param !== null) {
    if (!lowerNavs.includes(page_param)) {
        displayGUI(page_param);
    } else {
        console.log("Lower nav");
        displayGUI("main");
    }
    try {
        displayNav(page_param, true);
    } catch {
        displayNav("main", true);
    }
} else {
    displayGUI("main");
    displayNav("main", true);
}

if ((_params.get("session") !== null || _params.get("u") !== null && _params.get("p") !== null) && _params.get("nologin") === null) {
    /* DEV FEATURE */
    let user = _params.get("u");
    let pass = _params.get("p");
    if (user && pass) {
        document.querySelectorAll("#login-username")[0].value = user;
        document.querySelectorAll("#login-password")[0].value = pass;
        HandleGeneralLogin(false);
    } else {
        HandleGeneralLogin();
    }
    /*            */

}