/** @global */
const P2P_config = { appId: 'ODN_CONNECT' };


class TrysteroP2PNetwork {
    constructor(config) {
        /*
        config = {
            trysteroConfig: {},
            enableLogs: bool
        }
        */
        this.trysteroConfig = config.trysteroConfig || { appId: crypto.randomUUID() };
        this.trystero = {
            selfID: window.Trystero.selfId,
            joinRoom: window.Trystero.joinRoom,
        };
        this.routes = {};
        this.connections = {}; // room list => {roomName: {room: object, peers: [list]}}
        this.GlobalEvents = {
            "onPeerJoin": [],
            "onPeerLeave": [],
        }; // event list => {eventName: [func1, func2, ...]}
        this.reservedEvents = ["onPeerJoin", "onPeerLeave", "connectedTo"];
        this.returnPackets = {}
        this.enableLogs = config.enableLogs || false;


        /*
                TODO:
                Add return packets
                    - listener for specfic responses after a request.
                    - adds a promise to an object with unique ID
                    - custom timeout lengths 
        
        */


    }

    log(message) {
        if (this.enableLogs) {
            console.log("[P2P] " + message);
        }
    }


    async waitFor(roomID = false, Key, fromPeer, timeout = 5000) {
        if (!Key) { this.log("No key provided"); return; }
        let packetKey = fromPeer + ":" + Key //"packetType:key:peerID"
        let room = this.returnPackets[roomID];
        let data = {
            promise: null,
            resolve: null,
            reject: null,
            timeout: null,
            timeOutClear: function () {
                clearTimeout(this.timeout);
            }
        }
        let promise = new Promise((resolve, reject) => {
            let timeo = setTimeout(() => {
                reject("timeout");
            }, timeout);
            data.timeout = timeo;
            data.resolve = resolve;
            data.reject = reject;
        });
        data.promise = promise;

        if (!room) {
            this.returnPackets[roomID] = {};
            room = this.returnPackets[roomID];
        }
        room[packetKey] = data;
        return promise;
    }


    async invokeEvent(name, room = false, ...args) {
        this.log(`[invokeEvent] invoke event ${name} for ${room}`);
        if (room == false) {
            let GlobalEvent = this.GlobalEvents[name];
            if (GlobalEvent) {
                let toRemove = [];
                GlobalEvent.forEach((eve) => {
                    eve.func(...args);
                    if (eve.oneTime) {
                        toRemove.push(eve);
                    }
                });
                toRemove.forEach((eve) => {
                    this.GlobalEvents[name] = GlobalEvent.filter(item => item !== eve);
                });
            }
        } else {
            if (!this.connections[room]) {
                this.log(`[invokeEvent] Room '${room}' not found | ${name}`);
                return;
            }
            let Event = this.connections[room].events[name];
            if (Event) {
                let toRemove = [];
                Event.forEach((eve) => {
                    eve.func(...args);
                    if (eve.oneTime) {
                        toRemove.push(eve);
                    }
                });
                toRemove.forEach((eve) => {
                    this.connections[room].events[name] = Event.filter(item => item !== eve);
                });
            }
        }
    }

    async eventListener(roomID = false, event, func, oneTime = false) {
        if (roomID == false) {
            if (!this.GlobalEvents[event]) {
                this.GlobalEvents[event] = [];
            }
            this.GlobalEvents[event].push({
                oneTime: oneTime,
                func: func
            });
        } else {
            if (!this.connections[roomID]) {
                this.log(`[eventListener] Room '${roomID}' not found`);
                return;
            }
            if (!this.connections[roomID].events[event]) {
                this.connections[roomID].events[event] = [];
            }
            let _room = this.connections[roomID];
            this.connections[roomID].events[event].push({
                oneTime: oneTime,
                func: function () {
                    return func(_room, ...arguments);
                }
            });
        }
    }


    process(roomID, peer, packet) {
        let room = this.connections[roomID];
        if (!room) {
            this.log(`[process] Room '${roomID}' not found`);
            return;
        }
        let dataType = packet.dataType || "none";
        let data = packet.data;
        let returns = this.returnPackets[roomID] || false;
        let dataType_path;
        switch (dataType) {
            case "route": //route packet
                let route = packet.path;
                let routeObj = this.routes[route];
                if (routeObj) {
                    this.log("Processing packet from " + peer + " to route " + route);
                    this.log(`[process] ${routeObj.room == false} ${routeObj.room == roomID}`)
                    if (routeObj.room == false || routeObj.room == roomID) {
                        dataType_path = route;
                        routeObj.func({
                            peer: peer,
                            room: roomID,
                            signed: packet.signed
                        }, data);
                    }
                } else {
                    this.log(`Route '${route}' not found`);
                }
                break;
            case "event": //event packet
                let eventName = packet.event;
                /*
                {
                    dataType: "event",
                    event: name,
                    args: []
                }
                */
                if (this.reservedEvents.includes(eventName)) {
                    this.log("Reserved event name, aborting.");
                    break;
                }
                dataType_path = eventName;
                let args = packet.args || [];
                if (typeof (args) !== "object") {
                    try {
                        args = JSON.parse(args);
                    } catch {
                        args = [];
                    }
                }
                this.invokeEvent(eventName, roomID, ...packet.args);
                break;
            default:
                if (room.onData) {
                    room.onData(peer, packet);
                }
                break;
        }
        let packetKey = `${peer}:${dataType}:${dataType_path}`
        if (returns) {
            for (let returnKey in returns) {
                let ret = returns[returnKey];
                if (returnKey == packetKey) {
                    ret.timeOutClear();
                    ret.resolve(packet);
                    returns[returnKey] = null;
                }
            }
        }
    }

    newRoute(path, RouteFunc, opts = {}) {
        const _ = this;
        const room = opts.room || false;

        this.routes[path] = {
            room: room,
            func: function () {
                return RouteFunc(_, ...arguments)
            }
        }
    }


    disconnect(roomID, destroy = false) {
        if (this.connections[roomID]) {
            this.connections[roomID].room.leave();
            if (destroy) {
                delete this.connections[roomID];
            }
            this.log("Disconnected from room: " + roomID);
        } else {
            this.log("[disconnect] Could not find room: " + roomID);
        }
    }

    async connectTo(roomID, onData = false) {
        return new Promise(async (resolve, reject) => {
            let room = this.trystero.joinRoom(this.trysteroConfig, roomID, (error) => {
                this.log(error);
                reject(error);
            });
            let [sendPacket, getPacket] = room.makeAction('packet');
            room.onPeerJoin((peerID) => {
                this.log(`Peer '${peerID}' joined room: ${roomID}`);
                if (!this.connections[roomID].peers.includes(peerID)) {
                    this.connections[roomID].peers.push(peerID);
                }
                this.invokeEvent("onPeerJoin", roomID, peerID);
            });
            room.onPeerLeave((peerID) => {
                let conn = this.connections[roomID];
                this.log(`Peer '${peerID}' left room: ${roomID}`);
                if (conn) {
                    this.connections[roomID].peers = this.connections[roomID].peers.filter((_p) => _p !== peerID);
                }
                this.invokeEvent("onPeerLeave", roomID, peerID);
            });
            getPacket((data, peerID) => {
                this.process(roomID, peerID, data);
            });
            this.connections[roomID] = {
                room: room,
                peers: [],
                sendPacket: sendPacket,
                getPacket: getPacket,
                events: {},
                actions: {},
                roomID: roomID
            }
            if (onData) {
                this.connections[roomID].onData = onData;
            }
            this.log("[connect] Connected to room: " + roomID);
            this.invokeEvent("connectedTo", false, roomID);
            resolve(room);
        });
    }


    makeAction(room, actionName) {
        let roomObj = this.connections[room];
        if (!roomObj) {
            this.log("[makeAction] Room " + room + " not found.");
            return;
        }
        if (Object.keys(roomObj.actions).includes(actionName)) {
            this.log(`Action "${actionName}" does not exist for room "${room}"`);
        }
        let [actSend, actGet] = roomObj.room.makeAction(actionName);
        let actObj = {
            send: actSend,
            get: actGet
        }
        roomObj.actions[actionName] = actObj
        // actGet(onGet);
        return actObj;
    }

    async sendPacket(roomID, packet, peers = null) {
        return new Promise((resolve, reject) => {
            if (!this.connections[roomID]) {
                this.log(`[sendPacket] Room '${roomID}' not found`);
                this.log(`[sendPacket] packet: ${JSON.stringify(packet)}`)
                reject(`Room '${roomID}' not found`);
                return;
            }
            this.connections[roomID].sendPacket(packet, peers);
            resolve(true);
        });
    }

    async post(roomID, route, data = "", peers = null, signed = false) {
        return new Promise((resolve, reject) => {
            let packet = {
                dataType: "route",
                path: route,
                data: data,
                timestamp: Date.now()
            }
            if (signed !== false) {
                // packet.signed = {
                //     dataHash: "", //RSA(timestamp + data)
                //     username: "",
                //     publicKey: ""
                // };
                packet.signed = signed;
            }
            this.log(`[post] post to ${route} to users: ${peers} in room ${roomID}`)
            this.sendPacket(roomID, packet, peers);
            resolve(true);
        });
    }

}

class DMInstance {
    constructor(intID) {
        if (!sesh.loggedIn) {
            throw new Error("Not logged in.");
        }
        this.PID = intToStrID(intID);
        this.PIID = intID;
        this.intID = intID;
        this.p2p = sesh.P2P;
        this.peerIdentity = false;
        this.roomHash = false;
        this.ready = false;
        this.peerConnected = false;
        this.Messages = {
            "self": {},
            "peer": {}
        }
        this.Widget = false;
        this.WidgetOpts = {};
        //P2P Actions
        this.MessageAction = false;
        this.ReadAction = false;
        this.SyncAction = false;
        this.TypingAction = false;
        this.isOpen = false;
        //////////////////////
        this.messageList = []; //list of Message ID's
        //Determines how to process a message in the moment. 
        this.chatStatus = "disconnected" //disconnected | inRoom | chatting
        this.typingIndicator = {
            interval: null,
            typing: false,
            cancelAfter: 3000 //ms
        }
    }

    disconnect() {
        this.p2p.disconnect(this.roomHash);
        this.peerConnected = false;
        this.peerIdentity = false;
        this.chatStatus = "disconnected";
        this.ready = false;
    }

    reconnect() {
        this.init();
        this.renderAll();
    }

    async init() {
        // this.Peer = await getUser(this.intID);
        let selfIID = sesh.account.ID;
        let peerIID = this.PIID;
        this.roomHash = generateDMroomID(selfIID, peerIID);
        let _ = this;
        this.p2p.connectTo(this.roomHash);
        this.MessageAction = this.p2p.makeAction(this.roomHash, "message");
        this.ReadAction = this.p2p.makeAction(this.roomHash, "read");
        this.SyncAction = this.p2p.makeAction(this.roomHash, "sync");
        this.TypingAction = this.p2p.makeAction(this.roomHash, "type");

        this.MessageAction.get((packet, peerID) => this.recieveMessage(packet, peerID));
        this.ReadAction.get((messageHash, peerID) => this.messageRead(messageHash, peerID))
        this.SyncAction.get((syncData, peerID) => this.sync(syncData, peerID));
        this.TypingAction.get((isTyping, peerID) => {
            if (peerID !== _.peerIdentity.peerID) return;
            if (isTyping) {
                _.Widget.addTypingIndicator(_.peerIdentity.profile.username);
            } else {
                _.Widget.removeTypingIndicator(_.peerIdentity.profile.username);
            }
        });

        this.typingIndicator.interval = setInterval(function () {
            let lastInputUpdate = _.Widget.$lastInput;
            if ((lastInputUpdate + _.typingIndicator.cancelAfter) <= Date.now()) {
                if (_.typingIndicator.typing) {
                    _.typingIndicator.typing = false;
                    _.TypingAction.send(false);
                }
            } else {
                if (!_.typingIndicator.typing) {
                    _.typingIndicator.typing = true;
                    _.TypingAction.send(true);
                }
            }
        }, 200);
        this.p2p.eventListener(this.roomHash, "PeerAcknowledged", async function (roomObj, packet) {
            let peerID = packet.peer;
            let profile = packet.profile;
            console.log(profile, _.PID);
            if (profile.id == _.PID) {
                _.peerIdentity = {
                    peerID: peerID,
                    profile: profile,
                    RSA: new SimpleRSA(profile.key)
                }
                _.peerConnected = true;
                _.chatStatus = "chatting";
                _.Widget.updateUserStatus(_.PID, "online");
                _.requestSync();
                _.isOpen = true;
                await sleep(100);
                _.updateMessageStatuses();
            }
        });
        this.p2p.eventListener(this.roomHash, "onPeerLeave", async function (roomObj, peerID) {
            if (peerID == _.peerIdentity.peerID) {
                _.peerConnected = false;
                _.chatStatus = "inRoom";
                _.Widget.updateUserStatus(_.PID, "offline");
                console.log(`${_.peerIdentity.profile.username} has left the chat.`);
                // THEN RUN A STATUS PING TO UPDATE STATUS
                await sleep(500);
                // pingUser(_.peerIdentity.profile.username, _.peerIdentity.profile.ID);
                pingUser(_.peerIdentity.profile.ID).then(function (profile) {
                    _.Widget.updateUserStatus(_.PID, "idle");
                }).catch(function (err) {
                    _.Widget.updateUserStatus(_.PID, "offline");
                });
                _.peerIdentity = false;
            }
        });

        this.p2p.eventListener(this.roomHash, "onPeerJoin", async function (roomObj, peerID) {
            console.log(peerID + " Joined the chat.");
            _.p2p.post(_.roomHash, "/getProfile", sesh.publicProfile);
        });

        this.p2p.newRoute("/sync", function (self, req, syncRequest) {
            /*
            syncRequest: {
                blocklist: [],
                lastUpdate: timestamp
            }
            */
            if (req.peer == _.peerIdentity.peerID) {
                let blocklist = syncRequest.blocklist || [];
                let lastUpdate = syncRequest.lastUpdate || 0;
                let missing = _.messageList.filter(hash => !blocklist.includes(hash));
                let missing_messages = {}
                missing_messages[sesh.account.id] = _.Messages["self"]
                missing_messages[_.PID] = _.Messages["peer"]
                console.log("Missing messages:", missing);
                for (let hash of missing) {
                    _.messageRead(hash, req.peer);
                }
                if (missing.length == 0) {
                    _.SyncAction.send({
                        missing: false,
                    });
                } else {
                    _.SyncAction.send({
                        missing: missing,
                        messages: missing_messages
                    });
                }
            }
        }, {
            room: this.roomHash
        });
        this.chatStatus = "inRoom";
        let msgHistory = await MessageDB.getRoomHistory(this.roomHash);
        if (msgHistory.hashList.length > 0) {
            this.Messages.self = msgHistory[sesh.account.id] || {};
            this.Messages.peer = msgHistory[this.PID] || {};
            this.messageList = msgHistory.hashList;
            this.renderAll();
        }
        await sleep(500);
        this.ready = true;
    }

    sync(data, peerID) {
        if (peerID !== this.peerIdentity.peerID) { return };
        console.log("GOT SYNC:", data);
        if (data.missing == false) {
            console.log("Messages all up to date");
            return;
        }
        for (let hash of data.missing) {
            console.log("Syncing message: " + hash);
            let messages = data.messages[this.PID] || data.messages[sesh.account.id];
            let message = messages[hash];
            // console.log("MSG",message);
            let prevHash = message.prevHash;
            let authorID = message.author.strID;
            message.readAt = false;
            this.Messages[authorID == this.PID ? "peer" : "self"][hash] = message;
            let prevIndex = this.messageList.indexOf(prevHash);
            if (prevIndex == -1) {
                console.log("Previus index not found", prevHash, prevIndex)
                this.messageList.push(hash);
            } else {
                this.messageList.splice(prevIndex + 1, 0, hash);
            }
            MessageDB.addMessage(this.roomHash, message);
        }
        this.renderAll();
    }

    requestSync() {
        if (this.peerConnected) {
            let latestMessage = this.Messages.self[this.messageList.at(-1)] || this.Messages.peer[this.messageList.at(-1)]
            let lastestTimestamp;
            if (!latestMessage) {
                lastestTimestamp = 0;
            } else {
                lastestTimestamp = latestMessage.timestamp;
            }
            this.p2p.post(this.roomHash, "/sync", {
                blocklist: this.messageList,
                lastUpdate: lastestTimestamp
            }, this.peerIdentity.peerID);
        }
    }

    updateMessageStatuses() {
        for (let hash of this.messageList) {
            let MSG = this.Messages.peer[hash];
            console.log(MSG);
            if (MSG) {
                if (MSG.status == "recieved") {
                    this.Messages.peer[hash].status = "read";
                    this.ReadAction.send(hash);
                }
            }
        }
    }

    async renderAll() {
        let ident;
        if (!this.peerConnected) {
            console.warn("Peer not connected.");
            let user = await getUser(this.intID);
            ident = {
                peerID: false,
                profile: user,
                RSA: new SimpleRSA(user.key)
            }
        } else {
            ident = this.peerIdentity;
            this.updateMessageStatuses();
        }
        renderMessage({
            "mode": "all",
            "type": "dm",
            "hashList": this.messageList,
            "self": this.Messages.self,
            "peer": this.Messages.peer,
            "widget": this.Widget,
            "peerProfile": ident.profile
        });
    }


    messageRead(messageHash, peerID) {
        if (peerID !== this.peerIdentity.peerID) { return };
        let msg = this.Messages.peer[messageHash] || this.Messages.self[messageHash];
        if (msg.status == "read" || msg.readAt !== false) {
            return;
        }
        msg.readAt = Date.now();
        msg.status = "read";
        let CUI_UserMessage = this.Widget.MessageItems[messageHash];
        if (!CUI_UserMessage) {
            console.error("Could not find message: " + messageHash);
            return;
        }
        console.log("User read message " + messageHash, msg);
        CUI_UserMessage.updateStatus("read", {
            readAt: Date.now()
        });
        MessageDB.updateStatus(messageHash, "read", msg.readAt);
    }

    recieveMessage(messagePacket, peerID) {
        if (peerID !== this.peerIdentity.peerID) { return };
        let processed = processMessage(messagePacket);
        console.log("Processed message:", processed);
        let prevHash = this.messageList.at(-1);
        if (!prevHash) {
            prevHash = CryptoJS.SHA256("HASH ZERO").toString();
        }
        let message_newHash = processed.hash;
        let message_prevHash = processed.prevHash;
        let rawCompHashStr = `${processed.author.combString}|${processed.messageHash}|${processed.timestamp}|${message_prevHash}`;
        let computedHash = CryptoJS.SHA256(rawCompHashStr).toString()
        if (computedHash == message_newHash) {
            console.log("Valid block.");
            //store the message
            let toStore = {
                "author": processed.author,
                "rawMessage": processed.rawMessage,
                "hash": processed.hash,
                "prevHash": processed.prevHash,
                "timestamp": processed.timestamp,
                "readAt": Date.now(),
                "status": "read"
            }
            this.messageList.push(processed.hash);
            this.Messages.peer[processed.hash] = toStore;
            MessageDB.addMessage(this.roomHash, toStore);
            renderMessage({
                "mode": "append",
                "message": toStore,
                "type": "dm",
                "messageOptions": {
                    "status": "read",
                },
                "widget": this.Widget,
                "peerProfile": this.peerIdentity.profile
            });
            this.ReadAction.send(toStore.hash);
        } else {
            console.log("INVALID BLOCK");
            console.log("Computed:", computedHash, "message hash:", message_newHash, "raw:", rawCompHashStr);
        }
    }

    async sendMessage(msgText) {
        let ident;
        if (!this.peerConnected) {
            console.warn("Peer not connected.");
            let user = await getUser(this.intID);
            ident = {
                peerID: false,
                profile: user,
                RSA: new SimpleRSA(user.key)
            }
        } else {
            ident = this.peerIdentity;
            this.TypingAction.send(false);
        }
        let prevHash = this.messageList.at(-1) || false;
        let message = new Message(sesh.account, sesh.RSAkeys, msgText, prevHash);
        let peerPublicKey = ident.RSA.keypair.public;
        let encrypted = message.encryptFor(peerPublicKey);
        let toStore = message.messagePacket;
        toStore.readAt = false;
        // toStore.status = this.peerConnected ? "sent" : "waiting"
        if (this.peerConnected) {
            toStore.status = "sent";
            this.MessageAction.send(encrypted);
        } else {
            if (!cache.statusCache[this.PID]) {
                await pingUser(this.PIID);
            }
            if (cache.funcs.getStatus(this.PIID) == "online") {
                whisperTo(this.PIID, encrypted);
                toStore.status = "sent";
            } else {
                toStore.status = "waiting";
            }
        }
        MessageDB.addMessage(this.roomHash, toStore);
        this.messageList.push(toStore.hash);
        this.Messages.self[toStore.hash] = toStore;
        renderMessage({
            "mode": "append",
            "message": toStore,
            "type": "dm",
            "messageOptions": {
                "status": toStore.status,
            },
            "widget": this.Widget,
            "peerProfile": sesh.publicProfile
        });
    }

    initChatWidget(chat_options = {}) {
        this.WidgetOpts = chat_options;
        $("#chat-" + this.roomHash).remove();
        UI.MessageUI.chatwidget.append(`<div class="chat-instance" id="chat-${this.roomHash}"></div>`);
        this.Widget = new ChatWidget(`chat-${this.roomHash}`, this.WidgetOpts);
    }

    openWidget() {
        if (this.Widget) {
            this.Widget.open(this.WidgetOpts.inChat[0].username);
        }
    }

    minimize() {
        let _ = this;
        let p2p = this.p2p;
        this.isOpen = false;
        this.Widget.close();
        // if (instance) {
        //     p2p.SendAction(this.PeerJSID, "chat_status", false);
        // }
    }
}