let settings = {
    general: {
        notificationsSound: false,
        messageNotifications: true,
    },
    cloud: {
        syncMessages: true,
    },
    home: {
        clock: true,
        notifications: true,
        client: true,
        news: true,
    },
    network: {
        EnableCacheServer: true,
        MDBHost: "https://script.google.com/macros/s/AKfycbxjc1j5tYoJjjpptZqTzB20dCbqyifPbrnwvw16_Q-dsvpIVdEBL_K46BhXmg7hpCVU/exec",
        CacheServerHost: "N/A",
    }
}


var storageSettingsLocalChartOptions = {
    series: [{
        name: 'DMs',
        data: [10]
    }, {
        name: 'Room logs',
        data: [10]
    }, {
        name: 'System',
        data: [10]
    },
    {
        name: "Free",
        data: [70],
        color: "#444444ff"
    }],
    chart: {
        type: 'bar',
        height: 140,
        stacked: true,
        stackType: '100%'
    },
    plotOptions: {
        bar: {
            horizontal: true,
        },
    },
    // stroke: {
    //     width: 0,
    //     colors: ['#fff']
    // },
    xaxis: {
        categories: [""],
    },
    legend: {
        position: 'bottom',
        lables: {
            colors: '#ffffff',
            useSeriesColors: true,
        }
    },
    dataLabels: {
        enabled: true,
        style: {
            colors: ['#ffffff'],
        }
    },
    tooltip: {
        y: {
            formatter: function (val) {
                return val + "%"
            }
        }
    },
    fill: {
        opacity: 1,
    },
};


function importSettings(settingData) {
    for (let section in settingData) {
        for (let setting in settingData[section]) {
            settings[section][setting] = settingData[section][setting];
        }
    }
    UI.SettingsUI.funcs.loadSettings();
}
