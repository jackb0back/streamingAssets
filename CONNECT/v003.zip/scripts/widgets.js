function updateClock() {
    const now = new Date();

    // Time
    const timeString = now.toLocaleTimeString('en-US', {
        hour12: true,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
    document.getElementById('clock-time').textContent = timeString;

    // Date
    const dateString = now.toLocaleDateString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric'
    });
    document.getElementById('clock-date').textContent = dateString;
}

function cleanWhitespace(str) {
    // 1. Replace all whitespace sequences (newlines, tabs, spaces) with a single space
    // 2. Trim the outer edges
    return str.replace(/\s*[\r\n]+\s*/g, '\n').trim();
}

// Start clock
setInterval(updateClock, 1000);
updateClock();
