class ChatUI_SystemMessage {
    constructor(type, event) {
        /*
            event: {
                username: string,
                action: string,
            }
        */
        this.type = type;
        this.event = event;
        this.time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    get html() {
        let icon = "";
        switch (this.type) {
            case "join":
                icon = "assets/enter.png";
                break;
            case "leave":
                icon = "assets/exit.png";
                break;
        }
        return `
            <div class="system-message">
                <img class="system-message-icon" src="${icon}" alt="">
                <div class="system-message-content">
                    <strong>${this.event.username}</strong> ${this.event.action}. <span class="system-message-timestamp">Today at
                        ${this.time}</span>
                </div>
            </div>
        `;
    }
}

class ChatUI_UserMessage {
    // constructor(username, message, status = 'waiting', statusDetails = {}) {
    constructor(profile, packet, options) {
        console.log("FUCKING OPTIONS:",options);
        options = {
            status: options.status || "waiting", // waiting | sent | read
            statusDetails:  {
                readAt: options.readAt || undefined,
                count: options.count || undefined
            } // {count: int, time: "string"}
        }
        if (!options || !profile) {
            console.log(options, profile);
            throw new Error("profile or options not provided")
        }
        // this.username = username;
        this.profile = profile;
        this.username = profile.username;
        this.messagePacket = packet;
        this.message = packet.rawMessage;
        this.time = packet.timestamp;
        this.status = options.status;
        this.statusDetails = options.statusDetails;
        this.id = packet.hash;
        this.parsedMessage = this.parseMessage();
    }

    parseMessage() {
        let parsed = this.message;
        const placeholders = [];

        // Helper to store placeholder
        const storePlaceholder = (content) => {
            const id = `__PLACEHOLDER_${placeholders.length}__`;
            placeholders.push(content);
            return id;
        };

        // 1. Existing Image parsing: !img[url]
        parsed = parsed.replace(/!img\[(.*?)\]/g, (match, url) => {
            return storePlaceholder(`<img src="${url}" alt="Image">`);
        });

        // 2. Custom Link parsing: (url)[text]
        // Supports optional space between ) and [ and robust text matching (including newlines)
        parsed = parsed.replace(/\((.*?)\)\s*\[([^\]]*?)\]/g, (match, url, text) => {
            return storePlaceholder(`<a href="${url}" target="_blank">${text}</a>`);
        });

        // 3. Raw URL parsing
        // Matches http/https URLs that are not part of the existing structure (handled by placeholders)
        const urlRegex = /(https?:\/\/[^\s]+)/g;
        parsed = parsed.replace(urlRegex, (url) => {
            return storePlaceholder(`<a href="${url}" target="_blank">${url}</a>`);
        });

        // 4. Newlines
        parsed = parsed.replace(/\n/g, '<br>');

        // 5. Restore placeholders
        placeholders.forEach((content, index) => {
            parsed = parsed.replace(`__PLACEHOLDER_${index}__`, content);
        });

        return parsed;
    }

    get html() {
        let statusHtml = this.getStatusHtml();

        return `
            <div class="message-group" id="${this.id}">
                <img class="avatar" src="${this.profile.picture}" alt="Jackboback">
                <div class="message-content">
                    <div class="message-meta">
                        <span class="username" style="color: white;">${this.username}</span>
                        <span class="timestamp">${smartTimestamp(this.time)}</span>
                    </div>
                    <div class="message-text">${this.parsedMessage}</div>
                    <div class="message-status">
                        ${statusHtml}
                    </div>
                </div>
            </div>
        `;
    }

    getStatusHtml() {
        switch (this.status) {
            case 'waiting':
                return `<span class="status-text">Waiting to be sent</span><span class="status-icon">🕒</span>`;
            case 'sent':
                return `<span class="status-text">Sent</span><span class="status-icon">✓</span>`;
            case 'recieved':
                return `<span class="status-text">Recieved</span><span class="status-icon">✓</span>`
            case 'read':
                if (this.statusDetails.count) {
                    return `<span class="status-text">Read by ${this.statusDetails.count} people</span><span class="status-icon" style="color: #3ba55c;">✓✓</span>`;
                } else if (this.statusDetails.readAt && this.profile.id == sesh.account.id) {
                    return `<span class="status-text">Read ${smartTimestamp(this.statusDetails.readAt)}</span><span class="status-icon" style="color: #3ba55c;">✓✓</span>`;
                } else {
                    return `<span class="status-text">Read</span><span class="status-icon" style="color: #3ba55c;">✓✓</span>`;
                }
            default: return '';
        }
    }

    updateStatus(newStatus, details = {}) {
        this.status = newStatus;
        this.statusDetails = { ...this.statusDetails, ...details };
        const $el = $(`#${this.id}`);
        if ($el.length) {
            $el.find('.message-status').html(this.getStatusHtml());
        }
    }
}

class ChatWidget {
    constructor(containerId, options = {}) {
        this.containerId = containerId;
        this.$container = $(`#${containerId}`);
        this.title = options.title || "Chat";
        this.time = options.time || 0; //time in seconds
        this.username = options.username || sesh.account.username || "<ERROR>"; // Default user
        this.inChat = options.inChat || [];
        this.chatterStatus = {};
        this.isRoom = options.isRoom || false;
        this.instanceID = options.instanceID || false;
        this.isFavorite = options.isFavorite || false;
        this.widgetID = generateChatWidgetID(this.username, this.inChat);
        this.MessageItems = {};
        this.typingUsers = []; // Array to track users currently typing
        this.$lastInput = 0;
        this.init();
    }

    init() {
        for (let user of this.inChat) {
            this.chatterStatus[user.id] = "offline";
        }
        this.render();
        this.cacheDOM();
        this.bindEvents();
    }

    updateUserStatus(strID, status) {
        if (this.chatterStatus[strID]) {
            let sitem = this.$container.find(`[data-user="${strID}"]`);
            sitem.find(".chat-user-status-dot").removeClass("status-"+this.chatterStatus[strID]);
            this.chatterStatus[strID] = status;
            sitem.find(".chat-user-status-dot").addClass("status-"+status);
        }
    }


    get timeInRoom() {
        const seconds = this.time;
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        if (hours > 0) {
            return `${hours}h ${minutes % 60}m`;
        } else if (minutes > 0) {
            return `${minutes}m`;
        } else {
            return `${seconds}s`;
        }
    }

    render() {
        this.$container.addClass('chat-widget-host');

        // Mock Users Data
        // const users = [
        //     { name: "Jackboback", status: "online", time: "10min", avatar: "https://jackboback.dev/res/assets/favicon.ico" },
        //     { name: "Jane Doe", status: "idle", time: "25s", avatar: "assets/people.png" },
        //     { name: "John Smith", status: "dnd", time: "40s", avatar: "assets/people.png" },
        //     { name: "Alice W.", status: "offline", time: "5min", avatar: "assets/people.png" }
        // ];

        // determine if this is a room based on container ID (hacky but works for now)

        let usersHtml = this.inChat.map(user => `
            <div class="chat-user-item" data-user="${user.id}">
                <div class="chat-user-avatar">
                    <img src="${user.picture}" alt="${user.username}">
                    <div class="chat-user-status-dot status-${this.chatterStatus[user.id]}"></div>
                </div>
                <div class="chat-user-info">
                    <span class="chat-user-name">${user.username}</span>
                    <span class="chat-user-id">${user.id}</span>
                    ${this.isRoom ? `<span class="chat-user-time">Joined ${user.time} ago</span>` : ''}
                </div>
            </div>
        `).join('');

        const html = `
            <div class="chat-container">
                <div class="chat-header">
                    <h3><span style="color: #72767d;">@</span><span class="chat-title">${this.title}</span></h3>
                    <div class="chat-header-actions">
                        ${!this.isRoom ? `
                        <button class="header-action-btn" title="Start Video Call">
                            <img src="assets/video.png" alt="video call">
                        </button>
                        <button class="header-action-btn" title="Start Voice Call">
                            <img src="assets/call.png" alt="voice call">
                        </button>
                        <button class="header-action-btn dm-favorite-btn" title="${this.isFavorite ? 'Unfavorite' : 'Favorite'}">
                            <img src="assets/${this.isFavorite ? 'star-colored' : 'star'}.png" alt="favorite">
                        </button>
                        ` : ''}
                        <button class="header-action-btn" title="Info">
                            <img src="assets/info.png" alt="info">
                        </button>
                        <button class="header-action-btn chat-hide-btn" title="Hide Sidebar">
                            <img src="assets/collapse.png" alt="Hide">
                        </button>
                    </div>
                </div>
                
                <div class="chat-body">
                    <div class="chat-main">
                        <div class="chat-messages"></div>
                        <div class="chat-input-area">
                        <div class="chat-typing-indicator" style="display: none;">
                            <div class="typing-dots">
                                <span class="typing-dot"></span>
                                <span class="typing-dot"></span>
                                <span class="typing-dot"></span>
                            </div>
                            <span class="typing-text"></span>
                        </div>
                            <div class="chat-input-wrapper">
                                <button class="chat-action-btn" title="Upload File"><img src="assets/add.png"></button>
                                <button class="chat-action-btn" title="Attach Image"><img src="assets/picture.png"></button>
                                <button class="chat-action-btn" title="placeholder"><img src="assets/link.png"></button>
                                <textarea class="chat-textarea" placeholder="Send message..." rows="1"></textarea>
                                <button class="chat-send-btn"><img src="assets/send.png"></button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="chat-sidebar">
                        <div class="chat-sidebar-header">${this.isRoom ? 'Members — 4' : 'In Chat — 4'}</div>
                        <div class="chat-user-item">
                            <div class="chat-user-avatar">
                                <img src="${sesh.account.picture}" alt="${this.username}">
                                <div class="chat-user-status-dot status-online"></div>
                            </div>
                            <div class="chat-user-info">
                                <span class="chat-user-name" style="color: #3ba55c;">${this.username}</span>
                                <span class="chat-user-id">${sesh.account.id}</span>
                                ${this.isRoom ? `<span class="chat-user-time">Joined ${this.timeInRoom} ago</span>` : ''}
                            </div>
                        </div>
                        ${usersHtml}
                    </div>
                </div>
            </div>
        `;
        this.$container.html(html);
        this.$container.hide();
    }

    cacheDOM() {
        this.$chatContainer = this.$container.find('.chat-container');
        this.$messages = this.$container.find('.chat-messages');
        this.$input = this.$container.find('.chat-textarea');
        this.$sendBtn = this.$container.find('.chat-send-btn');
        this.$title = this.$container.find('.chat-title');
        this.$favoriteBtn = this.$container.find('.dm-favorite-btn');
        this.$sidebar = this.$container.find('.chat-sidebar');
        this.$hideBtn = this.$container.find('.chat-hide-btn');
        this.$typingIndicator = this.$container.find('.chat-typing-indicator');
    }

    bindEvents() {
        // Auto-resize textarea
        this.$input.on('input', () => {
            this.$input.css('height', 'auto');
            this.$input.css('height', this.$input[0].scrollHeight + 'px');
            this.$lastInput = Date.now();
        });

        this.$sendBtn.on('click', () => this.sendMessage());

        this.$input.on('keypress', (e) => {
            if (e.which == 13 && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });

        this.$favoriteBtn.on('click', async () => {
            this.isFavorite = !this.isFavorite;
            this.$favoriteBtn.find('img').attr('src', `assets/${this.isFavorite ? 'star-colored' : 'star'}.png`);
            this.$favoriteBtn.attr('title', this.isFavorite ? 'Unfavorite' : 'Favorite');
            if (this.isFavorite) {
                storageFunctions.addFavoriteContact(this.inChat[0].ID);
            } else {
                storageFunctions.removeFavoriteContact(this.inChat[0].ID);
            }
            await UI.MessageUI.funcs.displayFavoriteChats();
            await UI.MessageUI.funcs.displayRecentChats();
            selectNavItem("messages", `[data-username="${this.inChat[0].username}"]`);
        });

        this.$hideBtn.on('click', () => {
            if (this.$sidebar.is(":visible")) {
                this.$sidebar.hide();
                this.$hideBtn.css("transform", "rotate(180deg)");
                this.$hideBtn.attr("title", "Show Sidebar");
            } else {
                this.$sidebar.show();
                this.$hideBtn.css("transform", "rotate(0deg)");
                this.$hideBtn.attr("title", "Hide Sidebar");
            }
        });

    }

    sendMessage_deprecated() {
        let msg = this.$input.val();
        // Simple whitespace check
        if (msg.trim().length > 0) {

            // Create User Message Object
            const userMsg = new ChatUI_UserMessage(this.username, msg);

            // Append HTML
            this.$messages.append(userMsg.html);
            this.$input.val('');
            this.$input.css('height', 'auto');

            // Scroll to bottom
            this.$messages.animate({ scrollTop: this.$messages.prop("scrollHeight") }, 500);

            // Simulate Status Updates
            setTimeout(() => {
                userMsg.updateStatus('sent');
            }, 1500);

            setTimeout(() => {
                userMsg.updateStatus('read', { time: "10:00pm" });
            }, 3500);
        }
    }

    sendMessage() {
        let msg = this.messageInput;
        if (msg.length > 0) {
            if (this.instanceID == false) {
                console.error("No instance id provided, the fuck?");
                return;
            }
            if (this.isRoom) {
                //is chatroom
            }else {
                //not a chatroom
                MessageInstances[this.instanceID].sendMessage(msg);
                this.resetMessageInput();
            }
        }
    }


    resetMessageInput(scroll = true) {
        this.$input.val('');
        this.$input.css('height', 'auto');
        if (scroll) {
            this.$messages.animate({ scrollTop: this.$messages.prop("scrollHeight") }, 500);
        }
    }

    get isVisible() {
        return this.$container.is(":visible");
    }

    get messageInput() {
        let msg = this.$input.val();
        return msg.trim()
    }

    get isAtBottom() {
        const element = this.$messages[0];
        const tolerance = 20; 
        return (element.scrollHeight - element.scrollTop - element.clientHeight) <= tolerance;
    }

    scrollToBottom() {
        this.$messages.stop().animate({ 
            scrollTop: this.$messages.prop("scrollHeight") 
        }, 500);
    }

    renderNewMessage(CUI_UserMessage) {
        const shouldScroll = this.isAtBottom;
        this.MessageItems[CUI_UserMessage.id] = CUI_UserMessage;
        this.$messages.append(CUI_UserMessage.html);
        if (shouldScroll) {
            this.$messages.stop().animate({ 
                scrollTop: this.$messages.prop("scrollHeight") 
            }, 500);
        } else {
            // Optional: Show a "New Message" toast/button here since we didn't scroll
        }
    }

    clear() {
        this.$messages.empty();
    }

    open(title) {
        if (title) {
            this.title = title;
            this.$title.text(this.title);
        }
        this.$container.hide();

        // Reset and show
        this.$messages.empty();

        // Add fake join message
        // const joinMsg = new ChatUI_SystemMessage("join", { username: this.username, action: "has joined the chat" });
        // this.$messages.append(joinMsg.html);

        // //IMAGE TEST
        // const imgMsg = new ChatUI_UserMessage(this.username, "!img[https://sandovallegacygroup.com/wp-content/uploads/2025/08/Screenshot-2025-08-14-at-9.19.56-AM-854x675.png]");
        // this.$messages.append(imgMsg.html);
        //

        setTimeout(() => {
            this.$container.show();
        }, 100);

        // If this is the messages chat, we need to hide the contacts list.
        // This is a bit of a special case linkage. 
    }

    close() {
        this.$container.hide();
    }

    /**
     * Add a user to the typing indicator
     * @param {string} username - The username of the user who is typing
     */
    addTypingIndicator(username) {
        // Only add if not already in the array
        if (!this.typingUsers.includes(username)) {
            this.typingUsers.push(username);
            this.updateTypingDisplay();
        }
    }

    /**
     * Remove a user from the typing indicator
     * @param {string} username - The username of the user who stopped typing
     */
    removeTypingIndicator(username) {
        const index = this.typingUsers.indexOf(username);
        if (index > -1) {
            this.typingUsers.splice(index, 1);
            this.updateTypingDisplay();
        }
    }

    /**
     * Update the typing indicator display based on current typing users
     */
    updateTypingDisplay() {
        const count = this.typingUsers.length;
        const $typingText = this.$typingIndicator.find('.typing-text');

        if (count === 0) {
            // Hide the indicator if no one is typing
            this.$typingIndicator.hide();
        } else if (count === 1) {
            // Show single user typing
            $typingText.text(`${this.typingUsers[0]} is typing`);
            this.$typingIndicator.show();
        } else if (count === 2) {
            // Show two users typing
            $typingText.text(`${this.typingUsers[0]} and ${this.typingUsers[1]} are typing`);
            this.$typingIndicator.show();
        } else if (count === 3) {
            // Show three users typing
            $typingText.text(`${this.typingUsers[0]}, ${this.typingUsers[1]}, and ${this.typingUsers[2]} are typing`);
            this.$typingIndicator.show();
        } else {
            // Show count for more than 3 users
            $typingText.text(`${count} people are typing`);
            this.$typingIndicator.show();
        }
    }
}

// Global instances (to be initialized)
let messageChatWidget;
let roomChatWidget;

$(document).ready(function () {
    // We will initialize these after the placeholders are in index.html, 
    // but since this script runs on load, we assume placeholders might exist or we wait.

    // Actually, looking at index.html, scripts are at bottom of body.

    // But we haven't updated index.html yet! 
    // So this code might error if we don't have the elements.
    // However, the class definition is fine. 

    // We'll expose a function to init them or just do it if elements exist.
    // if ($('#chat-widget-messages').length) {
    //     messageChatWidget = new ChatWidget('chat-widget-messages');
    // }

    // if ($('#chatrooms-messages').length) {
    //     roomChatWidget = new ChatWidget('chatrooms-messages', { title: "Global Room" });
    //     // Show by default for chatrooms? Or wait for selection?
    //     // Current design: Chatrooms UI has nav items.
    // }
});

// Global functions for compatibility with existing onclick handlers

function generateChatWidgetID(username, inChat) {
    return CryptoJS.SHA256(username + "-" + inChat.map(user => user.username).sort().join('-')).toString();
}




function openRoom(name) {
    if (roomChatWidget) {
        hideSubNavs("chatrooms");
        roomChatWidget.open(name);
    }
}

