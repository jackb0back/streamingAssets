/** @global */
let MessageInstances = {};
let currentDM = false;


class Message {
    constructor(authorProfile, authorSimpleRSA, content, prevHash = false) {
        this.authorProfile = authorProfile;
        this.author = {
            username: authorProfile.username,
            intID: authorProfile.ID,
            strID: authorProfile.id,
            combString: authorProfile.username + ":" + authorProfile.id
        }
        this.rawMessage = content;
        this.messageHash = CryptoJS.SHA256(content).toString();
        this.prevHash = prevHash;
        if (this.prevHash == false) {
            this.prevHash = CryptoJS.SHA256("HASH ZERO").toString();
        }
        this.timestamp = Date.now();
        if (!authorProfile.keypair.private) {
            throw new Error("Author private key not found.")
        }
        if (!authorSimpleRSA) {
            throw new Error("Author simpleRSA instance not provided.");
        }
        this.keys = authorSimpleRSA;
    }

    get hash() {
        let rawhashStr = `${this.author.combString}|${this.messageHash}|${this.timestamp}|${this.prevHash}`;
        console.log(rawhashStr)
        return CryptoJS.SHA256(rawhashStr).toString()
    }

    get messagePacket() {
        return {
            "author": this.author,
            "rawMessage": this.rawMessage,
            "timestamp": this.timestamp,
            "hash": this.hash,
            "prevHash": this.prevHash
        }
    }

    encryptFor(peerPublicKey) {
        let rsa = new SimpleRSA(peerPublicKey);
        let packet = this.messagePacket;
        let decryptionKey = generateUUID();
        packet.decryptionKey = rsa.encrypt(decryptionKey);
        packet.message = CryptoJS.AES.encrypt(packet.rawMessage, decryptionKey).toString();
        packet.rawMessage = undefined;
        console.log(packet);
        return packet;
    }
}


async function whisperTo(intID, messagePacket) {
    if (!sesh.loggedIn) return;
    let peerJSID = generatePeerJSID(intID);
    let p2p = sesh.P2P;

    let instance = p2p.instances[peerJSID];
    if (!instance || !instance.connected) {
        p2p.connect(peerJSID);
    }

    if (!instance || !instance.connected) await sleep(1000);
    p2p.SendAction(peerJSID, "whisper", messagePacket);
}

function processWhisper(messagePacket, peerID) {
    console.log("Hip hip horray! a whisper packet has appeared!", messagePacket, peerID);
    cache.funcs.updateStatus(messagePacket.author.intID, peerID, "online");
    let processed = processMessage(messagePacket);
    let DM_RID = generateDMroomID(sesh.account.ID, processed.author.intID);
    console.log(processed);
    let notifMessage;
    if (processed.rawMessage.length > 20) {
        notifMessage = processed.rawMessage.slice(0, 20) + "...";
    } else {
        notifMessage = processed.rawMessage;
    }
    toast("message", notifMessage, {
        position: "bottom-right",
        userID: processed.author.intID,
        duration: 8000
    });
    let toStore = {
        "author": processed.author,
        "rawMessage": processed.rawMessage,
        "hash": processed.hash,
        "prevHash": processed.prevHash,
        "timestamp": processed.timestamp,
        "readAt": false,
        "status": "recieved"
    }
    MessageDB.addMessage(DM_RID, toStore);
}

function processMessage(packet) {
    console.log("Processing message packet", packet);
    let decryptionKey = sesh.RSAkeys.decrypt(packet.decryptionKey);
    packet.rawMessage = CryptoJS.AES.decrypt(packet.message, decryptionKey).toString(CryptoJS.enc.Utf8);
    packet.messageHash = CryptoJS.SHA256(packet.rawMessage).toString();
    delete packet.message;
    delete packet.decryptionKey;
    return packet;
}

function renderMessage(options) {
    options = {
        mode: options.mode || false, //"all"|"append"
        peerProfile: options.peerProfile,
        // append
        message: options.message,
        messageOptions: options.messageOptions,
        // all (dm|chatrooms)
        hashList: options.hashList || [], //[],
        self: options.self || {}, //<messages>
        peer: options.peer || {}, //<messages> (dm)
        peers: options.peers || {}, //{<messages>} (chatroom)
        ////////////////////////
        type: options.type || false, //"dm"|"chatroom"
        widget: options.widget || false //<ChatWidget>
    }
    if (!options.mode || !options.type || !options.widget) {
        console.log(options);
        throw new Error("option mode, type, or widget not provided.");
    }
    let widget = options.widget;
    if (options.type == "dm") {
        if (options.mode == "all") {
            widget.clear();
            for (let hash of options.hashList) {
                let message = options.self[hash] || options.peer[hash];
                console.log(message, options.self, options.peer, hash);
                let profile;
                if (message.author.strID == sesh.account.id) {
                    profile = sesh.publicProfile;
                } else {
                    profile = options.peerProfile;
                }
                let UserMessage = new ChatUI_UserMessage(profile, message, {
                    "status": message.status,
                    "readAt": message.readAt == false ? 0 : message.readAt
                });
                console.log("Render message: " + hash, UserMessage);
                widget.renderNewMessage(UserMessage);
            }
            widget.scrollToBottom();
        }
        if (options.mode == "append") {
            let message = options.message;
            let UserMessage = new ChatUI_UserMessage(options.peerProfile, message, options.messageOptions)
            widget.renderNewMessage(UserMessage);
        }
    }

    if (options.type == "chatroom") {
        if (options.mode == "all") {

        }
        if (options.mode == "append") {

        }
    }

}



function showContacts() {
    if (MessageInstances[currentDM]) {
        MessageInstances[currentDM].minimize();
        MessageInstances[currentDM].disconnect();
        $(".contacts-container").show();
    }
}


async function openChat(intID) {
    let user = await getUser(intID);
    if (!user) {
        return;
    }
    storageFunctions.addRecentContact(intID);
    await UI.MessageUI.funcs.displayRecentChats();
    let _recent = $(`.gcm-messages-recent[data-username="${user.username}"]`);
    let _favorite = $(`.gcm-messages-favorite[data-username="${user.username}"]`);
    $("#gui-cont-messages .nav-item.selected").removeClass('selected');
    if (_favorite.length !== 0) {
        console.log("Favorite", _favorite);
        _favorite.addClass('selected');
    } else {
        if (_recent.length !== 0) {
            console.log("Recent", _recent);
            _recent.addClass('selected');
        }
    }
    let chat_options = {
        isFavorite: _favorite.length !== 0,
        inChat: [user],
        instanceID: intToStrID(intID)
    };
    $('.contacts-container').hide();
    let DMI = MessageInstances[user.id];
    let prev = MessageInstances[currentDM];
    if (prev) {
        prev.Widget.close()
    }
    if (!DMI) {
        DMI = new DMInstance(intID);
        DMI.init();
        DMI.initChatWidget(chat_options);
        MessageInstances[user.id] = DMI;
    } else {
        DMI.reconnect();
    }
    DMI.openWidget();
    currentDM = user.id;
}
