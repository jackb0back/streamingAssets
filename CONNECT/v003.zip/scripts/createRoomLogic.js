// Chatroom Creation GUI Toggles
// Chatroom Creation GUI Toggles
function toggleCustomImageInput() {
    const select = document.getElementById('room-image');
    const customInput = document.getElementById('custom-image-url');
    const preview = document.getElementById('room-image-preview');

    if (select && customInput) {
        if (select.value === 'custom') {
            customInput.style.display = 'block';
            // Try to set preview to custom URL if it exists, otherwise placeholder or keep previous?
            // Better UX: keep previous or set to a default 'no image' icon until they type. 
            // For now, let's just trigger the custom helper.
            updatePreviewFromCustom();
        } else {
            customInput.style.display = 'none';
            if (preview) {
                preview.src = select.value;
            }
        }
    }
}

function updatePreviewFromCustom() {
    const customInput = document.getElementById('custom-image-url');
    const preview = document.getElementById('room-image-preview');
    if (customInput && preview) {
        if (customInput.value.trim() !== "") {
            preview.src = customInput.value;
            // Handle error? 
            preview.onerror = function () {
                this.src = 'assets/browse.png'; // Fallback
            };
        } else {
            preview.src = 'assets/browse.png'; // Placeholder for empty custom
        }
    }
}

// Attach listener for custom input
document.addEventListener('DOMContentLoaded', () => {
    const customInput = document.getElementById('custom-image-url');
    if (customInput) {
        customInput.addEventListener('input', updatePreviewFromCustom);
    }
});

function togglePrivacyOptions() {
    const privacyPublic = document.querySelector('input[name="privacy"][value="public"]');
    const privateSettings = document.getElementById('private-settings');
    const whitelistGroup = document.getElementById('whitelist-group');

    // Reset visibility first to ensure clean state
    if (privateSettings) privateSettings.style.display = 'none';
    if (whitelistGroup) whitelistGroup.style.display = 'none';

    if (privacyPublic && !privacyPublic.checked) {
        // Private is checked
        if (privateSettings) {
            privateSettings.style.display = 'block';

            // Check access control state
            const accessWhitelist = document.querySelector('input[name="access"][value="whitelist"]');
            if (accessWhitelist && accessWhitelist.checked) {
                if (whitelistGroup) whitelistGroup.style.display = 'block';
                populateFriendDropdown(); // Ensure populated
            }
        }
    }
}

// Access Control Toggle Listener
document.addEventListener('change', function (e) {
    if (e.target.name === 'access') {
        const passwordGroup = document.getElementById('password-group');
        const whitelistGroup = document.getElementById('whitelist-group');

        if (e.target.value === 'password') {
            if (passwordGroup) passwordGroup.style.display = 'block';
            if (whitelistGroup) whitelistGroup.style.display = 'none';
        } else if (e.target.value === 'whitelist') {
            if (passwordGroup) passwordGroup.style.display = 'none';
            if (whitelistGroup) {
                whitelistGroup.style.display = 'block';
                populateFriendDropdown();
            }
        }
    }
});


// Whitelist Logic
// const mockFriends = ["Jackboback", "Jane Doe", "John Smith", "Alice Wonderland", "CoolGamer", "NewUser123"];
let whitelistedUsers = [];

function populateFriendDropdown() {
    // const select = document.getElementById('whitelist-friend-select');
    // if (select && select.children.length <= 1) { // Only populate if empty (except default)
    //     select.innerHTML = '<option value="">Select a friend...</option>';
    //     mockFriends.forEach(friend => {
    //         const option = document.createElement('option');
    //         option.value = friend;
    //         option.textContent = friend;
    //         select.appendChild(option);
    //     });
    // }
    $(function () {
        $("#whitelist-friend-select").autocomplete({
            source: dummyData.friends
        });
    });
}

function addToWhitelist() {
    const select = document.getElementById('whitelist-friend-select');
    const container = document.getElementById('whitelist-container');
    const user = select.value;

    if (user && !whitelistedUsers.includes(user)) {
        whitelistedUsers.push(user);
        renderWhitelist(container);
        select.value = ""; // Reset selection
    }
}

function removeFromWhitelist(user) {
    whitelistedUsers = whitelistedUsers.filter(u => u !== user);
    const container = document.getElementById('whitelist-container');
    renderWhitelist(container);
}

function renderWhitelist(container) {
    if (!container) return;
    container.innerHTML = '';
    whitelistedUsers.forEach(user => {
        const item = document.createElement('div');
        item.className = 'whitelist-item';
        item.innerHTML = `
            ${user}
            <span class="whitelist-remove" onclick="removeFromWhitelist('${user}')">✕</span>
        `;
        container.appendChild(item);
    });
}
