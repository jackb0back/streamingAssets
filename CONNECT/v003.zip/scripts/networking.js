/** @global */
/*
LIBRARIES:
CryptoJS: https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js
JSRSASIGN: https://cdnjs.cloudflare.com/ajax/libs/jsrsasign/10.9.0/jsrsasign-all-min.js
Trystero: https://esm.run/trystero
*/

// Placeholder for P2P Config (Stun/Turn servers)
const selfId = window.Trystero.selfId;
const joinRoom = window.Trystero.joinRoom;
let MasterDBSrc = "https://script.google.com/macros/s/AKfycbx6v26R7m5NTlo874UVbiqAG4llhgIUCFrfBYLtIMqO8DNXMlSOlgHJ3-cHYMQlq2P8/exec";

async function preCache() {
    if (!sesh.loggedIn) {
        return false;
    }
    let totalCaches = 7;
    getUser(sesh.account.friends).then((data) => {
        console.log(`1/${totalCaches} CACHED FRIENDS`);
    });
    getUser(sesh.account.favoriteContacts).then((data) => {
        console.log(`2/${totalCaches} CACHED FAVORITES`);
    });
    getUser(sesh.account.recentContacts).then((data) => {
        console.log(`3/${totalCaches} CACHED RECENT`);
    });
    getUser(sesh.account.pendingFriends).then((data) => {
        console.log(`4/${totalCaches} CACHED PENDING FR`);
    });
    getUser(sesh.account.sentFriendR).then((data) => {
        console.log(`5/${totalCaches} CACHED SENT FR`);
    });
    listRooms(1).then((data) => {
        console.log(`6/${totalCaches} CACHED ROOMS-1`);
    });
    listRooms(2).then((data) => {
        console.log(`7/${totalCaches} CACHED ROOMS-2`);
    });
}



async function pingUser(IDs, notify = false) {
    if (!sesh.loggedIn) throw new Error("Not logged in.");
    let intID = IDs;
    let isList = (typeof IDs == "object");
    let sigRooms = [];
    let timeouts = {};
    let IdList = [];
    if (isList) {
        IdList = IDs;
    }else {
        IdList = [IDs];
    }
    let results = {};
    const p2p = sesh.P2P;


    const isMySigRoom = function(id) {
        return (id == sesh.signalingRoomID)
    }
    const alreadyConnected = function(id) {
        return (p2p.connections[id] !== undefined);
    }
    return new Promise(async (resolve, reject) => {
        if (isList) {
            //Connect to the signaling rooms
            for (let userID of IdList) {
                let gen = generateSigRoomID(userID);
                if (!sigRooms.includes(gen)) {
                    sigRooms.push(gen);
                    if (!isMySigRoom(gen) && !alreadyConnected(gen)) {
                        await p2p.connectTo(gen);
                    }
                }
            }
            //create the timeouts
            for (let userID of IdList) {
                let _id = intToStrID(userID);
                timeouts[_id] = setTimeout(() => {
                    // Only disconnect if we created the connection and it's not our own signaling room
                    let gen = generateSigRoomID(userID);
                    if (!alreadyConnected(gen) && !isMySigRoom(gen)) {
                        p2p.disconnect(gen, true);
                    }
                    // peer is likely offline
                    console.log(`[ping] user ${_id} is likely offline`);
                    cache.funcs.updateStatus(userID, false, "offline");
                    p2p.invokeEvent("userOffline", false, userID);
                    results[_id] = false;
                    isDone();
                }, 8000);
            }
            onConnect();
        }else {
            const RID = generateSigRoomID(intID);
            sigRooms.push(RID);
            let _id = intToStrID(intID);
            // Determine if we are already connected to this room
            timeouts[_id] = setTimeout(() => {
                // Only disconnect if we created the connection and it's not our own signaling room
                if (!alreadyConnected(RID) && !isMySigRoom(RID)) {
                    p2p.disconnect(RID, true);
                }

                // peer is likely offline
                console.log(`[ping] user ${_id} is likely offline`);
                cache.funcs.updateStatus(intID, false, "offline");
                p2p.invokeEvent("userOffline", false, intID);
                results[_id] = false;
                isDone();
            }, 8000);
            if (isMySigRoom(RID) || alreadyConnected(RID)) {
                // console.log("ALREADY CONNECTED")
                onConnect();
            } else {
                // We need to connect first
                await p2p.connectTo(RID);
                onConnect();
            }
        }

        function isDone() {
            if (Object.keys(results).length >= IdList.length) {
                if (isList) {
                    resolve(results);
                }else {
                    let res = results[intToStrID(intID)];
                    if (res == false) {
                        reject("Timeout");
                    }else {
                        resolve(res);
                    }
                }
                // console.log("results:", results);
                return true;
            }
        }

        async function onConnect() {
            // Setup the success listener
            for (let roomID of sigRooms) {
                p2p.eventListener(roomID, "PeerAcknowledged", async (roomObj, packet) => {
                    // console.log(roomObj, packet);
                    if (roomObj.roomID == roomID) {
                            if (IdList.includes(packet.profile.ID) && !results[packet.profile.id]) {
                                console.log("Ping SUCCESS!")
                                clearTimeout(timeouts[packet.profile.id]);
                                results[packet.profile.id] = packet.profile;
                                if (!isMySigRoom(roomID)) {
                                    await sleep(3000);
                                    p2p.disconnect(roomID,true);
                                }
                                isDone();
                            }
                        } 
                });
                await sleep(1000);
                // console.log("The fuck??????", roomID)
                sesh.sendP2Pprofile(roomID, false, notify);
            }
        }
    });
}




async function verifyPeer(intID, p2pInfo, sigPacket, sig) {
    /*
        sigPacket {
            timestamp: Date.now(),
            profile: _profile_
        }
    */
    let user = await getUser(intID);
    if (!user) throw new Error("Could not find user")
    let rsa = new SimpleRSA(user.key);
    let profile = sigPacket.profile;
    let isValid = rsa.verifyPacket({
        SigTimestamp: sigPacket.timestamp,
        data: profile
    }, sig);
    console.log("IS PROFILE VALID?", isValid);
    if (isValid) {
        cache.funcs.compareCachedUser(profile);
        cache.funcs.cacheValidPeer(profile.id, p2pInfo.room, p2pInfo.peer);
        console.log("CACHED PROFILE", profile);
    }
    return isValid;
}


async function listRooms(page = 1) {
    //1 page = 8
    let query = {
        min: (page - 1) * 8,
        max: page * 8
    }
    return new Promise((resolve, reject) => {
        let req = new MasterDBRequest("/rooms/list", query);
        req.send().then((data) => {
            console.log(data);
            if (data.response == "OK") {
                for (let i = 0; i < data.message.length; i++) {
                    cache.funcs.compareCachedRoom(data.message[i]);
                }
            }
            resolve(data);
        }).catch((error) => {
            console.log(error);
            reject(error);
        });
    });
}

async function getNews() {
    let req = new MasterDBRequest("/connect/news/get",{});
    initUI();
    UI.MiscUI.newsList.html("<h4>Loading news...</h4>");
    req.send().then((data) => {
        if (data.response == "OK") {
            cache.news = data.message;
            displayNews();
        }
    })
}

async function getAllNews() {
    let req = new MasterDBRequest("/connect/news/getAll",{});
    initUI();
    UI.MiscUI.newsList.html("<h4>Loading news...</h4>");
    req.send().then((data) => {
        if (data.response == "OK") {
            cache.news = data.message;
            displayNews();
        }
    })
}

async function searchUser(username) {
    return new Promise((resolve, reject) => {
        let req = new MasterDBRequest("/search", {
            query: username
        });
        req.send().then((data) => {
            // console.log(data);
            resolve(data);
        }).catch((error) => {
            console.log(error);
            reject(error);
        });
    });
}

async function sendFriendRequest(userID) {
    return new Promise((resolve, reject) => {
        let req = new MasterDBRequest("/friends", {
            username: sesh.account.username,
            session: sesh.sessionToken,
            request: {
                "action": "ADD",
                "ID": userID
            }
        });
        req.send().then((data) => {
            console.log(data);
            if (data.response == "OK") {
                toast("success", data.message);
                // sesh.account.friends.push(userID);
                // sesh.account.sentFriendR = sesh.account.sentFriendR.filter(item => item !== userID);
                // UI.CommunityUI.funcs.init();
            } else {
                toast("error", data.message);
            }
            resolve(data);
        }).catch((error) => {
            console.log(error);
            toast("error", error.message);
            reject(error);
        })
    });
}

async function cancelFriendRequest(userID) {
    return new Promise((resolve, reject) => {
        let req = new MasterDBRequest("/friends", {
            username: sesh.account.username,
            session: sesh.sessionToken,
            request: {
                "action": "CANCEL",
                "ID": userID
            }
        });
        req.send().then((data) => {
            console.log(data);
            if (data.response == "OK") {
                // sesh.account.sentFriendR = sesh.account.sentFriendR.filter(item => item !== userID);
                // UI.CommunityUI.funcs.init();
                toast("success", data.message);
            } else {
                toast("error", data.message);
            }
            resolve(data);
        }).catch((error) => {
            console.log(error);
            toast("error", error.message);
            reject(error);
        })
    });
}

async function removeFriend(userID) {
    return new Promise((resolve, reject) => {
        let req = new MasterDBRequest("/friends", {
            username: sesh.account.username,
            session: sesh.sessionToken,
            request: {
                "action": "REMOVE",
                "ID": userID
            }
        });
        req.send().then((data) => {
            console.log(data);
            if (data.response == "OK") {
                toast("success", data.message);
                // sesh.account.friends = sesh.account.friends.filter(item => item !== userID);
                // UI.CommunityUI.funcs.init();
            } else {
                toast("error", data.message);
            }
            resolve(data);
        }).catch((error) => {
            console.log(error);
            toast("error", error.message);
            reject(error);
        })
    });
}

async function getUser(identifier, usecache = true) {
    return new Promise((resolve, reject) => {
        if (usecache) {
            if (typeof identifier == "string" || typeof identifier == "number") {
                if (typeof identifier == "string" && !isNaN(identifier)) {
                    identifier = parseInt(identifier);
                }
                let cached = cache.funcs.getUser(identifier);
                // console.log(cached, identifier);
                if (cached) {
                    resolve(cached.profileData);
                    return
                }
            }
            if (typeof identifier == "object" && Array.isArray(identifier)) {
                let checks = 0;
                let totalChecks = identifier.length;
                let cached_list = [];
                for (let i = 0; i < identifier.length; i++) {
                    let cached = cache.funcs.getUser(identifier[i]);
                    if (cached !== false) {
                        cached_list.push(cached.profileData);
                        checks++;
                        // console.log(checks + "/" + totalChecks);
                    }
                }
                // console.log("Total checks: " + checks + "/" + totalChecks);
                // console.log(cached_list);
                if (checks == totalChecks) {
                    resolve(cached_list);
                    return
                }
            }
        }
        let req = new MasterDBRequest("/user", {
            query: identifier
        });
        req.send().then((data) => {
            console.log(data);
            let pdata = data.message;
            if (data.response == "OK") {
                if (typeof pdata == "object") {
                    if (Array.isArray(pdata)) {
                        for (let i = 0; i < pdata.length; i++) {
                            cache.funcs.compareCachedUser(pdata[i]);
                        }
                    } else {
                        cache.funcs.compareCachedUser(pdata);
                    }
                }
            }
            if (data.response == "OK") {
                resolve(data.message);
            } else {
                reject(data.message);
            }
        }).catch((error) => {
            console.log(error);
            reject(error);
        })
    });
}



/* Begin Library code */


class SimpleRSA {
    constructor(privateKeyPEM = null) {
        if (privateKeyPEM) {
            // 1. Clean the input
            const cleanPEM = privateKeyPEM.trim();

            try {
                // 2. Parse the Private Key to get the components (n, e)
                const prvKeyObj = KEYUTIL.getKey(cleanPEM);

                // 3. RECONSTRUCTION FIX:
                // Instead of asking KEYUTIL to extract the public key (which is failing),
                // we create a brand new RSAKey object with ONLY public data.
                const pubKeyObj = new RSAKey();
                pubKeyObj.setPublic(prvKeyObj.n.toString(16), prvKeyObj.e.toString(16));

                // 4. Store Keys
                this.keypair = {
                    private: cleanPEM, // Keep original private string
                    public: KEYUTIL.getPEM(pubKeyObj, "PKCS8PUB") // Export our fresh public object
                };
            } catch (e) {
                console.error("RSA Error:", e);
                console.error("RSAKEY", privateKeyPEM)
                throw new Error("Failed to load RSA key. Password might be wrong.");
            }
        } else {
            // Generate new 1024 bit RSA Keypair
            const keypair = KEYUTIL.generateKeypair("RSA", 1024);
            this.keypair = {
                private: KEYUTIL.getPEM(keypair.prvKeyObj, "PKCS8PRV"),
                public: KEYUTIL.getPEM(keypair.pubKeyObj, "PKCS8PUB")
            };
        }
    }

    /**
     * Encrypts the content using the Public Key.
     * Result can only be read by the Private Key holder.
     * @param {string} content - The plain text string to encrypt
     * @returns {string} - The encrypted Hex string
     */
    encrypt(content) {
        try {
            // Convert PEM string back to Key Object
            const pubKey = KEYUTIL.getKey(this.keypair.public);
            // Encrypt using RSAOAEP (Optimal Asymmetric Encryption Padding)
            return KJUR.crypto.Cipher.encrypt(content, pubKey, "RSAOAEP");
        } catch (e) {
            console.error("Encryption error:", e);
            return null;
        }
    }

    /**
     * Decrypts the content using the Private Key.
     * @param {string} content - The encrypted Hex string
     * @returns {string} - The decrypted plain text string
     */
    decrypt(content) {
        try {
            // Convert PEM string back to Key Object
            const prvKey = KEYUTIL.getKey(this.keypair.private);
            // Decrypt
            return KJUR.crypto.Cipher.decrypt(content, prvKey, "RSAOAEP");
        } catch (e) {
            console.error("Decryption error:", e);
            return null;
        }
    }

    verify(message, signature) {
        try {
            const sig = new KJUR.crypto.Signature({ alg: "SHA256withRSA" });
            sig.init(this.keypair.public);       // Load their Public Key
            sig.updateString(message); // Load the message they signed
            return sig.verify(signature); // Verify!
        } catch (e) {
            console.error("Verification error:", e);
            return false;
        }
    }


    sign(message) {
        const sig = new KJUR.crypto.Signature({ alg: "SHA256withRSA" });
        sig.init(this.keypair.private);
        sig.updateString(message);
        return sig.sign();
    }

    signPacket(packetData, username) {
        let _time = Date.now();
        return {
            dataSig: this.sign(_time.toString() + JSON.stringify(packetData)),
            username: username,
            publicKey: this.keypair.public,
            SigTimestamp: _time
        }
    }

    verifyPacket(packet, signature) {
        return this.verify(packet.SigTimestamp.toString() + JSON.stringify(packet.data), signature)
    }

}


class SessionInstance {
    constructor() {
        this.loggedIn = false;
        this.creds = {
            username: "",
            password: ""
        }
        this.sessionToken = false;
        this.account = {};
        this.RSAkeys = false;
        this.P2P = false;
        this.signalingRoomID = false;
        this.whisperAction = false;
    }

    saveSessionToken() {
        if (!this.sessionToken) {
            return;
        }
        let encrypted = CryptoJS.AES.encrypt(JSON.stringify(this.creds), this.sessionToken).toString()
        localStorage.setItem("ODN_session", encrypted);
    }

    sendP2Pprofile(room, priv = false, notify = false) {
        if (this.P2P == false) {
            console.log("P2P not ready.");
        }
        // this.P2P.post(room, "/profile", this.publicProfile, priv, this.RSAkeys.signPacket(this.publicProfile, this.account.username));
        let type = priv == false ? "POST" : "AKNOWLEDGE";
        let packet = {
            profile: this.publicProfile,
            timestamp: Date.now(),
            type: type,
            ping: notify
        }
        let sendTo = null;
        if (priv !== false) {
            sendTo = priv;
        }
        console.log(`Send P2P profile to room ${room} for ${sendTo}`);
        this.P2P.post(room, "/peerInfo", packet, sendTo, this.RSAkeys.signPacket(this.publicProfile, this.account.username));
    }

    async initP2P() {
        if (!this.loggedIn) return;
        let _ = this;
        let p2p = new TrysteroP2PNetwork({
            trysteroConfig: P2P_config,
            enableLogs: true
        });
        //online ping
        p2p.newRoute("/online", async function (self, req) {
            let valid = cache.funcs.isValidPeer(_.signalingRoomID, req.peer)
            if (valid !== false) {
                let intID = strToID(valid);
                friendOnlineNotif(intID);
                cache.funcs.updateStatus(intID, req.peer, "online");
            }
        });
        //get/send PeerInfo
        p2p.newRoute("/peerInfo", async function(self, req, packet) {
            /*
                packet: {
                    profile: {"public profile"},
                    timestamp: 0000000,
                    type: "POST | AKNOWLEDGE"
                }
            */
            let valid = false;
            if (cache.funcs.isValidPeer(req.room, req.peer) == false) {
                let profile = packet.profile;
                let packetSig = req.signed; //SimpleRSA "signPacket"
                let v = await verifyPeer(profile.ID, req, {
                    timestamp: packetSig.SigTimestamp,
                    profile: profile
                }, packetSig.dataSig);
                if (!v) {
                    throw new Error("Peer not valid");
                    return;
                }
            }
            valid = true;
            let notify = packet.ping == true ? true : false;
            if (notify) {
                cache.funcs.updateStatus(packet.profile.id, req.peer, "notOffline");
            } 
            if (packet.type == "POST") {
                //sent to everyone
                _.sendP2Pprofile(req.room, req.peer);
            }
            if (packet.type == "AKNOWLEDGE") {
                //recived after a call
                if (valid !== false) {
                    p2p.invokeEvent("PeerAcknowledged", req.room, {
                        peer: req.peer,
                        profile: packet.profile,
                        timestamp: Date.now()
                    });
                }else {
                    console.error("Not acknowledging, not valid.");
                }
            }
            console.log("PEERINFO PACKET:",packet);
        });
        //Ping a peer
        p2p.newRoute("/ping", async function (self, req, recieved = false) {
            console.log("Ping: " + req.peer, recieved);
            p2p.post(req.room, "/profile", _.publicProfile, req.peer, _.RSAkeys.signPacket(_.publicProfile, _.account.username));
            if (!recieved) {
                p2p.post(req.room, "/ping", _.publicProfile, req.peer, _.RSAkeys.signPacket(_.publicProfile, _.account.username));
            } else {
                //Ts like never works btw, don't use
                p2p.invokeEvent("pingSuccess", req.room, req.peer, recieved, req.signed);
            }
        });
        //Request a peer's profile.
        p2p.newRoute("/getProfile", function (self, req, peerInfo) {
            console.log(req.peer + " requested profile.", peerInfo);
            _.sendP2Pprofile(req.room);
        });
        //Recieve a peer's profile
        p2p.newRoute("/profile", async function (self, req, profile) {
            let cuser = cache.funcs.getUser(profile.ID);
            if (!cuser) {
                await getUser(profile.ID);
                cuser = cache.funcs.getUser(profile.ID);
            }
            if (!cuser) {
                console.error("Could not find user profile for verification");
                return;
            }
            let packetSig = req.signed; //SimpleRSA "signPacket"
            verifyPeer(profile.ID, req, {
                timestamp: packetSig.SigTimestamp,
                profile: profile
            }, packetSig.dataSig);
            self.invokeEvent("onProfileValidate", req.room, req.peer, profile, req.signed);
        });
        p2p.newRoute("/requestStatus", async function (self, req) {
            self.post(req.room, "/status", "online");
        });
        p2p.newRoute("/status", async function (self, req, status) {
            let isValid = cache.funcs.isValidPeer(req.room, req.peer);
            if (isValid == false) {
                console.log(`Peer "${req.peer} is not verified."`);
                return;
            }
            console.log(`Update status: ${req.peer} to ${status}`);
            cache.funcs.updateStatus(isValid, req.peer, status);
        });

        p2p.connectTo(this.signalingRoomID);

        p2p.eventListener(this.signalingRoomID, "onPeerJoin", async function (room, peer) {
            await sleep(200);
            // _.sendP2Pprofile(_.signalingRoomID, peer);
            _.P2P.post(_.signalingRoomID, "/requestStatus");
        });
        p2p.eventListener(this.signalingRoomID, "onPeerLeave", function (room, peer) {
            // let strID = cache.funcs.isValidPeer(_.signalingRoomID, peer);
            // if (strID !== false) {
            //     cache.funcs.updateStatus(strToID(strID), peer, "offline");
            // }
        });
        this.whisperAction = p2p.makeAction(this.signalingRoomID, "whisper");
        this.whisperAction.get((data, peerID) => processWhisper(data, peerID))
        this.P2P = p2p;
        await sleep(1000);
        this.sendP2Pprofile(this.signalingRoomID);
        await sleep(500);
        pingUser(this.account.friends);
    }

    get publicProfile() {
        let acc = this.account;
        return {
            "username": acc.username,
            "creationDate": acc.creationDate,
            "picture": acc.picture,
            "profile": acc.profile,
            "key": this.RSAkeys.keypair.public,
            "id": acc.id,
            "ID": acc.ID,
            "friends": acc.friends
        }
    }

    async updateAccountInfo(data) {
        if (!this.loggedIn || !this.sessionToken) return;
        const req = new MasterDBRequest("/updateAccount", {
            username: this.account.username,
            session: this.sessionToken,
            data: data
        }, {
            username: this.account.username,
            hash: this.account.password
        });
        await req.sendEncrypted();
        console.log(req.response);
        return (req.response.response == "OK");
    }

    async refreshAccount() {
        if (!this.loggedIn) {
            return false;
        }
        let res = await this.LogInWithSession(this.sessionToken, true);
        if (res) {
            console.log("Refreshed account info")
        } else {
            console.log("Failed to refresh account info");
        }
        return res;
    }

    async requestNewAccount(username, password, email) {
        const rsakeys = new SimpleRSA(); // Uses JSRSASIGN wrapper
        let data = {
            username,
            password,
            email,
            keypair: {
                public: rsakeys.keypair.public,
                // Encrypt private key using CryptoJS AES
                private: CryptoJS.AES.encrypt(rsakeys.keypair.private, password).toString()
            }
        }
        console.log("New account info:", data);
        const req = new MasterDBRequest(
            "/newAccount",
            data
        );
        await req.send();
        console.log(req.response);
        if (req.response && req.response.response == "OK") {
            console.log("Successfully created a new account.");
            return true;
        }
        console.log("Error creating a new account.");
        return false;
    }
    async LogInWithSession(token, refresh = false) {
        let localCreds = localStorage.getItem("ODN_session");
        if (localCreds !== null && !refresh) {
            try {
                let decrypted = CryptoJS.AES.decrypt(localCreds, token).toString(CryptoJS.enc.Utf8);
                console.log(decrypted);
                let creds = JSON.parse(decrypted);
                console.log(creds);
                this.creds = creds;
            } catch (e) {
                console.error("Failed to import session:", e);
                return false;
            }
        }
        const req = new MasterDBRequest("/sessionLogin", {
            token: token,
            username: this.creds.username
        });
        await req.send();
        console.log(req.response);
        if (req.response && req.response.success) {
            this.sessionToken = token;
            this.account = req.response.result;
            //Decode the private key
            try {
                // Decrypt private key using CryptoJS AES
                const decryptedBytes = CryptoJS.AES.decrypt(this.account.keypair.private, this.creds.password);
                // console.log(decryptedBytes);
                const decryptedKey = decryptedBytes.toString(CryptoJS.enc.Utf8);
                // console.log(decryptedKey);

                // Import the private key into SimpleRSA
                this.RSAkeys = new SimpleRSA(decryptedKey);
                // console.log(this.RSAkeys);
                console.log("Decoded private key.")
            } catch (e) {
                console.log("Error decoding private key:", e);
            }
            this.signalingRoomID = generateSigRoomID(this.account.ID);
            this.loggedIn = true;
            return true;
        }
        return false;
    }
    async LogIntoNet(username, password) {
        const req = new MasterDBRequest(
            "/login",
            { username, password },
            { username, hash: CryptoJS.SHA256(password).toString() }
        );

        await req.sendEncrypted();

        console.log(req.response);

        if (req.response && req.response.success) {
            this.sessionToken = req.response.token;
            this.account = req.response.result;
            this.creds.username = username;
            this.creds.password = password;
            this.saveSessionToken();
            //Decode the private key
            try {
                // Decrypt private key using CryptoJS AES
                const decryptedBytes = CryptoJS.AES.decrypt(this.account.keypair.private, password);
                // console.log(decryptedBytes);
                const decryptedKey = decryptedBytes.toString(CryptoJS.enc.Utf8);
                // console.log(decryptedKey);

                // Import the private key into SimpleRSA
                this.RSAkeys = new SimpleRSA(decryptedKey);
                // console.log(this.RSAkeys);
                console.log("Decoded private key.")
            } catch (e) {
                console.log("Error decoding private key:", e);
            }
            this.loggedIn = true;
            this.signalingRoomID = generateSigRoomID(this.account.ID);
            return true;
        }

        console.log("Error logging into the ODN.");
        return false;
    }
}

class MasterDBRequest {
    constructor(route, body, enc) {
        this.encryption = enc || {};
        this.route = route;
        this.masterDB = MasterDBSrc;
        this.requestBody = body;
        if (typeof this.requestBody == "object") this.requestBody = JSON.stringify(this.requestBody);
        this.response = null;
        if (enc && enc.username !== undefined && enc.hash !== undefined) {
            this.aesKey = CryptoJS.SHA256(enc.username + enc.hash).toString();
        }
    }
    async sendEncrypted() {
        this.response = await new Promise(async (resolve, reject) => {
            const formData = new FormData();
            console.log(this.requestBody, this.aesKey);

            const payload = {
                path: this.route,
                body: CryptoJS.AES.encrypt(this.requestBody, this.aesKey).toString(),
                enc: true,
                username: this.encryption.username
            }
            formData.append("path", payload.path);
            formData.append("body", payload.body);
            formData.append("enc", payload.enc);
            formData.append("username", payload.username);
            console.log("POSTING:", payload)

            fetch(this.masterDB, {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(result => {
                    console.log("Posted to " + this.masterDB);
                    console.log("Received:", result);
                    resolve(result);
                })
                .catch(error => {
                    console.log("Error posting to " + this.masterDB);
                    reject(error);
                })
        });
        return this.response;
    }
    async send() {
        this.response = await new Promise(async (resolve, reject) => {
            const formData = new FormData();
            formData.append("path", this.route);
            formData.append("body", this.requestBody);

            fetch(this.masterDB, {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(result => {
                    console.log("Posted to " + this.masterDB);
                    console.log("Received:", result);
                    resolve(result);
                })
                .catch(error => {
                    console.log("Error posting to " + this.masterDB);
                    reject(error);
                });
        });
        return this.response;
    }
}



/* End Library code */

const sesh = new SessionInstance();