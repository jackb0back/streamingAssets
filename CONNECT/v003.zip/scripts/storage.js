let storage = {
    settings: {},
    profileCache: {},
    notifications: {},
    Messaging: {
        favorites: [],
        recents: [],
    },
    networkEvents: {
        friends: [],
        sentFriendR: [],
        pendingFriends: []
    }
}
let MessageDB;
const storageFunctions = {
    addFavoriteContact(intID) {
        if (storage.Messaging.favorites.includes(intID)) {
            return;
        }
        storage.Messaging.favorites.push(intID);
        saveLocalStorage();
    },
    removeFavoriteContact(intID) {
        storage.Messaging.favorites = storage.Messaging.favorites.filter((user) => user !== intID);
        saveLocalStorage();
    },
    addRecentContact(intID) {
        let recents = storage.Messaging.recents;
        recents = recents.filter((id) => id !== intID);
        recents.splice(0, 0, intID);
        if (recents.length > 5) {
            recents.length = 5;
    }
        storage.Messaging.recents = recents;
        saveLocalStorage();
    },
    getNotifObj() {
        let res = [];
        for (let key in NotificationInstances) {
            res.push(NotificationInstances[key].table);
        }
        const sortByDate = (data) => {
            return data.sort((a, b) => a.timestamp - b.timestamp);
        };
        return sortByDate(res);
    },
    GetNetworkEvents() {
        if (!sesh.loggedIn) return;

        // --- 1. Get Current Data (Live) ---
        const currentFriends = sesh.account.friends;
        const currentSent = sesh.account.sentFriendR;
        const currentPending = sesh.account.pendingFriends;

        // --- 2. Get Stored Data (Old) ---
        const storedFriends = storage.networkEvents.friends || [];
        const storedSent = storage.networkEvents.sentFriendR || [];
        const storedPending = storage.networkEvents.pendingFriends || [];

        // --- 3. Helper: ID Extractor ---
        // Handles both simple numbers [1, 2] and objects [{id:1}, {id:2}]
        const getId = (item) => (item && typeof item === 'object' && 'id' in item) ? item.id : item;

        // Create lists of IDs for the OLD data to check against
        const storedFriendIds = storedFriends.map(getId);
        const storedPendingIds = storedPending.map(getId);
        
        // Create lists of IDs for CURRENT data (needed for the Declined check)
        const currentFriendIds = currentFriends.map(getId);
        const currentSentIds = currentSent.map(getId);


        // --- 4. Calculate Events ---

        // A. NEW FRIENDS
        // Logic: Exists in Current, did NOT exist in Stored
        const newFriends = currentFriends.filter(friend => {
            return !storedFriendIds.includes(getId(friend));
        });

        // B. NEW PENDING REQUESTS (Incoming)
        // Logic: Exists in Current, did NOT exist in Stored
        const newFriendRequests = currentPending.filter(req => {
            return !storedPendingIds.includes(getId(req));
        });

        // C. DECLINED REQUESTS (Outgoing)
        // Logic: Existed in Stored Sent, MISSING from Current Sent, AND NOT in Current Friends
        const declinedFriendRequests = storedSent.filter(req => {
            const id = getId(req);
            const isStillSent = currentSentIds.includes(id);
            const isNowFriend = currentFriendIds.includes(id);
            return !isStillSent && !isNowFriend;
        });

        // D. REMOVED FRIENDS (Unfriended)
        // Logic: Existed in Stored Friends, MISSING from Current Friends
        const removedFriends = storedFriends.filter(friend => {
            return !currentFriendIds.includes(getId(friend));
        });

        // --- 5. Logging & Return ---
        if (newFriends.length) console.log("New Friends:", newFriends);
        if (declinedFriendRequests.length) console.log("Declined Requests:", declinedFriendRequests);
        if (newFriendRequests.length) console.log("New Pending Requests:", newFriendRequests);
        if (removedFriends.length) console.log("Removed Friends:", removedFriends);

        return {
            newFriends: newFriends,
            declinedFriendRequests: declinedFriendRequests,
            newFriendRequests: newFriendRequests,
            removedFriends: removedFriends // Added to the return object
        };
    },
    saveNetworkEvents() {
        storage.networkEvents.friends = sesh.account.friends;
        storage.networkEvents.sentFriendR = sesh.account.sentFriendR;
        storage.networkEvents.pendingFriends = sesh.account.pendingFriends;
        saveLocalStorage();
    }
}

/*
room example (network request):
{
    "id": number,
    "RoomID": string,
    "name": string,
    "image": string,
    "description": string,
    "creator": string,
    "privacy": "public" | "private",
    "creationTimestamp": number,
    "expires": number,
}

*/



let cache = {
    profileCache: {},
    statusCache: {},
    validPeers: {},
    Chatrooms: {},
    RoomPages: {},
    news: [],
    funcs: {
        cacheRoom: function (room) {
            if (!room || !room.RoomID) {
                return;
            }
            cache.Chatrooms[room.RoomID] = {
                roomData: room,
                dataHash: CryptoJS.SHA256(JSON.stringify(room)).toString(),
                lastUpdated: Date.now()
            };
            let roomPage = Math.ceil(room.id / 10); //Hard limit cuz fuck you.
            if (!cache.RoomPages[roomPage]) {
                cache.RoomPages[roomPage] = [];
            }
            if (cache.RoomPages[roomPage].includes(room.RoomID)) {
                return;
            }
            cache.RoomPages[roomPage].push(room.RoomID);
        },
        getCachedRoom: function (RoomID) {
            if (!RoomID) {
                return false;
            }
            return cache.Chatrooms[RoomID].roomData;
        },
        getRoomPage: function (page) {
            if (!page || !cache.RoomPages[page]) {
                return [];
            }
            let res = [];
            for (let roomID of cache.RoomPages[page]) {
                res.push(cache.Chatrooms[roomID].roomData);
            }
            return res;
        },
        compareCachedRoom: function (room) {
            if (!room || !room.RoomID) {
                return;
            }
            let cached = cache.Chatrooms[room.RoomID];
            if (!cached) {
                console.log("New room");
                cache.funcs.cacheRoom(room);
                return false;
            }
            if (cached.dataHash == CryptoJS.SHA256(JSON.stringify(room)).toString()) {
                console.log("No diff")
                return true;
            }
            console.log("Update cached room");
            cache.funcs.cacheRoom(room);
            return false;
        },
        getUser: function (identifier) {
            switch (typeof identifier) {
                case "string":
                    for (let ID in cache.profileCache) {
                        if (cache.profileCache[ID].username == identifier) {
                            return cache.profileCache[ID];
                        }
                    }
                    return false;
                    break;
                case "number":
                    let ID = intToStrID(identifier);
                    if (cache.profileCache[ID]) {
                        return cache.profileCache[ID];
                    }
                    return false;
                    break;
                default:
                    return false;
            }
        },
        cacheUser: function (profile) {
            if (!profile || !profile.ID || !profile.id) {
                return;
            }
            cache.profileCache[profile.id] = {
                username: profile.username,
                profileData: profile,
                dataHash: CryptoJS.SHA256(JSON.stringify(profile)).toString(),
                lastUpdated: Date.now()
            };
            saveLocalStorage();
        },
        compareCachedUser: function (profile) {
            if (!profile || !profile.ID || !profile.id) {
                return;
            }
            let cached = cache.profileCache[profile.id];
            if (!cached) {
                console.log("New user");
                cache.funcs.cacheUser(profile);
                return false;
            }
            if (cached.dataHash == CryptoJS.SHA256(JSON.stringify(profile)).toString()) {
                console.log("No diff")
                return true;
            }
            console.log("Update cached user");
            cache.funcs.cacheUser(profile);
            return false;
        },
        cacheValidPeer: function(intID, roomID, peerID) {
            const uid = typeof intID === 'number' ? intToStrID(intID) : intID;
            let room = cache.validPeers[roomID];
            if (!room) {
                cache.validPeers[roomID] = {};
                room = cache.validPeers[roomID];
            }
            room[uid] = peerID;
            cache.funcs.updateStatus(intID, peerID, "online");
            return true;
        },
        isValidPeer: function(roomID, pid_uid){
            let room = cache.validPeers[roomID];
            if (!room) return false;
            if (typeof pid_uid == "number") {
                let pid = room[intToStrID(pid_uid)]
                if (!pid) {
                    return false;
                }
                return pid;
            }
            if (typeof pid_uid == "string") {
                for (userID in room) {
                    if (room[userID] == pid_uid) {
                        return userID;
                    }
                }
                return false;
            }
            return false;
        },
        getStatus: function(intID) {
            let scache = cache.statusCache[intToStrID(intID)];
            if (!scache) {
                return "offline";
            }
            return scache.status;
        },
        updateStatus: function(_id, peerID, status, notify = true) {
            const id = typeof _id === 'number' ? intToStrID(_id) : _id;
            let user = cache.statusCache[id];
            if (!user) {
                cache.statusCache[id] = {
                    status: status,
                    peerID: peerID,
                    timestamp: Date.now(),
                    was: null
                }
                if (status == "online" &&notify) {
                    friendOnlineNotif(strToID(id));
                }
            }else {
                if (status == "notOffline" && user.status !== "offline") {
                    status = user.status;
                }
                cache.statusCache[id] = {
                    status: status,
                    peerID: peerID,
                    timestamp: Date.now(),
                    was: {
                        status: user.status,
                        peerID: user.peerID,
                        timestamp: user.timestamp
                    }
                }
                if (user.status == "offline" && status == "online" && notify) {
                    friendOnlineNotif(strToID(id));
                }
            }
            updateAllStatusIndicatorsFor(strToID(id));
        }
    }
}


function initMessageDB() {
    if (!sesh.loggedIn) {
        console.error("Error initalizing messageDB, not logged in.");
        return;
    }
    let DBNAME = sesh.account.username + "_connectMessages";
    MessageDB = new MessageDBInstance(DBNAME);
}

class MessageDBInstance {
    constructor(dbName = 'EncryptedChatDB', storeName = 'messages') {
        if (dbName == false) {
            this.dummy = true;
        }else {
            this.dbName = dbName;
            this.storeName = storeName;
            this.db = null;
        }
    }

    async open() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, 1);

            request.onupgradeneeded = (event) => {
                const db = event.target.result;

                if (!db.objectStoreNames.contains(this.storeName)) {
                    // 1. Use 'hash' as the primary key since it is unique per message
                    const store = db.createObjectStore(this.storeName, { keyPath: 'hash' });

                    // 2. Index for grouping messages by Room
                    store.createIndex('room_idx', 'roomHash', { unique: false });

                    // 3. Index for sorting by time
                    store.createIndex('timestamp_idx', 'timestamp', { unique: false });

                    // 4. Index for traversing the chain (finding the child of a specific hash)
                    store.createIndex('prevHash_idx', 'prevHash', { unique: false });

                    // 5. Index for searching by author (Indexing nested property)
                    store.createIndex('author_idx', 'author.combString', { unique: false });
                }
            };

            request.onsuccess = (event) => {
                this.db = event.target.result;
                resolve(this.db);
            };

            request.onerror = (event) => reject(`DB Error: ${event.target.error}`);
        });
    }

    /**
     * Stores a message object into a specific room.
     * @param {string} roomHash - The SHA256 hash of the room.
     * @param {Object} messageObj - The JSON object exactly as provided in your example.
     */
    async addMessage(roomHash, messageObj) {
        if (!this.db) await this.open();

        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([this.storeName], 'readwrite');
            const store = transaction.objectStore(this.storeName);

            // We inject the roomHash into the record so we can query it later.
            // We use spread syntax to keep the original message intact.
            const record = {
                ...messageObj,
                roomHash: roomHash
            };

            const request = store.put(record); // .put() updates if hash exists

            request.onsuccess = () => resolve(messageObj.hash);
            request.onerror = (event) => reject(`Write Error: ${event.target.error}`);
        });
    }

    /**
     * Get all messages for a room, sorted by timestamp.
     */
    async getRoomHistory(roomHash) {
        if (!this.db) await this.open();

        return new Promise((resolve, reject) => {
            const tx = this.db.transaction([this.storeName], 'readonly');
            const index = tx.objectStore(this.storeName).index('room_idx');
            
            const request = index.getAll(IDBKeyRange.only(roomHash));

            request.onsuccess = (event) => {
                const messages = event.target.result;
                // Sort in memory to ensure chronological order
                messages.sort((a, b) => a.timestamp - b.timestamp);
                let results = {
                    hashList: [],
                }
                // console.log("grrr",messages)
                for (let message of messages) {
                    let authorID = message.author.strID;
                    // console.log("huh?",message);
                    if (!results[authorID]) {
                        results[authorID] = {};
                    }
                    results[authorID][message.hash] = message;
                    results.hashList.push(message.hash);
                }
                resolve(results);
            };
            request.onerror = (e) => reject(e.target.error);
        });
    }

    /**
     * Find a specific message by its hash.
     */
    async getMessageByHash(hash) {
        if (!this.db) await this.open();
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction([this.storeName], 'readonly');
            const store = tx.objectStore(this.storeName);
            const request = store.get(hash);
            
            request.onsuccess = (e) => resolve(e.target.result);
            request.onerror = (e) => reject(e.target.error);
        });
    }


    /**
     * Updates the status of a message (e.g., 'sent', 'delivered', 'read').
     * @param {string} hash - The unique hash of the message.
     * @param {string} newStatus - The new status string.
     */
    async updateStatus(hash, newStatus, readAt = Date.now()) {
        if (!this.db) await this.open();

        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([this.storeName], 'readwrite');
            const store = transaction.objectStore(this.storeName);

            // 1. Get the message first
            const request = store.get(hash);

            request.onsuccess = () => {
                const data = request.result;
                
                if (!data) {
                    // Fail silently or reject depending on your UI needs
                    console.warn(`Message ${hash} not found, cannot update status.`);
                    resolve(false); 
                    return;
                }

                // 2. Only update the status field
                data.status = newStatus;
                
                // Optional: Add a timestamp for when it was read
                if (newStatus === 'read') {
                    data.readAt = readAt;
                }

                // 3. Save it back
                const updateRequest = store.put(data);

                updateRequest.onsuccess = () => resolve(true);
                updateRequest.onerror = (e) => reject(e.target.error);
            };

            request.onerror = (e) => reject(e.target.error);
        });
    }
}



async function importNotifs(notifs) {
    if (UI.notifications.list.toArray().length < 1) {
        await sleep(500);
        UI.notifications.list = $(".notification-list");
    }
    UI.notifications.list.empty();
    for (let item of notifs) {
        item.parent = UI.notifications.list;
        new Notification("",item);
    }
}

function getLocalStorage() {
    if (!sesh.loggedIn) {
        return;
    }
    let id = sesh.account.username + "_ODNlocalStorage";
    let data = localStorage.getItem(id);
    if (data) {
        try {
            let parsed = JSON.parse(atob(data));
            console.log(parsed);
            for (let key in parsed) {
                storage[key] = parsed[key];
            }
            importSettings(parsed.settings);
            importNotifs(parsed.notifications);
            cache.profileCache = parsed.profileCache;
            console.log("Loaded from localStorage as " + id);
            return true;
        } catch (e) {
            console.log(e);
            return false;
        }
    }
    return false;
}


function saveLocalStorage() {
    // let toSave = {
    //     settings: settings,
    //     profileCache: cache.profileCache,
    //     notifications: {}
    // }
    // storage = toSave;
    storage.profileCache = cache.profileCache;
    storage.notifications = storageFunctions.getNotifObj();
    let toSave = storage;
    if (!sesh.loggedIn) {
        return;
    }
    let id = sesh.account.username + "_ODNlocalStorage";
    localStorage.setItem(id, btoa(JSON.stringify(toSave)));
    console.log("Saved to localStorage as " + id);
}