class NewsPost {
    constructor(title, content, date, config) {
        this.title = title;
        this.content = content;
        this.date = date; //timestamp int
        this.tagType = "fix"; //fix | minor | major
        this.tag = "hotfix";
        this.author = {
            picture: "assets/jackboback.png",
            username: "Jackboback"
        }
        Object.assign(this, config);
    }

    get table() {
        return {
            title: this.title,
            content: this.content,
            date: this.date,
            tagType: this.tagType,
            tag: this.tag,
            author: this.author
        }
    }

    get html() {
        const currentDate = new Date(this.date);
        const formattedDate = currentDate.toLocaleDateString('en-US', { 
            month: 'short',
            day: 'numeric',
            year: 'numeric'
        });
        return `
        <div class="news-item">
            <div class="news-header">
                <div>
                    <span class="news-tag tag-${this.tagType}">${this.tag}</span>
                    <span class="news-title">${this.title}</span>
                </div>
                <span class="news-date">${formattedDate}</span>
            </div>

            <div class="news-body">
                ${this.content}
            </div>

            <div class="news-footer">
                <div class="news-author-avatar" style="background-image: url('${this.author.picture}');"></div>
                <span>Posted by ${this.author.username}</span>
            </div>
        </div>
        `
    }
}

function displayNews() {
    UI.MiscUI.newsList.empty();
    for (let item of cache.news) {
        let post = importNewsTable(item);
        UI.MiscUI.newsList.append(post.html);
    }
}


function importNewsTable(table) {
    return new NewsPost("","","",table);
}


function newsTest() {
    let post = importNewsTable({
        "title": "Hello world!",
        "content": "<h1>The Quick Brown Fox Jumps Over The Lazy Dog.</h1>",
        "date": 1771552980423,
        "tagType": "fix",
        "tag": "hotfix",
        "author": {
            "picture": "assets/jackboback.png",
            "username": "Jackboback"
        }
    });
    UI.MiscUI.newsList.prepend(post.html);
}