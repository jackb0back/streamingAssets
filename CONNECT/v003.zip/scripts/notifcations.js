/** @global */

let NotificationInstances = {};

class Notification {
    constructor (type, options = {}) {
        this.type = type; // message | friendRequest | system | custom
        this.title = "New Notification";
        this.message = "This is a test notification."
        this.timestamp = Date.now();
        this.parent = false;
        this.icon = "assets/link.png";
        this.read = false;
        this.id = generateUUID();
        this.data = {};
        /*
            example action:
            {
                name: "Accept",
                class: "btn-accept",
                onclick: <function>
            }
        */
        this.actions = [];
        Object.assign(this, options);
        switch (this.type) {
            case "friendRequest":
                this.title = "Friend Request";
                this.actions = [{
                    name: "Accept",
                    class: "btn-accept",
                    onclick: (e, notification) => {
                        console.log(e)
                        UI.CommunityUI.funcs.buttons.send(e.target, this.data.ID)
                    }
                },{
                    name: "Decline",
                    class: "btn-decline",
                    onclick: (e, notification) => {
                        UI.CommunityUI.funcs.buttons.cancel(e.target, this.data.ID);
                    }
                },]
            break;
            case "message":

            break;
            case "system":
                break;
            default:
                //no change
            break;
        }
        this.element = null;
        NotificationInstances[this.id] = this;
        if (this.parent !== false) {
            this.parent.prepend(this.render());
            UI.notifications.funcs.showUnreadIcon();
            saveLocalStorage();
        }
    }

    // 1. New method to handle the state change and visual update
    markAsRead() {
        if (this.read) return; // Don't do anything if already read

        this.read = true;
        
        // Update the DOM immediately without full re-render
        if (this.element) {
            this.element.classList.remove("unread");
            this.element.classList.add("read"); // Optional, if you have specific styles for read
        }
        if (this.parent) {
            saveLocalStorage();
        }
        
        console.log(`Notification ${this.id} marked as read.`);
        UI.notifications.funcs.showUnreadIcon();
    }

    get table() {
        return {
            type: this.type,
            title: this.title,
            message: this.message,
            timestamp: this.timestamp,
            icon: this.icon,
            read: this.read,
            data: this.data
        }
    }

    render() {
        let _actions = ``;

        this.actions.forEach((item, index) => {
            _actions += `<button class="notification-action-btn ${item.class || ""}" data-index="${index}">${item.name || "action"}</button>`;
        });

        const htmlString = `
        <div id="notif-${this.id}" class="notification-item ${this.read ? "" : "unread"}">
            <img src="${this.icon}" class="notification-avatar" alt="Avatar">
            <div class="notification-content">
                <h3 class="notification-title">${this.title}</h3>
                <p class="notification-message">${this.message}</p>
                ${this.actions.length > 0 ? `<div class="notification-actions">${_actions}</div>` : ""}
                <p class="notification-time">${typeof smartTimestamp !== 'undefined' ? smartTimestamp(this.timestamp) : new Date(this.timestamp).toLocaleTimeString()}</p>
            </div>
            <img src="../assets/close.png" title="Delete" class="notification-delete" alt="">
        </div>
        `;

        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = htmlString.trim();
        const newElement = tempDiv.firstElementChild;

        if (this.element == null) {
            this.element = newElement;
        } else {
            this.element.replaceWith(newElement);
            this.element = newElement;
        }

        this.element.addEventListener('click', (e) => {
            this.markAsRead(); 
        });

        // 4. Attach Action Button Listeners
        const buttons = this.element.querySelectorAll('.notification-action-btn');
        const deleteBtn = this.element.querySelector('.notification-delete');

        deleteBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            let parent = this.element.parentElement;
            this.element.remove();
            delete NotificationInstances[this.id];
            if (this.parent !== false) {
                saveLocalStorage();
            }
            if (Object.keys(NotificationInstances).length == 0) {
                $(parent).html("<h4>No Notifications</h4>");
            }
        });

        buttons.forEach(btn => {
            const index = btn.getAttribute('data-index');
            const action = this.actions[index];

            if (action && action.onclick) {
                btn.addEventListener('click', (e) => {
                    // Execute the action
                    e.stopPropagation();
                    action.onclick(e, this);
                    // Note: Since this button is inside the main element, 
                    // the click will bubble up and trigger markAsRead() automatically.
                    // If you want to prevent that, use e.stopPropagation() inside the action definition.
                });
            }
        });

        return this.element;
    }
}

function readAllNotifcations() {
    for (let notif in NotificationInstances) {
        NotificationInstances[notif].markAsRead();
    }
}


class ToastLibrary {
    constructor() {
        this.container = document.createElement('div');
        this.container.id = 'toast-container';
        this.container.classList.add('bottom-right'); // Default position
        document.body.appendChild(this.container);

        this.types = {
            success: {
                icon: 'assets/check.png', // Placeholder, expecting user to have these or I should use existing
                className: 'success',
                duration: 4000
            },
            error: {
                icon: 'assets/close.png', // Placeholder
                className: 'error',
                duration: 5000
            },
            info: {
                icon: 'assets/info.png',
                className: 'info',
                duration: 5000
            },
            custom: {
                icon: '',
                className: 'custom',
                duration: 6000
            },
            message: {
                icon: '',
                className: 'message',
                duration: 6000
            },
            online: {
                icon: '',
                className: 'online',
                duration: 4000
            },
        };
    }

    setPosition(position) {
        this.container.className = ''; // Clear existing classes
        this.container.classList.add(position); // 'bottom-right' or 'top-bar'
    }

    createToast(type, message, options = {}) {
        const toastType = this.types[type] || this.types['info'];
        const duration = options.duration || toastType.duration;
        const title = options.title || type.charAt(0).toUpperCase() + type.slice(1);
        const iconSrc = options.icon || toastType.icon;
        const position = options.position || "bottom-right";
        const toastElement = document.createElement('div');
        const Color = options.color || false;
        const bgColor = options.backgroundColor || false;
        toastElement.classList.add('toast', type);
        if (Color !== false) {
            toastElement.style.color = Color;
        }
        if (bgColor !== false) {
            toastElement.style.backgroundColor = bgColor;
        }
        if (toastType.className) toastElement.classList.add(toastType.className);

        // Icon
        const iconContainer = document.createElement('div');
        iconContainer.classList.add('toast-icon');
        const img = document.createElement('img');
        img.src = iconSrc;
        img.onerror = () => { img.style.display = 'none'; }; // Hide if broken
        iconContainer.appendChild(img);
        toastElement.appendChild(iconContainer);

        // Content
        const contentContainer = document.createElement('div');
        contentContainer.classList.add('toast-content');

        if (title) {
            const titleElement = document.createElement('div');
            titleElement.classList.add('toast-title');
            titleElement.innerText = title;
            contentContainer.appendChild(titleElement);
        }

        const messageElement = document.createElement('div');
        messageElement.classList.add('toast-message');
        messageElement.innerText = message;
        contentContainer.appendChild(messageElement);

        toastElement.appendChild(contentContainer);

        // Close Button
        const closeBtn = document.createElement('button');
        closeBtn.classList.add('toast-close');
        closeBtn.innerHTML = '&times;';
        closeBtn.onclick = () => this.dismiss(toastElement);
        toastElement.appendChild(closeBtn);

        this.container.appendChild(toastElement);

        // this.setPosition(position);

        // Auto dismiss
        if (duration > 0) {
            setTimeout(() => {
                this.dismiss(toastElement);
            }, duration);
        }

        return {
            element: toastElement,
            iconImg: img
        };
    }

    dismiss(toastElement) {
        toastElement.classList.add('hide');
        toastElement.addEventListener('animationend', () => {
            if (toastElement.parentNode === this.container) {
                this.container.removeChild(toastElement);
            }
        });
    }
}

const Lib_toasts = new ToastLibrary();
const Lib_topToasts = new ToastLibrary();
Lib_topToasts.setPosition("top-bar");

async function friendOnlineNotif(intID) {
    if (!isFriend(intID)) return;
    let user = await getUser(intID);
    toast("online", user.username + " is online", { position: "top-bar", userID: intID })
}


async function createNetworkNotiifcations() {
    let newData = storageFunctions.GetNetworkEvents();
    for (let newFriend of newData.newFriends) {
        let user = await getUser(newFriend);
        toast("message", user.username + " is now your friend", {
            icon: user.picture,
            title: "New Friend",
            backgroundColor: "#2ecc71"
        });
        new Notification("system",{
           icon: user.picture,
           title: "New Friend",
           message: user.username + " is now your friend.",
           parent: UI.notifications.list
        });
    }
    for (let declinedFriend of newData.declinedFriendRequests) {
        let user = await getUser(declinedFriend);
        toast("message", user.username + " declined your request.", {
            icon: user.picture,
            title: "Friend Declined",
            backgroundColor: "#e74c3c"
        });
        new Notification("system",{
           icon: "assets/close.png",
           title: "Friend Request Declined",
           message: user.username + " declined your request.",
           parent: UI.notifications.list
        });
    }
    for (let newFriendRequest of newData.newFriendRequests) {
        let user = await getUser(newFriendRequest);
        toast("message", user.username + " sent you a friend request.", {
            icon: user.picture,
            title: "New Friend Request",
            // backgroundColor: "#e74c3c"
        });
        new Notification("friendRequest",{
           icon: user.picture,
           message: user.username + " sent you a friend request.",
           parent: UI.notifications.list,
           data: {
                ID: user.ID
           }
        });
    }
}


async function toast(type, message, options = {}) {
    // Mapping old types to new types
    if (type === 'ok') type = 'success';
    if (type === 'warning') type = 'error'; // Mapping warning to error for now, or could create warning type

    // Handle "message" type specifically for user profile pics (backward compatibility)
    if (type === 'message' || type === "online") {
        // type = 'custom';
        // Logic to fetch user profile picture if userID is present
        if (options.userID) {
            let user = await getUser(options.userID);
            if (user) {
                if (type === "online") {
                    options.icon = user.picture;
                    options.title = "A friend is online";
                } else {
                    options.icon = user.picture;
                    options.title = user.username;
                }
            }
        }
    }

    // Pass options directly
    if (options.position == "top-bar") {
        let toastInstance = Lib_topToasts.createToast(type, message, options);
    } else {
        let toastInstance = Lib_toasts.createToast(type, message, options);
    }

    // Compatibility: If it was a message type and we are waiting for user data (which acts async in the old one but here we awaited it),
    // we already set the icon. The old code set it *after* the toast opened.
    // Since we await getUser *before* creating the toast, the icon should be correct immediately.
    // However, if we wanted to support the exact old behavior of opening then updating, we'd need to return the img element.
    // syntax: if (type == "message") { let icon = ...; let user = await ...; icon.src = ... }
}

// Expose toastLib to window if needed for position changing
// window.toastLib = toastLib;
